package app.tint;

import android.graphics.*;
import android.text.TextPaint;

/**
 * Sticker packs drawn from the phone's own colour emoji font (Noto Color Emoji on Android 15,
 * which is vector, so stickers stay sharp at any size). Free, offline, adds nothing to the app size.
 */
final class Stickers {
    static final String[] CATS = {"Smileys", "Love", "Hands", "People", "Animals", "Nature", "Food", "Party", "Travel", "Objects", "Symbols", "Flags"};

    static final String[] PACKS = {
            // Smileys
            "😀 😃 😄 😁 😆 😅 🤣 😂 🙂 🙃 😉 😊 😇 🥰 😍 🤩 😘 😗 😚 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🫢 🤫 🤔 🫡 🤐 🤨 😐 😑 😶 🫥 😏 😒 🙄 😬 😌 😔 😪 🤤 😴 😷 🤒 🥵 🥶 🥴 😵 🤯 🤠 🥳 🥸 😎 🤓 🧐 😕 🫤 😟 🙁 😮 😯 😲 😳 🥺 🥹 😦 😧 😨 😰 😥 😢 😭 😱 😖 😣 😞 😓 😩 😫 🥱 😤 😡 😠 🤬 😈 👿 💀 ☠️ 💩 🤡 👹 👺 👻 👽 👾 🤖 😺 😸 😹 😻 😼 😽 🙀 😿 😾",
            // Love
            "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 🩷 🩵 🩶 💔 ❤️‍🔥 ❤️‍🩹 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 💌 💋 🫶 🥰 😍 😘 😻 💑 💏 🌹 💐 💍 🧸 🎀 🍫 🌷",
            // Hands
            "👍 👎 👊 ✊ 🤛 🤜 👏 🙌 🫶 👐 🤲 🤝 🙏 ✌️ 🤞 🫰 🤟 🤘 👌 🤌 🤏 👈 👉 👆 👇 ☝️ 🫵 ✋ 🤚 🖐️ 🖖 👋 🤙 🫱 🫲 💪 🦾 ✍️ 💅 🤳 👀 👁️ 👅 👄 🫦 🧠",
            // People
            "👶 🧒 👦 👧 🧑 👱 👨 🧔 👩 🧓 👴 👵 🙋 🙆 🙅 🤷 🤦 💁 🙇 🧕 👳 👲 👰 🤵 👸 🤴 🫅 🦸 🦹 🧙 🧚 🧛 🧜 🧝 🧞 🧟 🥷 👮 👷 💂 🕵️ 👩‍⚕️ 👨‍🍳 👩‍🎓 👨‍🎤 👩‍🎨 👨‍🚀 👩‍💻 👨‍🔧 💃 🕺 👯 🧘 🏃 🚶 🧗 🏄 🏊 🚴 ⛹️ 🏋️ 👪",
            // Animals
            "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐻‍❄️ 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐢 🐍 🦎 🐙 🦑 🦐 🦀 🐡 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐅 🐆 🦓 🦍 🐘 🦛 🦏 🐪 🦒 🦘 🐄 🐎 🐑 🦙 🐐 🦌 🐕 🐩 🐈 🐈‍⬛ 🐓 🦚 🦜 🦢 🦩 🕊️ 🐇 🦝 🦦 🦥 🐿️ 🦔 🐾 🐉 🦕 🦖 🪼 🪿",
            // Nature
            "🌸 💮 🏵️ 🌹 🥀 🌺 🌻 🌼 🌷 🪷 🪻 🌱 🪴 🌲 🌳 🌴 🌵 🌾 🌿 ☘️ 🍀 🍁 🍂 🍃 🍄 🪸 🐚 🌍 🌙 🌛 🌜 🌝 🌞 🌚 ⭐ 🌟 ✨ 💫 ☄️ 🪐 ☀️ 🌤️ ⛅ 🌈 ☁️ 🌧️ ⛈️ 🌩️ ❄️ ☃️ ⛄ 🔥 💧 🌊 ⚡ 🌪️ 🌋 🏔️ 🏝️ 🏖️ 🏜️ 🌅 🌄 🌌",
            // Food
            "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🫐 🍈 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🥑 🍆 🥕 🌽 🌶️ 🥒 🥦 🧄 🧅 🥔 🥐 🥯 🍞 🥖 🧀 🥚 🍳 🥞 🧇 🍗 🍖 🌭 🍔 🍟 🍕 🥪 🌮 🌯 🥙 🧆 🥗 🍝 🍜 🍲 🍛 🍣 🍱 🥟 🍤 🍙 🍚 🍥 🍡 🍧 🍨 🍦 🥧 🧁 🍰 🎂 🍮 🍭 🍬 🍫 🍿 🍩 🍪 🥛 ☕ 🍵 🧋 🥤 🧃 🍹 🧉 🫖 🧊",
            // Party
            "🎉 🎊 🎈 🎁 🎀 🎂 🪅 🪩 🎆 🎇 🧨 ✨ 🎄 🎃 🎗️ 🎟️ 🏆 🥇 🥈 🥉 🏅 🎖️ 👑 💎 🎤 🎧 🎵 🎶 🎸 🎹 🥁 🎷 🎺 🎻 🪕 🪘 🎮 🕹️ 🎲 🧩 🎯 🎳 ⚽ 🏀 🏈 ⚾ 🎾 🏐 🎱 🏓 🏸 🥊 🛹 🌙 ☪️ 🕌 🏮 🪔 🕯️ 🎐 🎏",
            // Travel
            "🚗 🚕 🚙 🏎️ 🚓 🚑 🚒 🚐 🛻 🚚 🏍️ 🛵 🚲 🛴 🚂 🚆 🚇 🚊 ✈️ 🛫 🛬 🚁 🚀 🛸 ⛵ 🚤 🛳️ ⚓ 🗺️ 🧭 🏕️ ⛺ 🏠 🏡 🏢 🏰 🏯 🗼 🗽 🕋 🕌 ⛩️ 🌉 🎡 🎢 🎠 ⛲ 🏟️ 🌆 🌃 🌇 🌁 📍 🧳 🎒 🕶️ 📸 🏁",
            // Objects
            "📱 💻 ⌚ 📷 🎥 📺 📻 🔋 💡 🔦 🕯️ 💸 💵 💰 💳 💎 ⚖️ 🔧 🔨 ⚙️ 🧲 🔮 🧿 🪬 💊 🩹 🧸 🪄 📚 📖 ✏️ ✒️ 🖌️ 🖍️ 📝 📌 📎 ✂️ 🔑 🗝️ 🔒 🛍️ 👗 👠 👟 👜 👛 💄 💼 🎓 🧢 👒 🎩 ⏰ ⌛ 🧪 🔭 📡 🪞 🪟 🛋️ 🧴 🪥 🎨 🧵 🪡",
            // Symbols
            "💯 ✅ ❌ ❓ ❗ ‼️ ⁉️ 💢 💥 💦 💨 💤 💬 💭 🗯️ ♻️ ⚠️ 🚫 ⛔ 🆒 🆕 🆓 🆗 🆙 🔥 ⭐ 🌟 ✨ ⚡ ☮️ ☯️ ♾️ 🔆 ➕ ➖ ✖️ ➗ 💲 ©️ ®️ ™️ 🔴 🟠 🟡 🟢 🔵 🟣 🟤 ⚫ ⚪ 🟥 🟧 🟨 🟩 🟦 🟪 ⬛ ⬜ 🔺 🔻 🔸 🔹 ▶️ ⏸️ ⏩ 🔁 🔔 📢 ♈ ♉ ♊ ♋ ♌ ♍ ♎ ♏ ♐ ♑ ♒ ♓",
            // Flags
            "🇦🇪 🇪🇬 🇸🇦 🇶🇦 🇰🇼 🇴🇲 🇧🇭 🇯🇴 🇱🇧 🇲🇦 🇩🇿 🇹🇳 🇮🇶 🇸🇾 🇵🇸 🇾🇪 🇸🇩 🇱🇾 🇲🇷 🇸🇴 🇹🇷 🇮🇷 🇮🇳 🇵🇰 🇧🇩 🇮🇩 🇲🇾 🇵🇭 🇯🇵 🇰🇷 🇨🇳 🇺🇸 🇨🇦 🇲🇽 🇧🇷 🇦🇷 🇬🇧 🇫🇷 🇩🇪 🇮🇹 🇪🇸 🇵🇹 🇳🇱 🇧🇪 🇨🇭 🇸🇪 🇳🇴 🇬🇷 🇷🇺 🇺🇦 🇳🇬 🇿🇦 🇰🇪 🇪🇹 🇦🇺 🇳🇿 🏁 🏳️ 🏴 🚩",
    };

    static String[] pack(int i) { return PACKS[i].trim().split("\\s+"); }

    /** Renders one emoji big and crops it tight, ready to be a sticker. */
    static Bitmap render(String emoji, int px) {
        TextPaint p = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        p.setTextSize(px * 0.75f);
        p.setTextAlign(Paint.Align.CENTER);
        Bitmap b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint.FontMetrics fm = p.getFontMetrics();
        c.drawText(emoji, px / 2f, px / 2f - (fm.ascent + fm.descent) / 2f, p);
        Bitmap t = trim(b);
        if (t != b) b.recycle();
        return t;
    }

    private static Bitmap trim(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight();
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        int l = w, t = h, r = -1, bt = -1;
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                if ((px[y * w + x] >>> 24) > 8) {
                    if (x < l) l = x;
                    if (x > r) r = x;
                    if (y < t) t = y;
                    if (y > bt) bt = y;
                }
        if (r < 0) return b;
        int pad = Math.max(2, w / 64);
        l = Math.max(0, l - pad); t = Math.max(0, t - pad);
        r = Math.min(w - 1, r + pad); bt = Math.min(h - 1, bt + pad);
        return Bitmap.createBitmap(b, l, t, r - l + 1, bt - t + 1);
    }
}
