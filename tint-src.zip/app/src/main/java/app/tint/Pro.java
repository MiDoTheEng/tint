package app.tint;

/**
 * Professional colour grade, the way photo editors' presets work:
 * exposure, white balance, highlight / shadow recovery, tone curve, per-colour HSL,
 * vibrance, split toning, lift / gamma / gain, fade and clarity.
 * The grade is baked once into a 33×33×33 colour cube (3D LUT) and applied per pixel
 * with smooth interpolation, so it is fast even on full-resolution photos.
 */
final class Pro {
    // bands: red, orange, yellow, green, aqua, blue, purple, magenta
    static final int RED = 0, ORANGE = 1, YELLOW = 2, GREEN = 3, AQUA = 4, BLUE = 5, PURPLE = 6, MAGENTA = 7;
    private static final float[] CENTER = {0, 30, 60, 120, 180, 225, 270, 315};
    private static final float[] WIDTH = {30, 30, 35, 60, 50, 45, 45, 45};

    float exposure;          // stops
    float temp, tint;        // -1..1
    float highlights;        // -1 recover .. +1 brighten
    float shadows;           // -1 deepen .. +1 lift
    float whites, blacks;    // -1..1 end points
    float contrast;          // -1..1 (S-curve)
    float vibrance, saturation = 1;
    final float[] hueShift = new float[8], satMul = {1, 1, 1, 1, 1, 1, 1, 1}, lumShift = new float[8];
    int shadowTone = 0xFF808080, highlightTone = 0xFF808080;
    float splitShadows, splitHighlights;
    final float[] lift = new float[3], gain = {1, 1, 1};
    float fade;              // matte black lift
    float rolloff = 0.5f;    // gentle highlight shoulder
    boolean mono;
    float mixR = 0.30f, mixG = 0.59f, mixB = 0.11f;
    float clarity;           // -1..1 local contrast

    private int[] cube;

    // ------------------------------------------------------------------ builder helpers
    Pro exposure(float v) { exposure = v; return this; }
    Pro wb(float t, float g) { temp = t; tint = g; return this; }
    Pro tone(float hi, float sh) { highlights = hi; shadows = sh; return this; }
    Pro ends(float wh, float bl) { whites = wh; blacks = bl; return this; }
    Pro contrast(float v) { contrast = v; return this; }
    Pro color(float vib, float sat) { vibrance = vib; saturation = sat; return this; }
    Pro hsl(int band, float hue, float sat, float lum) { hueShift[band] = hue; satMul[band] = sat; lumShift[band] = lum; return this; }
    Pro split(int sh, float shAmt, int hi, float hiAmt) { shadowTone = sh; splitShadows = shAmt; highlightTone = hi; splitHighlights = hiAmt; return this; }
    Pro lgg(float lr, float lg, float lb, float gr, float gg, float gb) {
        lift[0] = lr; lift[1] = lg; lift[2] = lb; gain[0] = gr; gain[1] = gg; gain[2] = gb; return this;
    }
    Pro fade(float v) { fade = v; return this; }
    Pro rolloff(float v) { rolloff = v; return this; }
    Pro mono(float r, float g, float b) { mono = true; float s = r + g + b; mixR = r / s; mixG = g / s; mixB = b / s; return this; }
    Pro clarity(float v) { clarity = v; return this; }

    // ------------------------------------------------------------------ the grade
    private static float clamp(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
    private static float luma(float r, float g, float b) { return 0.2126f * r + 0.7152f * g + 0.0722f * b; }
    private static float sCurve(float x) { return x * x * (3 - 2 * x); }

    void grade(float[] c) {
        float r = c[0], g = c[1], b = c[2];

        // exposure (in linear light)
        if (exposure != 0) {
            float m = (float) Math.pow(2, exposure);
            r = (float) Math.pow(Math.pow(r, 2.2) * m, 1 / 2.2);
            g = (float) Math.pow(Math.pow(g, 2.2) * m, 1 / 2.2);
            b = (float) Math.pow(Math.pow(b, 2.2) * m, 1 / 2.2);
        }
        // white balance
        r *= 1 + temp * 0.12f;
        b *= 1 - temp * 0.12f;
        g *= 1 - tint * 0.08f;

        // mono with a channel mixer (like coloured lens filters)
        if (mono) {
            float m = mixR * r + mixG * g + mixB * b;
            r = g = b = m;
        }

        // highlights / shadows
        float L = clamp(luma(r, g, b));
        float d = shadows * 0.32f * (1 - L) * (1 - L) * (1 - L) * (1 + L)
                + highlights * 0.30f * L * L * L;
        r += d; g += d; b += d;

        // white / black points
        float bp = -blacks * 0.07f, wp = 1 - whites * 0.08f;
        r = (r - bp) / (wp - bp); g = (g - bp) / (wp - bp); b = (b - bp) / (wp - bp);

        // tone curve (S-curve)
        if (contrast != 0) {
            r = clamp(r); g = clamp(g); b = clamp(b);
            r += contrast * (sCurve(r) - r);
            g += contrast * (sCurve(g) - g);
            b += contrast * (sCurve(b) - b);
        }
        r = clamp(r); g = clamp(g); b = clamp(b);

        // HSL per colour + vibrance + saturation
        if (!mono) {
            float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
            float l = (max + min) / 2, s = 0, h = 0;
            float dd = max - min;
            if (dd > 1e-5f) {
                s = l > 0.5f ? dd / (2 - max - min) : dd / (max + min);
                if (max == r) h = ((g - b) / dd + (g < b ? 6 : 0));
                else if (max == g) h = (b - r) / dd + 2;
                else h = (r - g) / dd + 4;
                h *= 60;
                float hs = 0, sm = 0, ls = 0, wsum = 0;
                for (int i = 0; i < 8; i++) {
                    float dh = Math.abs(h - CENTER[i]);
                    if (dh > 180) dh = 360 - dh;
                    float w = dh >= WIDTH[i] ? 0 : (float) (0.5 + 0.5 * Math.cos(Math.PI * dh / WIDTH[i]));
                    if (w <= 0) continue;
                    hs += w * hueShift[i];
                    sm += w * (satMul[i] - 1);
                    ls += w * lumShift[i];
                    wsum += w;
                }
                if (wsum > 1) { hs /= wsum; sm /= wsum; ls /= wsum; }
                // protect near-grey tones: their "colour" is mostly noise, so colour tweaks would make blotches
                float prot = s < 0.05f ? 0 : (s > 0.22f ? 1 : sCurve((s - 0.05f) / 0.17f));
                hs *= prot; sm *= prot; ls *= prot;
                h = (h + hs + 360) % 360;
                s = clamp(s * (1 + sm));
                l = clamp(l + ls * s * 0.5f);
            }
            // vibrance boosts dull colours more than vivid ones (protects skin)
            s = clamp(s * saturation * (1 + vibrance * (1 - s) * 1.2f));
            float[] rgb = hsl2rgb(h, s, l);
            r = rgb[0]; g = rgb[1]; b = rgb[2];
        }

        // split toning
        L = clamp(luma(r, g, b));
        if (splitShadows > 0 || splitHighlights > 0) {
            float ws = (1 - L) * (1 - L) * splitShadows, wh = L * L * splitHighlights;
            float sl = luma(((shadowTone >> 16) & 255) / 255f, ((shadowTone >> 8) & 255) / 255f, (shadowTone & 255) / 255f);
            float hl = luma(((highlightTone >> 16) & 255) / 255f, ((highlightTone >> 8) & 255) / 255f, (highlightTone & 255) / 255f);
            r += ws * (((shadowTone >> 16) & 255) / 255f - sl) + wh * (((highlightTone >> 16) & 255) / 255f - hl);
            g += ws * (((shadowTone >> 8) & 255) / 255f - sl) + wh * (((highlightTone >> 8) & 255) / 255f - hl);
            b += ws * ((shadowTone & 255) / 255f - sl) + wh * ((highlightTone & 255) / 255f - hl);
        }

        // lift / gain (cinematic colour)
        r = lift[0] * (1 - r) + r * gain[0];
        g = lift[1] * (1 - g) + g * gain[1];
        b = lift[2] * (1 - b) + b * gain[2];

        // highlight shoulder: no harsh clipping
        r = shoulder(r); g = shoulder(g); b = shoulder(b);

        // matte fade
        if (fade > 0) {
            float k = fade * 0.13f;
            r = k + r * (1 - k * 1.1f); g = k + g * (1 - k * 1.1f); b = k + b * (1 - k * 1.1f);
        }
        c[0] = clamp(r); c[1] = clamp(g); c[2] = clamp(b);
    }

    private float shoulder(float x) {
        if (rolloff <= 0) return x;
        float knee = 1 - 0.25f * rolloff;
        if (x <= knee) return x;
        float span = 1 - knee;
        return knee + span * (1 - (float) Math.exp(-(x - knee) / span));
    }

    private static float[] hsl2rgb(float h, float s, float l) {
        if (s <= 0) return new float[]{l, l, l};
        float q = l < 0.5f ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
        return new float[]{hue(p, q, h / 360f + 1f / 3), hue(p, q, h / 360f), hue(p, q, h / 360f - 1f / 3)};
    }

    private static float hue(float p, float q, float t) {
        if (t < 0) t += 1;
        if (t > 1) t -= 1;
        if (t < 1f / 6) return p + (q - p) * 6 * t;
        if (t < 0.5f) return q;
        if (t < 2f / 3) return p + (q - p) * (2f / 3 - t) * 6;
        return p;
    }

    /** The baked colour cube (33³ entries, packed RGB). */
    synchronized int[] cube() {
        if (cube != null) return cube;
        int n = 33;
        int[] out = new int[n * n * n];
        float[] c = new float[3];
        for (int bi = 0; bi < n; bi++)
            for (int gi = 0; gi < n; gi++)
                for (int ri = 0; ri < n; ri++) {
                    c[0] = ri / 32f; c[1] = gi / 32f; c[2] = bi / 32f;
                    grade(c);
                    out[(bi * n + gi) * n + ri] = (Math.round(c[0] * 255) << 16) | (Math.round(c[1] * 255) << 8) | Math.round(c[2] * 255);
                }
        cube = out;
        return out;
    }

    /** Applies the cube to one pixel (r, g, b in 0..255) with trilinear interpolation. */
    static int apply(int[] cube, int r, int g, int b) {
        int rr = r * 32 * 256 / 255, gg = g * 32 * 256 / 255, bb = b * 32 * 256 / 255;
        int r0 = rr >> 8, g0 = gg >> 8, b0 = bb >> 8;
        int fr = rr & 255, fg = gg & 255, fb = bb & 255;
        int r1 = Math.min(32, r0 + 1), g1 = Math.min(32, g0 + 1), b1 = Math.min(32, b0 + 1);
        int c000 = cube[(b0 * 33 + g0) * 33 + r0], c100 = cube[(b0 * 33 + g0) * 33 + r1];
        int c010 = cube[(b0 * 33 + g1) * 33 + r0], c110 = cube[(b0 * 33 + g1) * 33 + r1];
        int c001 = cube[(b1 * 33 + g0) * 33 + r0], c101 = cube[(b1 * 33 + g0) * 33 + r1];
        int c011 = cube[(b1 * 33 + g1) * 33 + r0], c111 = cube[(b1 * 33 + g1) * 33 + r1];
        int out = 0;
        for (int sh = 16; sh >= 0; sh -= 8) {
            int a00 = lerp((c000 >> sh) & 255, (c100 >> sh) & 255, fr), a10 = lerp((c010 >> sh) & 255, (c110 >> sh) & 255, fr);
            int a01 = lerp((c001 >> sh) & 255, (c101 >> sh) & 255, fr), a11 = lerp((c011 >> sh) & 255, (c111 >> sh) & 255, fr);
            int v = lerp(lerp(a00, a10, fg), lerp(a01, a11, fg), fb);
            out |= v << sh;
        }
        return out;
    }

    private static int lerp(int a, int b, int f) { return a + (((b - a) * f) >> 8); }
}
