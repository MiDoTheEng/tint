package app.tint;

import android.graphics.BlendMode;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLExt;
import android.opengl.EGLSurface;
import android.opengl.GLES11Ext;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Random;

import javax.microedition.khronos.opengles.GL10;

/**
 * Draws the camera feed on the GPU with the filter applied in a shader, so the live
 * preview runs at the camera's full frame rate. Covers the colour part of every filter
 * (colour matrix, pro grade cube, gradient maps, posterize) plus vignette, grain, scan lines,
 * RGB split, pixelate, mirror, colour wash, light leak and cinema bars.
 */
final class CameraGL implements GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener {
    interface Ready { void onSurface(SurfaceTexture st); }

    final GLSurfaceView view;
    final Ready ready;
    SurfaceTexture st;
    volatile Filter pending;
    volatile boolean filterDirty = true;
    volatile float rot;            // radians, for tablets in landscape
    volatile boolean flipX;
    volatile float contentAspect;  // camera picture width/height as shown (0 = fill exactly)

    private int prog, camTex, cubeTex, gradTex, noiseTex;
    private int bloomFbo, bloomTex, bw, bh;          // small image of the bright parts, for the glow
    private float glow;
    private int w = 1, h = 1;
    private final float[] texM = new float[16];
    private FloatBuffer quad;
    private final Random rnd = new Random();

    // current filter uniforms
    private final float[] m3 = {1, 0, 0, 0, 1, 0, 0, 0, 1};
    private final float[] off = new float[3];
    private float cubeOn, gradOn, gradMix, poster, split, pixel, washA, leakA, vig, scan, grain, bars;
    private int mirror, washMode;
    private final float[] wash = new float[3], leak = new float[3];

    CameraGL(GLSurfaceView v, Ready r) { view = v; ready = r; }

    // ------------------------------------------------------------------ video recording
    // Every camera frame is drawn twice: once on screen and once into the video encoder,
    // so the recorded video has the same live filter.
    private volatile android.view.Surface recIn;
    private volatile int recW, recH;
    private volatile boolean recStop;
    private volatile Runnable recStopped;
    private EGLSurface recSurface;

    void startRecording(android.view.Surface s, int w, int h) { recW = w; recH = h; recStop = false; recIn = s; }

    void stopRecording(Runnable done) { recStopped = done; recStop = true; view.requestRender(); }

    private void recordFrame(long ts) {
        EGLDisplay dpy = EGL14.eglGetCurrentDisplay();
        EGLContext ctx = EGL14.eglGetCurrentContext();
        EGLSurface draw = EGL14.eglGetCurrentSurface(EGL14.EGL_DRAW), read = EGL14.eglGetCurrentSurface(EGL14.EGL_READ);
        if (recStop) {
            if (recSurface != null) { EGL14.eglDestroySurface(dpy, recSurface); recSurface = null; }
            recIn = null;
            recStop = false;
            Runnable r = recStopped;
            recStopped = null;
            if (r != null) view.post(r);
            return;
        }
        if (recIn == null) return;
        if (recSurface == null) {
            int[] id = new int[1];
            EGL14.eglQueryContext(dpy, ctx, EGL14.EGL_CONFIG_ID, id, 0);
            EGLConfig[] cfg = new EGLConfig[1];
            int[] n = new int[1];
            EGL14.eglChooseConfig(dpy, new int[]{EGL14.EGL_CONFIG_ID, id[0], EGL14.EGL_NONE}, 0, cfg, 0, 1, n, 0);
            recSurface = EGL14.eglCreateWindowSurface(dpy, cfg[0], recIn, new int[]{EGL14.EGL_NONE}, 0);
            if (recSurface == null || recSurface == EGL14.EGL_NO_SURFACE) { recSurface = null; recIn = null; return; }
        }
        if (glow > 0 && bloomFbo != 0) {                 // glow for the video's own (wider) framing
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, bloomFbo);
            drawPass(bw, bh, 1, (float) recW / recH);
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        }
        EGL14.eglMakeCurrent(dpy, recSurface, recSurface, ctx);
        draw(recW, recH);
        EGLExt.eglPresentationTimeANDROID(dpy, recSurface, ts);
        EGL14.eglSwapBuffers(dpy, recSurface);
        EGL14.eglMakeCurrent(dpy, draw, read, ctx);
    }

    void setFilter(Filter f) { pending = f; filterDirty = true; view.requestRender(); }

    // ------------------------------------------------------------------ lens-switch transition
    interface Snap { void got(android.graphics.Bitmap b); }
    private volatile Snap snapCb;
    private volatile Runnable framesCb;
    private volatile int framesLeft;

    /** Grabs the picture currently on screen (small), for the blur-across when changing cameras. */
    void snapshot(Snap cb) { snapCb = cb; view.requestRender(); }

    // ------------------------------------------------------------------ small frames for gesture detection
    volatile Snap analysis;                 // receives a small frame about 7 times a second
    private long lastAnalysis;
    private int anaFbo, anaTex, aw, ah;

    private void analysisFrame() {
        long now = System.currentTimeMillis();
        if (now - lastAnalysis < 140) return;
        lastAnalysis = now;
        Snap cb = analysis;
        if (cb == null) return;
        int tw = 240, th = Math.max(16, Math.round(240f * h / w));
        if (anaFbo == 0 || aw != tw || ah != th) {
            int[] t = new int[1];
            if (anaTex != 0) { t[0] = anaTex; GLES30.glDeleteTextures(1, t, 0); }
            if (anaFbo != 0) { t[0] = anaFbo; GLES30.glDeleteFramebuffers(1, t, 0); }
            aw = tw; ah = th;
            GLES30.glGenTextures(1, t, 0);
            anaTex = t[0];
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, anaTex);
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, aw, ah, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null);
            GLES30.glGenFramebuffers(1, t, 0);
            anaFbo = t[0];
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, anaFbo);
            GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, anaTex, 0);
        } else {
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, anaFbo);
        }
        drawPass(aw, ah, 0, (float) w / h);
        ByteBuffer buf = ByteBuffer.allocateDirect(aw * ah * 4).order(ByteOrder.nativeOrder());
        GLES30.glReadPixels(0, 0, aw, ah, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf);
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        GLES30.glViewport(0, 0, w, h);
        android.graphics.Bitmap bm = android.graphics.Bitmap.createBitmap(aw, ah, android.graphics.Bitmap.Config.ARGB_8888);
        buf.rewind();
        bm.copyPixelsFromBuffer(buf);
        android.graphics.Matrix m = new android.graphics.Matrix();
        m.setScale(1, -1);
        android.graphics.Bitmap up = android.graphics.Bitmap.createBitmap(bm, 0, 0, aw, ah, m, false);
        bm.recycle();
        cb.got(up);                          // called on the GL thread; the receiver hands it off quickly
    }

    /** Runs once n new camera frames have been drawn (the new lens has settled). */
    void onNextFrames(int n, Runnable r) { framesLeft = n; framesCb = r; }

    private void grab() {
        Snap cb = snapCb;
        snapCb = null;
        android.graphics.Bitmap out = null;
        try {
            ByteBuffer buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder());
            GLES30.glReadPixels(0, 0, w, h, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf);
            android.graphics.Bitmap full = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888);
            buf.rewind();
            full.copyPixelsFromBuffer(buf);
            android.graphics.Matrix m = new android.graphics.Matrix();
            m.setScale(0.25f, -0.25f);                       // GL rows are upside down; shrink while flipping
            out = android.graphics.Bitmap.createBitmap(full, 0, 0, w, h, m, true);
            full.recycle();
        } catch (Throwable ignored) { }
        final android.graphics.Bitmap fb = out;
        if (cb != null) view.post(() -> cb.got(fb));
    }

    private static final String VS =
            "#version 300 es\n" +
            "in vec2 aPos; out vec2 vUV;\n" +
            "void main(){ vUV = aPos*0.5+0.5; gl_Position = vec4(aPos,0.0,1.0); }\n";

    private static final String FS =
            "#version 300 es\n" +
            "#extension GL_OES_EGL_image_external_essl3 : require\n" +
            "precision highp float; precision highp sampler3D;\n" +
            "in vec2 vUV; out vec4 o;\n" +
            "uniform samplerExternalOES uCam; uniform mat4 uTex; uniform float uRot; uniform float uFlipX; uniform vec2 uScale;\n" +
            "uniform mat3 uM; uniform vec3 uMo;\n" +
            "uniform float uCubeOn; uniform sampler3D uCube;\n" +
            "uniform float uGradOn; uniform sampler2D uGrad; uniform float uGradMix;\n" +
            "uniform float uPoster; uniform float uSplit; uniform float uPixel; uniform int uMirror; uniform vec2 uRes;\n" +
            "uniform vec3 uWash; uniform float uWashA; uniform int uWashMode;\n" +
            "uniform vec3 uLeak; uniform float uLeakA;\n" +
            "uniform float uVig; uniform float uScan; uniform float uGrain; uniform sampler2D uNoise; uniform vec2 uNoiseOff; uniform float uBars;\n" +
            "uniform int uPass; uniform sampler2D uBloom; uniform vec2 uBT; uniform float uGlow;\n" +
            "vec3 cam(vec2 s){\n" +
            "  if (uFlipX > 0.5) s.x = 1.0 - s.x;\n" +
            "  s = (s - 0.5)*uScale + 0.5;\n" +
            "  vec2 c = vec2(s.x, 1.0 - s.y) - 0.5;\n" +
            "  float cs = cos(uRot), sn = sin(uRot);\n" +
            "  c = vec2(c.x*cs - c.y*sn, c.x*sn + c.y*cs) + 0.5;\n" +
            "  return texture(uCam, (uTex*vec4(c,0.0,1.0)).xy).rgb;\n" +
            "}\n" +
            "vec3 mat(vec3 c){ return clamp(uM*c + uMo, 0.0, 1.0); }\n" +
            "vec3 blend(vec3 a, vec3 b, int m){\n" +
            "  if (m==1) return 1.0-(1.0-a)*(1.0-b);\n" +
            "  if (m==2) return mix(2.0*a*b, 1.0-2.0*(1.0-a)*(1.0-b), step(0.5,a));\n" +
            "  if (m==3) return a*b;\n" +
            "  if (m==4) return (1.0-2.0*b)*a*a + 2.0*b*a;\n" +
            "  return b;\n" +
            "}\n" +
            "void main(){\n" +
            "  vec2 s = vec2(vUV.x, 1.0 - vUV.y);\n" +
            "  if ((uMirror==1 || uMirror==3) && s.x > 0.5) s.x = 1.0 - s.x;\n" +
            "  if ((uMirror==2 || uMirror==3) && s.y > 0.5) s.y = 1.0 - s.y;\n" +
            "  if (uPixel > 0.0) { vec2 b = vec2(uPixel, uPixel*uRes.y/uRes.x); s = (floor(s*b)+0.5)/b; }\n" +
            "  vec3 c;\n" +
            "  if (uSplit > 0.0) c = vec3(mat(cam(s - vec2(uSplit,0.0))).r, mat(cam(s)).g, mat(cam(s + vec2(uSplit,0.0))).b);\n" +
            "  else c = mat(cam(s));\n" +
            "  if (uCubeOn > 0.5) c = texture(uCube, c*(32.0/33.0) + 0.5/33.0).rgb;\n" +
            "  if (uGradOn > 0.5) { float l = dot(c, vec3(0.299,0.587,0.114)); c = mix(c, texture(uGrad, vec2(l*(255.0/256.0)+0.5/256.0,0.5)).rgb, uGradMix); }\n" +
            "  if (uPoster > 1.0) c = floor(c*(uPoster-1.0)+0.5)/(uPoster-1.0);\n" +
            "  if (uPass == 1) { float m = max(max(c.r,c.g),c.b); o = vec4(c*smoothstep(0.55,0.95,m), 1.0); return; }\n" +
            "  if (uGlow > 0.0) {\n" +
            "    vec3 b = texture(uBloom, s).rgb*0.2;\n" +
            "    b += (texture(uBloom, s+vec2(uBT.x*1.5,0.0)).rgb + texture(uBloom, s-vec2(uBT.x*1.5,0.0)).rgb\n" +
            "        + texture(uBloom, s+vec2(0.0,uBT.y*1.5)).rgb + texture(uBloom, s-vec2(0.0,uBT.y*1.5)).rgb)*0.13;\n" +
            "    b += (texture(uBloom, s+uBT*2.5).rgb + texture(uBloom, s-uBT*2.5).rgb\n" +
            "        + texture(uBloom, s+vec2(uBT.x,-uBT.y)*2.5).rgb + texture(uBloom, s-vec2(uBT.x,-uBT.y)*2.5).rgb)*0.07;\n" +
            "    c = 1.0-(1.0-c)*(1.0-clamp(b*uGlow*2.2, 0.0, 1.0));\n" +
            "  }\n" +
            "  if (uWashA > 0.0) c = mix(c, blend(c, uWash, uWashMode), uWashA);\n" +
            "  if (uLeakA > 0.0) { float d = length((s - vec2(0.02,0.12))*uRes)/(max(uRes.x,uRes.y)*0.85);\n" +
            "    vec3 l = uLeak*(1.0 - smoothstep(0.0,1.0,d))*uLeakA; c = 1.0-(1.0-c)*(1.0-l); }\n" +
            "  if (uVig > 0.0) { float d = length((s-0.5)*uRes)/(0.5*length(uRes)); c *= 1.0 - uVig*smoothstep(0.5,1.0,d); }\n" +
            "  if (uScan > 0.0) { float k = fract(s.y*uRes.y/max(2.0, uRes.y/320.0)); if (k < 0.45) c *= 1.0 - uScan; }\n" +
            "  if (uGrain > 0.0) { float n = texture(uNoise, s*uRes/192.0 + uNoiseOff).r;\n" +
            "    vec3 ov = mix(2.0*c*n, 1.0-2.0*(1.0-c)*(1.0-n), step(0.5,c)); c = mix(c, ov, uGrain); }\n" +
            "  if (uBars > 0.0) { float bh = (1.0 - uRes.x/2.39/uRes.y)/2.0; if (s.y < bh || s.y > 1.0-bh) c = vec3(0.0); }\n" +
            "  o = vec4(clamp(c,0.0,1.0), 1.0);\n" +
            "}\n";

    private static int shader(int type, String src) {
        int s = GLES30.glCreateShader(type);
        GLES30.glShaderSource(s, src);
        GLES30.glCompileShader(s);
        return s;
    }

    @Override
    public void onSurfaceCreated(GL10 unused, javax.microedition.khronos.egl.EGLConfig config) {
        prog = GLES30.glCreateProgram();
        GLES30.glAttachShader(prog, shader(GLES30.GL_VERTEX_SHADER, VS));
        GLES30.glAttachShader(prog, shader(GLES30.GL_FRAGMENT_SHADER, FS));
        GLES30.glBindAttribLocation(prog, 0, "aPos");
        GLES30.glLinkProgram(prog);

        quad = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        quad.put(new float[]{-1, -1, 1, -1, -1, 1, 1, 1}).position(0);

        int[] t = new int[4];
        GLES30.glGenTextures(4, t, 0);
        camTex = t[0]; cubeTex = t[1]; gradTex = t[2]; noiseTex = t[3];

        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex);
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);

        // placeholders so every sampler always has a valid texture
        uploadCube(new int[]{0});
        uploadGrad(new int[]{0});

        byte[] n = new byte[192 * 192];
        Random r = new Random(7);
        for (int i = 0; i < n.length; i++) n[i] = (byte) Math.max(0, Math.min(255, (int) (128 + r.nextGaussian() * 38)));
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, noiseTex);
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1);
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_R8, 192, 192, 0, GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, ByteBuffer.wrap(n));
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT);

        if (st != null) st.release();
        st = new SurfaceTexture(camTex);
        st.setOnFrameAvailableListener(this);
        filterDirty = true;
        final SurfaceTexture s = st;
        view.post(() -> ready.onSurface(s));
    }

    private void uploadCube(int[] cube) {
        int n = cube.length == 1 ? 1 : 33;
        ByteBuffer b = ByteBuffer.allocateDirect(n * n * n * 3);
        for (int i = 0; i < n * n * n; i++) {
            int c = cube[i];
            b.put((byte) ((c >> 16) & 255)).put((byte) ((c >> 8) & 255)).put((byte) (c & 255));
        }
        b.position(0);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, cubeTex);
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1);
        GLES30.glTexImage3D(GLES30.GL_TEXTURE_3D, 0, GLES30.GL_RGB8, n, n, n, 0, GLES30.GL_RGB, GLES30.GL_UNSIGNED_BYTE, b);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_R, GLES30.GL_CLAMP_TO_EDGE);
    }

    private void uploadGrad(int[] lut) {
        int n = lut.length;
        ByteBuffer b = ByteBuffer.allocateDirect(n * 3);
        for (int c : lut) b.put((byte) ((c >> 16) & 255)).put((byte) ((c >> 8) & 255)).put((byte) (c & 255));
        b.position(0);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, gradTex);
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1);
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGB8, n, 1, 0, GLES30.GL_RGB, GLES30.GL_UNSIGNED_BYTE, b);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
    }

    private static int modeOf(BlendMode m) {
        if (m == BlendMode.SCREEN) return 1;
        if (m == BlendMode.OVERLAY) return 2;
        if (m == BlendMode.MULTIPLY) return 3;
        if (m == BlendMode.SOFT_LIGHT) return 4;
        return 0;
    }

    private void applyFilter(Filter f) {
        float[] a = Renderer.matrix(f).getArray();
        for (int i = 0; i < 3; i++) {                 // column-major mat3 from Android's 4x5 matrix
            for (int j = 0; j < 3; j++) m3[j * 3 + i] = a[i * 5 + j];
            off[i] = (a[i * 5 + 3] * 255 + a[i * 5 + 4]) / 255f;
        }
        cubeOn = 0;
        if (f.pro != null) { uploadCube(f.pro.cube()); cubeOn = 1; }
        gradOn = 0;
        if (f.grad != null) { uploadGrad(Renderer.buildLut(f.grad)); gradOn = 1; gradMix = f.gradMix; }
        poster = f.poster;
        split = f.split;
        pixel = f.pixel;
        mirror = f.mirror;
        washA = f.ovA;
        washMode = modeOf(f.ovMode);
        wash[0] = Color.red(f.ovColor) / 255f; wash[1] = Color.green(f.ovColor) / 255f; wash[2] = Color.blue(f.ovColor) / 255f;
        leakA = f.leak;
        leak[0] = Color.red(f.leakColor) / 255f; leak[1] = Color.green(f.leakColor) / 255f; leak[2] = Color.blue(f.leakColor) / 255f;
        vig = f.vig;
        scan = f.scan;
        grain = f.grain;
        bars = f.bars ? 1 : 0;
        glow = f.glow;
    }

    @Override
    public void onSurfaceChanged(GL10 unused, int width, int height) {
        w = Math.max(1, width);
        h = Math.max(1, height);
        GLES30.glViewport(0, 0, w, h);
        bw = Math.max(16, w / 10);
        bh = Math.max(16, h / 10);
        int[] t = new int[1];
        if (bloomTex != 0) { t[0] = bloomTex; GLES30.glDeleteTextures(1, t, 0); }
        if (bloomFbo != 0) { t[0] = bloomFbo; GLES30.glDeleteFramebuffers(1, t, 0); }
        GLES30.glGenTextures(1, t, 0);
        bloomTex = t[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, bloomTex);
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, bw, bh, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glGenFramebuffers(1, t, 0);
        bloomFbo = t[0];
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, bloomFbo);
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, bloomTex, 0);
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
    }

    @Override
    public void onDrawFrame(GL10 unused) {
        if (st == null) return;
        try { st.updateTexImage(); } catch (Throwable ignored) { return; }
        st.getTransformMatrix(texM);
        if (filterDirty) {
            filterDirty = false;
            Filter f = pending;
            if (f != null) applyFilter(f);
        }
        if (glow > 0 && bloomFbo != 0) {
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, bloomFbo);
            drawPass(bw, bh, 1, (float) w / h);
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        }
        draw(w, h);
        if (snapCb != null) grab();
        if (analysis != null) analysisFrame();
        if (framesCb != null && --framesLeft <= 0) { Runnable r = framesCb; framesCb = null; view.post(r); }
        if (recIn != null || recStop) recordFrame(st.getTimestamp());
    }

    private void draw(int vw, int vh) { drawPass(vw, vh, 0, (float) vw / vh); }

    /** pass 0: the picture; pass 1: bright parts only, into the small glow image. aspect = framing to use. */
    private void drawPass(int vw, int vh, int pass, float aspect) {
        GLES30.glViewport(0, 0, vw, vh);
        GLES30.glUseProgram(prog);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE4);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, pass == 0 && bloomTex != 0 ? bloomTex : noiseTex);
        u1i("uBloom", 4);
        u1i("uPass", pass);
        u1f("uGlow", pass == 0 && bloomTex != 0 ? glow : 0);
        GLES30.glUniform2f(GLES30.glGetUniformLocation(prog, "uBT"), 1f / Math.max(1, bw), 1f / Math.max(1, bh));
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, cubeTex);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE2);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, gradTex);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE3);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, noiseTex);
        u1i("uCam", 0); u1i("uCube", 1); u1i("uGrad", 2); u1i("uNoise", 3);
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(prog, "uTex"), 1, false, texM, 0);
        u1f("uRot", rot);
        u1f("uFlipX", flipX ? 1 : 0);
        float va = aspect, ca = contentAspect, sx = 1, sy = 1;
        if (ca > 0) { if (va < ca) sx = va / ca; else sy = ca / va; }        // cover: fill the screen, crop the overflow
        GLES30.glUniform2f(GLES30.glGetUniformLocation(prog, "uScale"), sx, sy);
        GLES30.glUniformMatrix3fv(GLES30.glGetUniformLocation(prog, "uM"), 1, false, m3, 0);
        GLES30.glUniform3fv(GLES30.glGetUniformLocation(prog, "uMo"), 1, off, 0);
        u1f("uCubeOn", cubeOn);
        u1f("uGradOn", gradOn);
        u1f("uGradMix", gradMix);
        u1f("uPoster", poster);
        u1f("uSplit", split);
        u1f("uPixel", pixel);
        u1i("uMirror", mirror);
        GLES30.glUniform2f(GLES30.glGetUniformLocation(prog, "uRes"), vw, vh);
        GLES30.glUniform3fv(GLES30.glGetUniformLocation(prog, "uWash"), 1, wash, 0);
        u1f("uWashA", washA);
        u1i("uWashMode", washMode);
        GLES30.glUniform3fv(GLES30.glGetUniformLocation(prog, "uLeak"), 1, leak, 0);
        u1f("uLeakA", leakA);
        u1f("uVig", vig);
        u1f("uScan", scan);
        u1f("uGrain", grain);
        GLES30.glUniform2f(GLES30.glGetUniformLocation(prog, "uNoiseOff"), rnd.nextFloat(), rnd.nextFloat());
        u1f("uBars", bars);
        GLES30.glEnableVertexAttribArray(0);
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 0, quad);
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4);
    }

    private void u1f(String n, float v) { GLES30.glUniform1f(GLES30.glGetUniformLocation(prog, n), v); }
    private void u1i(String n, int v) { GLES30.glUniform1i(GLES30.glGetUniformLocation(prog, n), v); }

    @Override
    public void onFrameAvailable(SurfaceTexture s) { view.requestRender(); }
}
