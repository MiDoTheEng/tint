package app.tint;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;

import com.google.mediapipe.framework.image.BitmapImageBuilder;
import com.google.mediapipe.framework.image.ByteBufferExtractor;
import com.google.mediapipe.framework.image.MPImage;
import com.google.mediapipe.tasks.core.BaseOptions;
import com.google.mediapipe.tasks.vision.core.RunningMode;
import com.google.mediapipe.tasks.vision.imagesegmenter.ImageSegmenter;
import com.google.mediapipe.tasks.vision.imagesegmenter.ImageSegmenterResult;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.List;

/**
 * Background removal that needs nothing from Google Play services: two small models packed
 * inside the app (fetched at build time). Used when Google's own tool is missing or fails,
 * for example on a Huawei tablet.
 *
 * People are tried first (sharper edges); if no person is found, a general model that knows
 * pets, cars, plants, bottles, furniture and similar objects is tried.
 */
final class LocalCutout {
    static final String PEOPLE = "selfie_multiclass_256x256.tflite";
    static final String OBJECTS = "deeplab_v3.tflite";
    /** The photo is shrunk to this before it goes to the model; the mask is stretched back afterwards. */
    static final int INPUT_MAX = 640;

    private static ImageSegmenter people, objects;

    private LocalCutout() {}

    /**
     * A small soft mask of the subject: alpha is how much each pixel belongs to the subject,
     * colour is unused. Null when no subject is found. Throws if the engine cannot run.
     * Slow; call it off the main thread.
     */
    static synchronized Bitmap mask(Context c, Bitmap src) {
        Bitmap in = prepare(src);
        try {
            if (people == null) people = open(c, PEOPLE);
            Bitmap m = run(people, in);
            if (coverage(m) >= 0.01f) return m;
            if (objects == null) objects = open(c, OBJECTS);
            Bitmap o = run(objects, in);
            if (coverage(o) >= 0.005f) return o;
            return null;
        } finally {
            if (in != src) in.recycle();
        }
    }

    /** The mask stretched to the given size, as a new bitmap that can be painted on. */
    static Bitmap full(Bitmap mask, int w, int h) {
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        new Canvas(out).drawBitmap(mask, null, new Rect(0, 0, w, h), p);
        return out;
    }

    /** A copy of the photo with everything outside the mask made transparent. */
    static Bitmap foreground(Bitmap src, Bitmap mask) {
        Bitmap out = src.copy(Bitmap.Config.ARGB_8888, true);
        out.setHasAlpha(true);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        new Canvas(out).drawBitmap(mask, null, new Rect(0, 0, out.getWidth(), out.getHeight()), p);
        return out;
    }

    static synchronized void close() {
        try { if (people != null) people.close(); } catch (Throwable ignored) { }
        try { if (objects != null) objects.close(); } catch (Throwable ignored) { }
        people = null;
        objects = null;
    }

    // ------------------------------------------------------------------ engine

    private static ImageSegmenter open(Context c, String model) {
        ImageSegmenter.ImageSegmenterOptions opt = ImageSegmenter.ImageSegmenterOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath(model).build())
                .setRunningMode(RunningMode.IMAGE)
                .setOutputConfidenceMasks(true)
                .setOutputCategoryMask(false)
                .build();
        return ImageSegmenter.createFromOptions(c.getApplicationContext(), opt);
    }

    /** A plain, modest-size copy the engine accepts (or the photo itself when it already is one). */
    private static Bitmap prepare(Bitmap src) {
        int w = src.getWidth(), h = src.getHeight();
        float k = Math.min(1f, INPUT_MAX / (float) Math.max(w, h));
        if (k >= 1f && src.getConfig() == Bitmap.Config.ARGB_8888) return src;
        int nw = Math.max(1, Math.round(w * k)), nh = Math.max(1, Math.round(h * k));
        Bitmap out = Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888);
        new Canvas(out).drawBitmap(src, null, new Rect(0, 0, nw, nh), new Paint(Paint.FILTER_BITMAP_FLAG));
        return out;
    }

    /** Runs one model. In both models the first output is "background", so subject = 1 - background. */
    private static Bitmap run(ImageSegmenter seg, Bitmap in) {
        ImageSegmenterResult res = seg.segment(new BitmapImageBuilder(in).build());
        List<MPImage> masks = res.confidenceMasks().get();
        MPImage bg = masks.get(0);
        int w = bg.getWidth(), h = bg.getHeight();
        float[] conf = new float[w * h];
        read(ByteBufferExtractor.extract(bg), conf);
        int[] px = new int[w * h];
        for (int i = 0; i < px.length; i++) {
            float fg = 1f - conf[i];
            // a little contrast so soft, unsure edges do not leave a haze around the subject
            float a = (fg - 0.15f) / 0.7f;
            if (a < 0f) a = 0f; else if (a > 1f) a = 1f;
            px[i] = Math.round(a * 255f) << 24;
        }
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        out.setPixels(px, 0, w, 0, 0, w, h);
        return out;
    }

    /**
     * Copies the confidences out of the engine's buffer. The numbers are written in the device's
     * own byte order; if they come out as nonsense (not between 0 and 1) the other order is used.
     */
    private static void read(ByteBuffer raw, float[] out) {
        ByteBuffer b = raw.duplicate();
        b.rewind();
        b.order(ByteOrder.nativeOrder());
        if (!fill(b.asFloatBuffer(), out)) {
            b.rewind();
            b.order(b.order() == ByteOrder.LITTLE_ENDIAN ? ByteOrder.BIG_ENDIAN : ByteOrder.LITTLE_ENDIAN);
            fill(b.asFloatBuffer(), out);
        }
    }

    private static boolean fill(FloatBuffer f, float[] out) {
        int n = Math.min(out.length, f.remaining());
        f.get(out, 0, n);
        for (int i = n; i < out.length; i++) out[i] = 1f;   // anything missing counts as background
        int step = Math.max(1, n / 2000);
        for (int i = 0; i < n; i += step) {
            float v = out[i];
            if (!(v >= -0.05f && v <= 1.05f)) return false;
        }
        return true;
    }

    /** Share of the picture that is clearly subject. */
    private static float coverage(Bitmap m) {
        int w = m.getWidth(), h = m.getHeight();
        int[] px = new int[w * h];
        m.getPixels(px, 0, w, 0, 0, w, h);
        int n = 0;
        for (int p : px) if ((p >>> 24) > 128) n++;
        return n / (float) px.length;
    }
}
