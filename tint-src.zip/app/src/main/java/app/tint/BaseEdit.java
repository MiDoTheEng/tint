package app.tint;

import android.graphics.*;

/**
 * Edits to the main photo, applied in this order:
 *   1. cut-out (mask, in the original photo's space) + new background
 *   2. rotate / flip
 *   3. crop (fractions of the rotated image), optionally circular
 * The same code runs on the preview and on the full-resolution photo when saving.
 */
final class BaseEdit {
    static final int BG_NONE = 0, BG_COLOR = 1, BG_GRADIENT = 2, BG_BLUR = 3, BG_PHOTO = 4;

    int rot;                 // quarter turns clockwise
    boolean flip;
    RectF crop;              // null = whole image
    boolean cropCircle;

    Bitmap mask;             // raw cut-out confidence in the alpha channel (null = background kept)
    int maskVer;
    float soft = 0.55f;      // edge softness 0..1
    float grow = 0.5f;       // shrink 0 .. grow 1

    int bg = BG_NONE;
    int c1 = Color.WHITE, c2 = 0xFF7C4DFF;
    float blur = 0.5f;
    Bitmap bgPhoto;
    int bgVer;

    BaseEdit copy() {
        BaseEdit e = new BaseEdit();
        e.rot = rot; e.flip = flip; e.crop = crop == null ? null : new RectF(crop); e.cropCircle = cropCircle;
        e.mask = mask; e.maskVer = maskVer; e.soft = soft; e.grow = grow;
        e.bg = bg; e.c1 = c1; e.c2 = c2; e.blur = blur; e.bgPhoto = bgPhoto; e.bgVer = bgVer;
        return e;
    }

    boolean isEmpty() { return rot == 0 && !flip && crop == null && mask == null; }

    ColorMatrixColorFilter levels() {
        float width = 0.04f + 0.9f * soft;
        float centre = 0.68f - 0.36f * grow;
        float s = 1f / width, t = 255f * (0.5f - centre / width);
        return new ColorMatrixColorFilter(new float[]{
                1, 0, 0, 0, 0,
                0, 1, 0, 0, 0,
                0, 0, 1, 0, 0,
                0, 0, 0, s, t});
    }

    /** Rotated size of an image of w x h. */
    int[] orientedSize(int w, int h) { return rot % 2 == 0 ? new int[]{w, h} : new int[]{h, w}; }

    /**
     * Applies the edits. When `own` is true, src may be modified or recycled (saves memory at full size).
     * Always returns a bitmap that the caller owns (may be src itself if nothing changes).
     */
    Bitmap compose(Bitmap src, boolean own) {
        Bitmap cur = src;
        int W = src.getWidth(), H = src.getHeight();

        // 1. cut-out + background
        if (mask != null) {
            Bitmap blurSmall = null;
            if (bg == BG_BLUR) {
                int bw = Math.max(4, Math.round(W / (12f + 60f * blur))), bh = Math.max(4, Math.round((float) bw * H / W));
                blurSmall = Renderer.scaleDown(src, bw, bh);
            }
            Bitmap cut = (own && src.isMutable()) ? src : src.copy(Bitmap.Config.ARGB_8888, true);
            cut.setHasAlpha(true);
            Canvas c = new Canvas(cut);
            Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
            p.setColorFilter(levels());
            p.setBlendMode(BlendMode.DST_IN);
            c.drawBitmap(mask, null, new Rect(0, 0, W, H), p);

            if (bg != BG_NONE) {
                Bitmap out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
                Canvas oc = new Canvas(out);
                drawBackground(oc, W, H, blurSmall);
                oc.drawBitmap(cut, 0, 0, null);
                out.setHasAlpha(false);
                if (cut != src || own) cut.recycle();
                cur = out;
            } else {
                cur = cut;
            }
            if (blurSmall != null) blurSmall.recycle();
        }

        // 2. rotate / flip
        if (rot != 0 || flip) {
            Matrix m = new Matrix();
            if (flip) m.postScale(-1, 1);
            if (rot != 0) m.postRotate(90 * rot);
            Bitmap r = Bitmap.createBitmap(cur, 0, 0, cur.getWidth(), cur.getHeight(), m, true);
            if (r != cur && (cur != src || own)) cur.recycle();
            cur = r;
        }

        // 3. crop
        if (crop != null) {
            int w = cur.getWidth(), h = cur.getHeight();
            int l = clamp(Math.round(crop.left * w), 0, w - 1), t = clamp(Math.round(crop.top * h), 0, h - 1);
            int r = clamp(Math.round(crop.right * w), l + 1, w), b = clamp(Math.round(crop.bottom * h), t + 1, h);
            Bitmap cr = Bitmap.createBitmap(r - l, b - t, Bitmap.Config.ARGB_8888);
            Canvas cc = new Canvas(cr);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            if (cropCircle) {
                cc.drawOval(new RectF(0, 0, r - l, b - t), p);
                p.setBlendMode(BlendMode.SRC_IN);
            }
            cc.drawBitmap(cur, new Rect(l, t, r, b), new Rect(0, 0, r - l, b - t), p);
            if (!cropCircle && !cur.hasAlpha()) cr.setHasAlpha(false);
            if (cur != src || own) cur.recycle();
            cur = cr;
        }
        return cur;
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    void drawBackground(Canvas c, int W, int H, Bitmap blurSmall) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        switch (bg) {
            case BG_COLOR:
                c.drawColor(c1);
                break;
            case BG_GRADIENT:
                p.setShader(new LinearGradient(0, 0, W * 0.35f, H, c1, c2, Shader.TileMode.CLAMP));
                c.drawRect(0, 0, W, H, p);
                break;
            case BG_BLUR:
                if (blurSmall != null) {
                    // two smooth upscales give a soft, lens-like blur
                    int mw = Math.max(blurSmall.getWidth() * 4, Math.min(W, 64)), mh = Math.max(1, Math.round((float) mw * H / W));
                    Bitmap mid = Bitmap.createScaledBitmap(blurSmall, mw, mh, true);
                    c.drawBitmap(mid, null, new Rect(0, 0, W, H), p);
                    mid.recycle();
                }
                break;
            case BG_PHOTO:
                if (bgPhoto != null) {
                    float s = Math.max((float) W / bgPhoto.getWidth(), (float) H / bgPhoto.getHeight());
                    float sw = W / s, sh = H / s;
                    float l = (bgPhoto.getWidth() - sw) / 2, t = (bgPhoto.getHeight() - sh) / 2;
                    c.drawBitmap(bgPhoto, new Rect(Math.round(l), Math.round(t), Math.round(l + sw), Math.round(t + sh)),
                            new Rect(0, 0, W, H), p);
                }
                break;
        }
    }

    static final int[][] GRADIENTS = {
            {0xFFFF9A8B, 0xFFFF6A88}, {0xFFA18CD1, 0xFFFBC2EB}, {0xFF84FAB0, 0xFF8FD3F4}, {0xFFFCCB90, 0xFFD57EEB},
            {0xFF0F2027, 0xFF2C5364}, {0xFFFFD86F, 0xFFFC6262}, {0xFF43CEA2, 0xFF185A9D}, {0xFF1A0B3D, 0xFFFF4FD8},
            {0xFFFFFFFF, 0xFFD7D2CC}, {0xFF232526, 0xFF414345}};
}
