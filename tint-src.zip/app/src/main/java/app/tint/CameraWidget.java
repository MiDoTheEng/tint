package app.tint;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/** Shared helper for the Photo and Video home-screen widgets. */
final class CameraWidget {
    static final String OPEN_CAMERA = "app.tint.OPEN_CAMERA", OPEN_VIDEO = "app.tint.OPEN_VIDEO";

    static PendingIntent open(Context c, String action, int code) {
        Intent i = new Intent(c, CameraActivity.class).setAction(action)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }
}
