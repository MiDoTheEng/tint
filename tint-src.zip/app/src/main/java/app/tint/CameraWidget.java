package app.tint;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/** Home-screen widget: two buttons that open Tint's camera straight in photo or video mode. */
public class CameraWidget extends AppWidgetProvider {
    static final String OPEN_CAMERA = "app.tint.OPEN_CAMERA", OPEN_VIDEO = "app.tint.OPEN_VIDEO";

    static PendingIntent open(Context c, String action, int code) {
        Intent i = new Intent(c, MainActivity.class).setAction(action)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_camera);
            v.setOnClickPendingIntent(R.id.w_photo, open(c, OPEN_CAMERA, 1));
            v.setOnClickPendingIntent(R.id.w_video, open(c, OPEN_VIDEO, 2));
            m.updateAppWidget(id, v);
        }
    }
}
