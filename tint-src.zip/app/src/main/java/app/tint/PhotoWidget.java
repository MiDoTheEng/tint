package app.tint;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

/** Home-screen widget: opens Tint's camera in Photo mode. */
public class PhotoWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_photo);
            v.setOnClickPendingIntent(R.id.w_photo, CameraWidget.open(c, CameraWidget.OPEN_CAMERA, 1));
            m.updateAppWidget(id, v);
        }
    }
}
