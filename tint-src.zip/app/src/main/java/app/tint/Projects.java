package app.tint;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Projects live in the app's private folder:  files/projects/<id>/
 *   project.json   settings, filter and every text / picture
 *   source         a byte-for-byte copy of the original photo (no quality loss)
 *   s_<key>_o.png  added pictures (original),  s_<key>_b.png  (shown, e.g. background removed)
 *   thumb.jpg      the small preview shown on the start screen
 */
final class Projects {

    static File root(Context c) {
        File f = new File(c.getFilesDir(), "projects");
        f.mkdirs();
        return f;
    }

    static String newId() { return System.currentTimeMillis() + "_" + UUID.randomUUID().toString().substring(0, 6); }

    static File dir(Context c, String id) {
        File d = new File(root(c), id);
        d.mkdirs();
        return d;
    }

    /** Projects, newest first. */
    static List<File> list(Context c) {
        File[] ds = root(c).listFiles(f -> f.isDirectory() && new File(f, "project.json").exists());
        List<File> out = new ArrayList<>();
        if (ds == null) return out;
        out.addAll(Arrays.asList(ds));
        out.sort((a, b) -> Long.compare(new File(b, "project.json").lastModified(), new File(a, "project.json").lastModified()));
        return out;
    }

    static void delete(File dir) {
        File[] fs = dir.listFiles();
        if (fs != null) for (File f : fs) f.delete();
        dir.delete();
    }

    static void copy(InputStream in, File out) throws IOException {
        try (InputStream i = in; OutputStream o = new FileOutputStream(out)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = i.read(buf)) > 0) o.write(buf, 0, n);
        }
    }

    static void writePng(Bitmap b, File f) throws IOException {
        if (f.exists()) return;
        File tmp = new File(f.getPath() + ".tmp");
        try (OutputStream o = new FileOutputStream(tmp)) { b.compress(Bitmap.CompressFormat.PNG, 100, o); }
        tmp.renameTo(f);
    }

    static Bitmap readPng(File f) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inMutable = false;
        return BitmapFactory.decodeFile(f.getPath(), o);
    }

    static void writeText(File f, String s) throws IOException {
        File tmp = new File(f.getPath() + ".tmp");
        try (OutputStream o = new FileOutputStream(tmp)) { o.write(s.getBytes(StandardCharsets.UTF_8)); }
        tmp.renameTo(f);
    }

    static String readText(File f) throws IOException {
        try (InputStream i = new java.io.FileInputStream(f)) {
            java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = i.read(buf)) > 0) b.write(buf, 0, n);
            return b.toString("UTF-8");
        }
    }

    // ------------------------------------------------------------------ items <-> json

    static JSONArray itemsToJson(List<Item> items) throws Exception {
        JSONArray a = new JSONArray();
        for (Item it : items) {
            JSONObject o = new JSONObject();
            o.put("x", it.x).put("y", it.y).put("rot", it.rot).put("size", it.size);
            if (it instanceof TextArt.Layer) {
                TextArt.Layer l = (TextArt.Layer) it;
                o.put("type", "text").put("text", l.text).put("style", l.style).put("color", l.color);
                if (l.font != null) o.put("font", l.font);
            } else if (it instanceof Item.Sticker) {
                Item.Sticker s = (Item.Sticker) it;
                o.put("type", "pic").put("key", s.key).put("outline", s.outline).put("flip", s.flip)
                        .put("cutout", s.cutout).put("opacity", s.opacity);
            }
            a.put(o);
        }
        return a;
    }

    static List<Item> itemsFromJson(File dir, JSONArray a) {
        List<Item> out = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            Item it;
            if ("text".equals(o.optString("type"))) {
                TextArt.Layer l = new TextArt.Layer();
                l.text = o.optString("text");
                l.style = o.optInt("style");
                l.color = o.optInt("color", 0xFFFFFFFF);
                l.font = o.has("font") ? o.optString("font") : null;
                it = l;
            } else {
                String key = o.optString("key");
                Bitmap orig = readPng(new File(dir, "s_" + key + "_o.png"));
                if (orig == null) continue;
                Bitmap shown = readPng(new File(dir, "s_" + key + "_b.png"));
                Item.Sticker s = new Item.Sticker(orig);
                s.setBitmap(shown != null ? shown : orig);
                s.key = key;
                s.flip = o.optBoolean("flip");
                s.cutout = o.optBoolean("cutout");
                s.opacity = (float) o.optDouble("opacity", 1);
                if (o.optBoolean("outline")) { s.setOutline(true); s.key = key; }
                it = s;
            }
            it.x = (float) o.optDouble("x", .5);
            it.y = (float) o.optDouble("y", .5);
            it.rot = (float) o.optDouble("rot", 0);
            it.size = (float) o.optDouble("size", it.size);
            out.add(it);
        }
        return out;
    }

    /** Removes picture files that no item uses any more. */
    static void cleanup(File dir, List<Item> items) {
        Set<String> keep = new HashSet<>();
        for (Item it : items) if (it instanceof Item.Sticker && ((Item.Sticker) it).key != null) keep.add(((Item.Sticker) it).key);
        File[] fs = dir.listFiles((d, n) -> n.startsWith("s_"));
        if (fs == null) return;
        for (File f : fs) {
            String n = f.getName();
            String k = n.substring(2, Math.max(2, n.lastIndexOf('_')));
            if (!keep.contains(k)) f.delete();
        }
    }
}
