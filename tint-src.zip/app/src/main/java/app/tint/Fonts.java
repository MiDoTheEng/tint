package app.tint;

import android.content.Context;
import android.graphics.Typeface;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Open-licence Google Fonts bundled in assets/fonts (downloaded automatically at build time,
 * see app/build.gradle). The list here must match the families listed there.
 */
final class Fonts {
    static final class Font {
        final String key, name, cat;
        Font(String name, String cat) {
            this.name = name;
            this.cat = cat;
            this.key = name.toLowerCase().replaceAll("[^a-z0-9]", "_");
        }
        boolean arabic() { return cat.equals("Arabic"); }
    }

    static final String[] CATEGORIES = {"All", "Arabic", "Script", "Display", "Elegant", "Retro", "Clean"};

    static final Font[] ALL = {
            // Arabic (all of these also contain Latin letters)
            new Font("Cairo", "Arabic"), new Font("Tajawal", "Arabic"), new Font("Almarai", "Arabic"),
            new Font("Amiri", "Arabic"), new Font("Lalezar", "Arabic"), new Font("Reem Kufi", "Arabic"),
            new Font("Aref Ruqaa", "Arabic"), new Font("Changa", "Arabic"), new Font("El Messiri", "Arabic"),
            new Font("Lemonada", "Arabic"), new Font("Mada", "Arabic"), new Font("Markazi Text", "Arabic"),
            new Font("Harmattan", "Arabic"), new Font("Rakkas", "Arabic"), new Font("Katibeh", "Arabic"),
            new Font("Jomhuria", "Arabic"), new Font("Mirza", "Arabic"), new Font("Scheherazade New", "Arabic"),
            new Font("Readex Pro", "Arabic"), new Font("Noto Kufi Arabic", "Arabic"), new Font("Noto Naskh Arabic", "Arabic"),
            new Font("Alexandria", "Arabic"), new Font("Marhey", "Arabic"), new Font("Vibes", "Arabic"),
            new Font("Blaka", "Arabic"), new Font("Kufam", "Arabic"), new Font("Gulzar", "Arabic"),
            new Font("IBM Plex Sans Arabic", "Arabic"), new Font("Baloo Bhaijaan 2", "Arabic"), new Font("Lateef", "Arabic"),
            new Font("Zain", "Arabic"), new Font("Handjet", "Arabic"), new Font("Noto Nastaliq Urdu", "Arabic"),
            new Font("Rubik", "Arabic"),
            // Script & handwriting
            new Font("Pacifico", "Script"), new Font("Lobster", "Script"), new Font("Dancing Script", "Script"),
            new Font("Great Vibes", "Script"), new Font("Satisfy", "Script"), new Font("Caveat", "Script"),
            new Font("Sacramento", "Script"), new Font("Parisienne", "Script"), new Font("Allura", "Script"),
            new Font("Kaushan Script", "Script"), new Font("Yellowtail", "Script"), new Font("Homemade Apple", "Script"),
            new Font("Pinyon Script", "Script"), new Font("Tangerine", "Script"), new Font("Mr Dafoe", "Script"),
            new Font("Shadows Into Light", "Script"), new Font("Indie Flower", "Script"), new Font("Gloria Hallelujah", "Script"),
            new Font("Permanent Marker", "Script"), new Font("Rock Salt", "Script"),
            // Display
            new Font("Bebas Neue", "Display"), new Font("Anton", "Display"), new Font("Oswald", "Display"),
            new Font("Abril Fatface", "Display"), new Font("Righteous", "Display"), new Font("Bungee", "Display"),
            new Font("Alfa Slab One", "Display"), new Font("Staatliches", "Display"), new Font("Russo One", "Display"),
            new Font("Bangers", "Display"), new Font("Lilita One", "Display"), new Font("Fredoka", "Display"),
            new Font("Baloo 2", "Display"), new Font("Unbounded", "Display"), new Font("Syne", "Display"),
            new Font("Black Ops One", "Display"), new Font("Rubik Mono One", "Display"),
            // Elegant
            new Font("Playfair Display", "Elegant"), new Font("Cinzel", "Elegant"), new Font("DM Serif Display", "Elegant"),
            new Font("Bodoni Moda", "Elegant"), new Font("Lora", "Elegant"), new Font("Cormorant Garamond", "Elegant"),
            new Font("Libre Baskerville", "Elegant"), new Font("Prata", "Elegant"),
            // Retro & tech
            new Font("Press Start 2P", "Retro"), new Font("VT323", "Retro"), new Font("Orbitron", "Retro"),
            new Font("Audiowide", "Retro"), new Font("Monoton", "Retro"), new Font("Special Elite", "Retro"),
            new Font("Space Mono", "Retro"), new Font("Major Mono Display", "Retro"), new Font("Creepster", "Retro"),
            new Font("Silkscreen", "Retro"),
            // Clean
            new Font("Poppins", "Clean"), new Font("Montserrat", "Clean"), new Font("Raleway", "Clean"),
            new Font("Comfortaa", "Clean"), new Font("Nunito", "Clean"), new Font("Quicksand", "Clean"),
            new Font("Josefin Sans", "Clean"), new Font("Archivo Black", "Clean"),
    };

    private static Context app;
    private static Set<String> present;
    private static final Map<String, Typeface> cache = new HashMap<>();

    static void init(Context c) {
        app = c.getApplicationContext();
        present = new HashSet<>();
        try {
            String[] files = app.getAssets().list("fonts");
            if (files != null) present.addAll(Arrays.asList(files));
        } catch (Exception ignored) { }
    }

    /** Fonts that actually made it into this build. */
    static List<Font> available(String cat) {
        List<Font> out = new ArrayList<>();
        for (Font f : ALL)
            if (present != null && present.contains(f.key + ".ttf") && (cat.equals("All") || f.cat.equals(cat)))
                out.add(f);
        return out;
    }

    static Font byKey(String key) {
        for (Font f : ALL) if (f.key.equals(key)) return f;
        return null;
    }

    static synchronized Typeface get(String key) {
        if (key == null || app == null) return null;
        Typeface t = cache.get(key);
        if (t == null) {
            try {
                t = Typeface.createFromAsset(app.getAssets(), "fonts/" + key + ".ttf");
            } catch (Exception e) {
                t = Typeface.DEFAULT;
            }
            cache.put(key, t);
        }
        return t;
    }
}
