package app.tint;

import android.graphics.*;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;

/**
 * Text layers and their styles. Uses only system fonts, so it stays light and
 * Arabic (and any other script) is shaped and laid out right-to-left automatically.
 */
final class TextArt {

    static final class Layer {
        String text = "";
        int style = 0;
        int color = Color.WHITE;
        float size = 0.085f;      // text size as a fraction of image width
        float x = 0.5f, y = 0.5f; // centre, as fractions of image size
        final RectF bounds = new RectF();

        Layer copy() {
            Layer l = new Layer();
            l.text = text; l.style = style; l.color = color; l.size = size; l.x = x; l.y = y;
            return l;
        }
    }

    static final String[] STYLES = {"Clean", "Bold", "Neon", "Outline", "Box", "Retro", "Serif", "Script", "Label", "Stamp", "3D", "Glow"};

    static final int[] COLORS = {0xFFFFFFFF, 0xFF0A0A0A, 0xFFFF4D2E, 0xFFFFD23F, 0xFFFF7AC6, 0xFF7C4DFF,
            0xFF3DE8FF, 0xFF2EE59D, 0xFFFF9A2E, 0xFFFFF1D6, 0xFF1E3A8A, 0xFFE11D48};

    static Typeface typeface(int style) {
        switch (style) {
            case 1: case 10: return Typeface.create("sans-serif-black", Typeface.NORMAL);
            case 5: return Typeface.create("sans-serif-black", Typeface.ITALIC);
            case 6: return Typeface.create("serif", Typeface.ITALIC);
            case 7: return Typeface.create("cursive", Typeface.BOLD);
            case 8: case 9: return Typeface.create(Typeface.MONOSPACE, Typeface.BOLD);
            case 3: return Typeface.create("sans-serif-black", Typeface.NORMAL);
            default: return Typeface.create("sans-serif-medium", Typeface.NORMAL);
        }
    }

    private static int darker(int c, float k) {
        return Color.rgb((int) (Color.red(c) * k), (int) (Color.green(c) * k), (int) (Color.blue(c) * k));
    }

    private static int lighter(int c, float k) {
        return Color.rgb(Color.red(c) + (int) ((255 - Color.red(c)) * k),
                Color.green(c) + (int) ((255 - Color.green(c)) * k),
                Color.blue(c) + (int) ((255 - Color.blue(c)) * k));
    }

    private static boolean isLight(int c) {
        return (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000 > 150;
    }

    /** Draws one layer onto an image-sized canvas (w x h) and stores its bounds. */
    static void draw(Canvas c, int w, int h, Layer t) {
        String text = t.text.isEmpty() ? " " : t.text;
        float size = Math.max(4, t.size * w);
        TextPaint p = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        p.setTypeface(typeface(t.style));
        p.setTextSize(size);
        p.setColor(t.color);

        int maxW = (int) (w * 0.9f);
        float desired = 0;
        for (String line : text.split("\n", -1)) desired = Math.max(desired, Layout.getDesiredWidth(line, p));
        int lw = Math.max(1, Math.min(maxW, (int) Math.ceil(desired) + 2));
        StaticLayout lay = StaticLayout.Builder.obtain(text, 0, text.length(), p, lw)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setIncludePad(false)
                .build();
        float lh = lay.getHeight();
        float left = t.x * w - lw / 2f, top = t.y * h - lh / 2f;
        float pad = size * 0.35f;
        t.bounds.set(left - pad, top - pad, left + lw + pad, top + lh + pad);

        c.save();
        c.translate(left, top);
        switch (t.style) {
            case 0: // Clean
                p.setShadowLayer(size * 0.12f, 0, size * 0.03f, 0x80000000);
                lay.draw(c);
                break;
            case 1: // Bold
                p.setShadowLayer(size * 0.02f, size * 0.05f, size * 0.05f, 0xB0000000);
                lay.draw(c);
                break;
            case 2: // Neon
                p.setColor(t.color);
                p.setShadowLayer(size * 0.6f, 0, 0, t.color);
                lay.draw(c);
                p.setShadowLayer(size * 0.25f, 0, 0, t.color);
                lay.draw(c);
                p.setColor(lighter(t.color, 0.75f));
                p.setShadowLayer(size * 0.06f, 0, 0, t.color);
                lay.draw(c);
                break;
            case 3: // Outline
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeJoin(Paint.Join.ROUND);
                p.setStrokeWidth(size * 0.055f);
                p.setShadowLayer(size * 0.1f, 0, 0, 0x60000000);
                lay.draw(c);
                break;
            case 4: { // Box
                Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
                bg.setColor(t.color);
                float r = size * 0.3f, bp = size * 0.28f;
                for (int i = 0; i < lay.getLineCount(); i++) {
                    if (lay.getLineRight(i) - lay.getLineLeft(i) < 1) continue;
                    c.drawRoundRect(new RectF(lay.getLineLeft(i) - bp, lay.getLineTop(i) - bp * 0.5f,
                            lay.getLineRight(i) + bp, lay.getLineBottom(i) + bp * 0.5f), r, r, bg);
                }
                p.setColor(isLight(t.color) ? 0xFF111111 : Color.WHITE);
                lay.draw(c);
                break;
            }
            case 5: { // Retro: hard shadow + gradient
                p.setColor(darker(t.color, 0.35f));
                c.save();
                c.translate(size * 0.07f, size * 0.07f);
                lay.draw(c);
                c.restore();
                p.setShader(new LinearGradient(0, 0, 0, lh,
                        new int[]{lighter(t.color, 0.55f), t.color, darker(t.color, 0.8f)}, null, Shader.TileMode.CLAMP));
                p.setColor(Color.WHITE);
                lay.draw(c);
                p.setShader(null);
                break;
            }
            case 6: // Serif
            case 7: // Script
                p.setShadowLayer(size * 0.2f, 0, size * 0.04f, 0x99000000);
                lay.draw(c);
                break;
            case 8: { // Label tape
                Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
                bg.setColor(t.color);
                bg.setShadowLayer(size * 0.15f, 0, size * 0.05f, 0x55000000);
                c.drawRect(-pad * 0.6f, -pad * 0.4f, lw + pad * 0.6f, lh + pad * 0.4f, bg);
                p.setColor(isLight(t.color) ? 0xFF111111 : Color.WHITE);
                lay.draw(c);
                break;
            }
            case 9: // Stamp
                p.setShadowLayer(size * 0.35f, 0, 0, (t.color & 0x00FFFFFF) | 0xCC000000);
                lay.draw(c);
                break;
            case 10: { // 3D
                p.setColor(darker(t.color, 0.45f));
                float step = size * 0.018f;
                for (int i = 7; i >= 1; i--) {
                    c.save();
                    c.translate(step * i, step * i);
                    lay.draw(c);
                    c.restore();
                }
                p.setColor(t.color);
                lay.draw(c);
                break;
            }
            case 11: // Glow
                p.setShadowLayer(size * 0.45f, 0, 0, 0xEEFFFFFF);
                lay.draw(c);
                break;
        }
        c.restore();
    }
}
