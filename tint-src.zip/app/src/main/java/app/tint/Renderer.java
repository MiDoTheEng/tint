package app.tint;

import android.graphics.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Applies a Filter using Canvas/ColorMatrix (no libraries).
 * Everything is drawn in whole-image coordinates, so the same pipeline works for a
 * small preview and for a full-resolution photo processed in horizontal bands
 * (low memory, no quality loss).
 */
final class Renderer {
    private static Bitmap noise;

    /** Per-image data computed once (from a small copy) and shared by every band. */
    static final class Ctx {
        Bitmap pix;          // pixelate source
        Bitmap glow;         // tiny blurred copy for bloom
        float[] stars;       // sparkle points: x, y (0..1), strength
        int[] lut;           // 256-entry gradient map
    }

    private static synchronized Bitmap noise() {
        if (noise == null) {
            int n = 192;
            int[] px = new int[n * n];
            Random r = new Random(7);
            for (int i = 0; i < px.length; i++) {
                int v = (int) (128 + r.nextGaussian() * 38);
                v = Math.max(0, Math.min(255, v));
                px[i] = 0xFF000000 | (v << 16) | (v << 8) | v;
            }
            noise = Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888);
        }
        return noise;
    }

    private static int a(float v) { return (int) (255 * Math.max(0, Math.min(1, v))); }

    // ------------------------------------------------------------------ colour

    static ColorMatrix matrix(Filter f) {
        ColorMatrix cm = new ColorMatrix();
        if (f.swap) cm.set(new float[]{0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0});

        float r = f.r * (1 + f.warm * 0.14f);
        float g = f.g * (1 - f.tint * 0.10f);
        float b = f.b * (1 - f.warm * 0.14f);
        ColorMatrix gain = new ColorMatrix();
        gain.setScale(r, g, b, 1);
        cm.postConcat(gain);

        if (f.hue != 0) cm.postConcat(hue(f.hue));

        ColorMatrix s = new ColorMatrix();
        s.setSaturation(f.mono ? 0 : f.sat);
        cm.postConcat(s);

        if (f.sepia > 0) {
            float k = f.sepia;
            float[] sp = {0.393f, 0.769f, 0.189f, 0, 0,
                          0.349f, 0.686f, 0.168f, 0, 0,
                          0.272f, 0.534f, 0.131f, 0, 0,
                          0, 0, 0, 1, 0};
            float[] m = new float[20];
            for (int i = 0; i < 20; i++) {
                float id = (i == 0 || i == 6 || i == 12 || i == 18) ? 1 : 0;
                m[i] = id * (1 - k) + sp[i] * k;
            }
            cm.postConcat(new ColorMatrix(m));
        }

        float c = f.con, t = 128f * (1 - c) + f.bri * 255f;
        cm.postConcat(new ColorMatrix(new float[]{
                c, 0, 0, 0, t, 0, c, 0, 0, t, 0, 0, c, 0, t, 0, 0, 0, 1, 0}));

        if (f.fade > 0) {
            float k = 1 - f.fade * 0.28f, o = f.fade * 58f;
            cm.postConcat(new ColorMatrix(new float[]{
                    k, 0, 0, 0, o, 0, k, 0, 0, o, 0, 0, k, 0, o, 0, 0, 0, 1, 0}));
        }
        if (f.invert) {
            cm.postConcat(new ColorMatrix(new float[]{
                    -1, 0, 0, 0, 255, 0, -1, 0, 0, 255, 0, 0, -1, 0, 255, 0, 0, 0, 1, 0}));
        }
        if (f.duo) {
            float[] m = new float[20];
            int[] lo = {Color.red(f.duoLo), Color.green(f.duoLo), Color.blue(f.duoLo)};
            int[] hi = {Color.red(f.duoHi), Color.green(f.duoHi), Color.blue(f.duoHi)};
            for (int i = 0; i < 3; i++) {
                float d = (hi[i] - lo[i]) / 255f;
                m[i * 5] = d * 0.299f; m[i * 5 + 1] = d * 0.587f; m[i * 5 + 2] = d * 0.114f;
                m[i * 5 + 4] = lo[i];
            }
            m[18] = 1;
            cm.postConcat(new ColorMatrix(m));
        }
        return cm;
    }

    private static ColorMatrix hue(float deg) {
        double rad = Math.toRadians(deg);
        float cos = (float) Math.cos(rad), sin = (float) Math.sin(rad);
        float lr = 0.213f, lg = 0.715f, lb = 0.072f;
        return new ColorMatrix(new float[]{
                lr + cos * (1 - lr) + sin * (-lr), lg + cos * (-lg) + sin * (-lg), lb + cos * (-lb) + sin * (1 - lb), 0, 0,
                lr + cos * (-lr) + sin * 0.143f, lg + cos * (1 - lg) + sin * 0.140f, lb + cos * (-lb) + sin * -0.283f, 0, 0,
                lr + cos * (-lr) + sin * (-(1 - lr)), lg + cos * (-lg) + sin * lg, lb + cos * (1 - lb) + sin * lb, 0, 0,
                0, 0, 0, 1, 0});
    }

    private static int[] buildLut(int[] cols) {
        int[] lut = new int[256];
        int n = cols.length - 1;
        for (int i = 0; i < 256; i++) {
            float p = i / 255f * n;
            int k = Math.min(n - 1, (int) p);
            float t = p - k;
            int c0 = cols[k], c1 = cols[k + 1];
            int r = (int) (Color.red(c0) + (Color.red(c1) - Color.red(c0)) * t);
            int g = (int) (Color.green(c0) + (Color.green(c1) - Color.green(c0)) * t);
            int b = (int) (Color.blue(c0) + (Color.blue(c1) - Color.blue(c0)) * t);
            lut[i] = (r << 16) | (g << 8) | b;
        }
        return lut;
    }

    /** Gradient map + posterize, on the first `rows` rows of bmp. */
    private static void pixelPass(Bitmap bmp, int rows, Filter f, Ctx ctx, int[] buf) {
        int w = bmp.getWidth();
        int[] px = (buf != null && buf.length >= w * rows) ? buf : new int[w * rows];
        bmp.getPixels(px, 0, w, 0, 0, w, rows);
        int levels = f.poster;
        float step = levels > 1 ? 255f / (levels - 1) : 0;
        int mix = (int) (256 * f.gradMix);
        for (int i = 0, n = w * rows; i < n; i++) {
            int c = px[i];
            int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
            if (ctx.lut != null) {
                int l = (r * 77 + g * 150 + b * 29) >> 8;
                int m = ctx.lut[l];
                r += (((m >> 16) & 255) - r) * mix >> 8;
                g += (((m >> 8) & 255) - g) * mix >> 8;
                b += ((m & 255) - b) * mix >> 8;
            }
            if (levels > 1) {
                r = Math.round(Math.round(r / step) * step);
                g = Math.round(Math.round(g / step) * step);
                b = Math.round(Math.round(b / step) * step);
            }
            px[i] = 0xFF000000 | (Math.min(255, r) << 16) | (Math.min(255, g) << 8) | Math.min(255, b);
        }
        bmp.setPixels(px, 0, w, 0, 0, w, rows);
    }

    // ------------------------------------------------------------------ helpers

    /** Good-quality downscale (repeated halving). */
    static Bitmap scaleDown(Bitmap src, int tw, int th) {
        Bitmap cur = src;
        while (cur.getWidth() / 2 >= tw && cur.getHeight() / 2 >= th) {
            Bitmap nx = Bitmap.createScaledBitmap(cur, cur.getWidth() / 2, cur.getHeight() / 2, true);
            if (cur != src) cur.recycle();
            cur = nx;
        }
        Bitmap out = Bitmap.createScaledBitmap(cur, Math.max(1, tw), Math.max(1, th), true);
        if (cur != src && cur != out) cur.recycle();
        return out;
    }

    private static Bitmap fit(Bitmap src, int longSide) {
        int w = src.getWidth(), h = src.getHeight();
        float s = (float) longSide / Math.max(w, h);
        if (s >= 1) return src.copy(Bitmap.Config.ARGB_8888, false);
        return scaleDown(src, Math.max(1, Math.round(w * s)), Math.max(1, Math.round(h * s)));
    }

    static Ctx prepare(Bitmap src, Filter f) {
        Ctx ctx = new Ctx();
        int w = src.getWidth(), h = src.getHeight();
        if (f.grad != null) ctx.lut = buildLut(f.grad);
        if (f.pixel > 0) {
            int bw = Math.max(2, f.pixel), bh = Math.max(2, Math.round((float) f.pixel * h / w));
            ctx.pix = scaleDown(src, bw, bh);
        }
        if (f.glow > 0 || f.sparkle > 0) {
            Bitmap small = fit(src, 160);
            int sw = small.getWidth(), sh = small.getHeight();
            Bitmap prepped = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888);
            Ctx sub = new Ctx();
            sub.lut = ctx.lut;
            stage1(new Canvas(prepped), prepped, sh, small, f, sub, sw, sh, null);
            small.recycle();
            if (f.glow > 0) ctx.glow = fit(prepped, 40);
            if (f.sparkle > 0) ctx.stars = findStars(prepped, f.sparkle);
            prepped.recycle();
        }
        return ctx;
    }

    private static float[] findStars(Bitmap b, float amount) {
        int w = b.getWidth(), h = b.getHeight();
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        int cell = 8;
        List<float[]> pts = new ArrayList<>();
        for (int cy = 0; cy < h; cy += cell)
            for (int cx = 0; cx < w; cx += cell) {
                int best = -1, bx = 0, by = 0;
                for (int y = cy; y < Math.min(h, cy + cell); y++)
                    for (int x = cx; x < Math.min(w, cx + cell); x++) {
                        int c = px[y * w + x];
                        int l = (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 150 + (c & 255) * 29) >> 8;
                        if (l > best) { best = l; bx = x; by = y; }
                    }
                if (best > 175) pts.add(new float[]{(bx + .5f) / w, (by + .5f) / h, (best - 175) / 80f});
            }
        pts.sort((p, q) -> Float.compare(q[2], p[2]));
        int max = (int) (10 + amount * 30);
        if (pts.isEmpty()) {                       // dark photo: sprinkle a few anyway
            Random r = new Random(5);
            for (int i = 0; i < 8; i++) pts.add(new float[]{r.nextFloat(), r.nextFloat() * .6f, .5f});
        }
        int n = Math.min(max, pts.size());
        float[] out = new float[n * 3];
        for (int i = 0; i < n; i++) System.arraycopy(pts.get(i), 0, out, i * 3, 3);
        return out;
    }

    private static void drawImg(Canvas c, Bitmap s, Paint p, int w, int h, float dx) {
        if (s.getWidth() == w && s.getHeight() == h) c.drawBitmap(s, dx, 0, p);
        else c.drawBitmap(s, null, new RectF(dx, 0, dx + w, h), p);
    }

    private static void drawMirrored(Canvas c, Bitmap s, Paint p, Filter f, int w, int h, float dx) {
        if (f.mirror == 0) { drawImg(c, s, p, w, h, dx); return; }
        float cx = w / 2f, cy = h / 2f;
        boolean horiz = f.mirror == 1 || f.mirror == 3, vert = f.mirror == 2 || f.mirror == 3;
        for (int i = 0; i < 4; i++) {
            boolean right = (i & 1) == 1, bottom = (i & 2) == 2;
            if (right && !horiz) continue;
            if (bottom && !vert) continue;
            c.save();
            float l = horiz ? (right ? cx : 0) : 0, rr = horiz ? (right ? w : cx) : w;
            float t = vert ? (bottom ? cy : 0) : 0, bb = vert ? (bottom ? h : cy) : h;
            c.clipRect(l, t, rr, bb);
            c.scale(right ? -1 : 1, bottom ? -1 : 1, cx, cy);
            drawImg(c, s, p, w, h, dx);
            c.restore();
        }
    }

    // ------------------------------------------------------------------ pipeline

    /** Base image + colour + pixel effects + wash. `target` receives rows y0..y0+rows. */
    private static void stage1(Canvas c, Bitmap target, int rows, Bitmap src, Filter f, Ctx ctx,
                               int w, int h, int[] buf) {
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        Bitmap s = src;
        if (ctx.pix != null) { s = ctx.pix; p.setFilterBitmap(false); p.setAntiAlias(false); }
        ColorMatrix cm = matrix(f);

        if (f.split > 0) {
            c.drawColor(Color.BLACK);
            float d = f.split * w;
            float[] off = {-d, 0, d};
            p.setBlendMode(BlendMode.PLUS);
            for (int i = 0; i < 3; i++) {
                float[] iso = new float[20];
                iso[i * 6] = 1;
                iso[18] = 1;
                ColorMatrix m = new ColorMatrix(cm);
                m.postConcat(new ColorMatrix(iso));
                p.setColorFilter(new ColorMatrixColorFilter(m));
                drawMirrored(c, s, p, f, w, h, off[i]);
            }
            p.setBlendMode(null);
        } else {
            p.setColorFilter(new ColorMatrixColorFilter(cm));
            drawMirrored(c, s, p, f, w, h, 0);
        }

        if (f.needsPixels()) pixelPass(target, rows, f, ctx, buf);

        if (f.ovA > 0) {
            Paint op = new Paint();
            op.setColor(f.ovColor);
            op.setAlpha(a(f.ovA));
            op.setBlendMode(f.ovMode);
            c.drawRect(0, 0, w, h, op);
        }
    }

    private static void pipeline(Canvas c, Bitmap target, int rows, Bitmap src, Filter f, Ctx ctx,
                                 int w, int h, int[] buf) {
        stage1(c, target, rows, src, f, ctx, w, h, buf);

        if (ctx.glow != null) {
            Paint gp = new Paint(Paint.FILTER_BITMAP_FLAG);
            gp.setColorFilter(new ColorMatrixColorFilter(new ColorMatrix(new float[]{
                    1.6f, 0, 0, 0, -90, 0, 1.6f, 0, 0, -90, 0, 0, 1.6f, 0, -90, 0, 0, 0, 1, 0})));
            gp.setBlendMode(BlendMode.SCREEN);
            gp.setAlpha(a(f.glow));
            c.drawBitmap(ctx.glow, null, new RectF(0, 0, w, h), gp);
        }

        if (f.leak > 0) {
            float R = Math.max(w, h) * 0.85f;
            int clear = f.leakColor & 0x00FFFFFF;
            Paint lp = new Paint(Paint.ANTI_ALIAS_FLAG);
            lp.setBlendMode(BlendMode.SCREEN);
            lp.setShader(new RadialGradient(w * 0.02f, h * 0.12f, R,
                    new int[]{f.leakColor, clear | 0x55000000, clear}, new float[]{0, 0.35f, 1}, Shader.TileMode.CLAMP));
            lp.setAlpha(a(f.leak));
            c.drawRect(0, 0, w, h, lp);
            lp.setShader(new RadialGradient(w, h * 0.95f, R * 0.6f,
                    new int[]{f.leakColor, clear}, null, Shader.TileMode.CLAMP));
            lp.setAlpha(a(f.leak * 0.5f));
            c.drawRect(0, 0, w, h, lp);
        }

        if (f.rainbow > 0) {
            Paint rp = new Paint(Paint.ANTI_ALIAS_FLAG);
            rp.setShader(new LinearGradient(w * 0.15f, 0, w * 0.85f, h,
                    new int[]{0x00FF0000, 0xFFFF3B3B, 0xFFFFC93B, 0xFF5BFF6B, 0xFF3BD5FF, 0xFF7A5BFF, 0xFFFF5BD8, 0x00FF5BD8},
                    new float[]{0.28f, 0.36f, 0.42f, 0.48f, 0.54f, 0.60f, 0.66f, 0.74f}, Shader.TileMode.CLAMP));
            rp.setBlendMode(BlendMode.SCREEN);
            rp.setAlpha(a(f.rainbow));
            c.drawRect(0, 0, w, h, rp);
        }

        if (f.vig > 0) {
            Paint vp = new Paint(Paint.ANTI_ALIAS_FLAG);
            float R = (float) Math.hypot(w, h) / 2f;
            vp.setShader(new RadialGradient(w / 2f, h / 2f, R,
                    new int[]{0, 0, 0xFF000000}, new float[]{0, 0.5f, 1}, Shader.TileMode.CLAMP));
            vp.setAlpha(a(f.vig));
            c.drawRect(0, 0, w, h, vp);
        }

        if (f.scan > 0) {
            Paint sp = new Paint();
            sp.setColor(Color.BLACK);
            sp.setAlpha(a(f.scan));
            float step = Math.max(2f, h / 320f);
            for (float y = 0; y < h; y += step) c.drawRect(0, y, w, y + step * 0.45f, sp);
        }

        if (f.grain > 0) {
            Paint np = new Paint(Paint.FILTER_BITMAP_FLAG);
            BitmapShader bs = new BitmapShader(noise(), Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
            float s = Math.max(1f, w / 1500f);
            Matrix m = new Matrix();
            m.setScale(s, s);
            bs.setLocalMatrix(m);
            np.setShader(bs);
            np.setBlendMode(BlendMode.OVERLAY);
            np.setAlpha(a(f.grain));
            c.drawRect(0, 0, w, h, np);
        }

        if (f.dust > 0) {
            Random r = new Random(11);
            Paint dp = new Paint(Paint.ANTI_ALIAS_FLAG);
            float u = w / 1000f;
            int n = (int) (f.dust * 90);
            for (int i = 0; i < n; i++) {
                dp.setColor(r.nextFloat() < 0.7f ? Color.WHITE : Color.BLACK);
                dp.setAlpha(60 + r.nextInt(120));
                float x = r.nextFloat() * w, y = r.nextFloat() * h;
                if (r.nextFloat() < 0.12f) {
                    dp.setStyle(Paint.Style.STROKE);
                    dp.setStrokeWidth(Math.max(0.6f, u * 1.2f));
                    Path path = new Path();
                    path.moveTo(x, y);
                    path.quadTo(x + (r.nextFloat() - .5f) * 40 * u, y + (r.nextFloat() - .5f) * 40 * u,
                            x + (r.nextFloat() - .5f) * 70 * u, y + (r.nextFloat() - .5f) * 70 * u);
                    c.drawPath(path, dp);
                } else {
                    dp.setStyle(Paint.Style.FILL);
                    c.drawCircle(x, y, Math.max(0.5f, (0.6f + r.nextFloat() * 2.2f) * u), dp);
                }
            }
        }

        if (ctx.stars != null) drawStars(c, ctx.stars, f.sparkle, w, h);

        if (f.bars) {
            float target2 = w / 2.39f;
            if (target2 < h) {
                float bh = (h - target2) / 2f;
                Paint bp = new Paint();
                bp.setColor(Color.BLACK);
                c.drawRect(0, 0, w, bh, bp);
                c.drawRect(0, h - bh, w, h, bp);
            }
        }

        if (f.frame > 0) drawFrame(c, f.frame, w, h);

        if (f.date) {
            String s = new SimpleDateFormat("''yy  MM  dd", Locale.US).format(new Date());
            Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
            tp.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            float size = Math.min(w, h) * 0.055f;
            tp.setTextSize(size);
            tp.setColor(0xFFFF9A2E);
            tp.setShadowLayer(size * 0.35f, 0, 0, 0xCCFF5A00);
            tp.setTextAlign(Paint.Align.RIGHT);
            float inset = f.frame == 1 ? Math.min(w, h) * 0.16f : size * 1.1f;
            c.drawText(s, w - size * 1.1f - (f.frame > 0 ? Math.min(w, h) * 0.04f : 0), h - inset, tp);
        }
    }

    private static void drawStars(Canvas c, float[] st, float amount, int w, int h) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float base = Math.min(w, h) * (0.025f + 0.03f * amount);
        for (int i = 0; i < st.length; i += 3) {
            float x = st[i] * w, y = st[i + 1] * h, k = Math.max(.35f, Math.min(1, st[i + 2]));
            float L = base * (0.5f + 0.7f * k) * (0.7f + ((i * 37) % 10) / 15f);
            p.setShader(new RadialGradient(x, y, L * 0.45f, new int[]{0xCCFFFFFF, 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
            c.drawCircle(x, y, L * 0.45f, p);
            p.setShader(new RadialGradient(x, y, L, new int[]{0xFFFFFFFF, 0xAAFFFFFF, 0x00FFFFFF},
                    new float[]{0, .3f, 1}, Shader.TileMode.CLAMP));
            c.drawPath(star(x, y, L, L * 0.06f), p);
            c.save();
            c.rotate(45, x, y);
            c.drawPath(star(x, y, L * 0.45f, L * 0.04f), p);
            c.restore();
        }
    }

    private static Path star(float x, float y, float L, float t) {
        Path s = new Path();
        s.moveTo(x - L, y); s.lineTo(x - t, y - t); s.lineTo(x, y - L); s.lineTo(x + t, y - t);
        s.lineTo(x + L, y); s.lineTo(x + t, y + t); s.lineTo(x, y + L); s.lineTo(x - t, y + t);
        s.close();
        return s;
    }

    private static void drawFrame(Canvas c, int type, int w, int h) {
        float m = Math.min(w, h);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Path border = new Path();
        border.setFillType(Path.FillType.EVEN_ODD);
        border.addRect(0, 0, w, h, Path.Direction.CW);
        if (type == 1) {               // instant
            float t = m * 0.045f, bottom = m * 0.16f;
            border.addRect(t, t, w - t, h - bottom, Path.Direction.CW);
            p.setColor(0xFFF7F5F0);
            c.drawPath(border, p);
        } else {                       // film
            float t = m * 0.035f;
            border.addRoundRect(new RectF(t, t, w - t, h - t), t * 0.4f, t * 0.4f, Path.Direction.CW);
            p.setColor(0xFF0B0B0B);
            c.drawPath(border, p);
            p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            p.setTextSize(t * 0.55f);
            p.setColor(0xFFFF9A2E);
            c.drawText("TINT  400  ▸ 12", t * 1.4f, h - t * 0.3f, p);
        }
    }

    // ------------------------------------------------------------------ public API

    /** Whole-bitmap render (preview & thumbnails). Returns a new bitmap. */
    static Bitmap render(Bitmap src, Filter f) {
        int w = src.getWidth(), h = src.getHeight();
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Ctx ctx = prepare(src, f);
        Canvas c = new Canvas(out);
        pipeline(c, out, h, src, f, ctx, w, h, null);
        if (src.hasAlpha()) keepAlpha(c, src);
        recycle(ctx);
        return out;
    }

    /** Full-resolution, in place, processed in bands so huge photos don't run out of memory. */
    static void applyFull(Bitmap src, Filter f, float k) {
        int w = src.getWidth(), h = src.getHeight();
        Ctx ctx = prepare(src, f);
        int bh = Math.max(32, Math.min(h, 2_000_000 / w));
        Bitmap band = Bitmap.createBitmap(w, bh, Bitmap.Config.ARGB_8888);
        int[] buf = f.needsPixels() ? new int[w * bh] : null;
        Canvas out = new Canvas(src);
        Paint bp = new Paint();
        bp.setAlpha(a(k));
        // Mirror effects read the top half, so go bottom-up: rows are read before they are replaced.
        int count = (h + bh - 1) / bh;
        for (int i = count - 1; i >= 0; i--) {
            int y0 = i * bh, rows = Math.min(bh, h - y0);
            band.eraseColor(Color.TRANSPARENT);
            Canvas c = new Canvas(band);
            c.clipRect(0, 0, w, rows);
            c.translate(0, -y0);
            pipeline(c, band, rows, src, f, ctx, w, h, buf);
            if (src.hasAlpha()) keepAlpha(c, src);
            out.drawBitmap(band, new Rect(0, 0, w, rows), new Rect(0, y0, w, y0 + rows), bp);
        }
        band.recycle();
        recycle(ctx);
    }

    /** Transparent canvases stay transparent: effects only show where the image has pixels. */
    private static void keepAlpha(Canvas c, Bitmap src) {
        Paint m = new Paint();
        m.setBlendMode(BlendMode.DST_IN);
        c.drawBitmap(src, 0, 0, m);
    }

    private static void recycle(Ctx ctx) {
        if (ctx.pix != null) ctx.pix.recycle();
        if (ctx.glow != null) ctx.glow.recycle();
    }

    /** High-quality square thumbnail (centre crop). */
    static Bitmap thumb(Bitmap s, int size) {
        int m = Math.min(s.getWidth(), s.getHeight());
        int x = (s.getWidth() - m) / 2, y = (s.getHeight() - m) / 2;
        Bitmap sq = Bitmap.createBitmap(s, x, y, m, m);
        Bitmap out = scaleDown(sq, size, size);
        if (sq != s && sq != out) sq.recycle();
        return out;
    }

    /** Built-in sunset scene so the app looks alive before a photo is opened. */
    static Bitmap sample(int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, 0, h * 0.62f,
                new int[]{0xFF2B3A67, 0xFF8E6C9A, 0xFFF2A07B, 0xFFFCD9A8},
                new float[]{0, .45f, .8f, 1}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(new RadialGradient(w * .62f, h * .5f, w * .32f,
                new int[]{0xFFFFF4D6, 0x88FFE2B0, 0x00FFE2B0}, new float[]{0, .25f, 1}, Shader.TileMode.CLAMP));
        c.drawCircle(w * .62f, h * .5f, w * .32f, p);
        p.setShader(null);
        p.setColor(0xFFFFF7E6);
        c.drawCircle(w * .62f, h * .5f, w * .07f, p);
        int[] cols = {0xFF6E5A87, 0xFF3E3F6B, 0xFF1E2140};
        float[] base = {.58f, .68f, .80f};
        for (int i = 0; i < 3; i++) {
            float y = h * base[i];
            Path path = new Path();
            path.moveTo(0, y);
            path.cubicTo(w * .25f, y - h * .08f, w * .45f, y + h * .05f, w * .7f, y - h * .02f);
            path.cubicTo(w * .85f, y - h * .06f, w * .95f, y, w, y - h * .03f);
            path.lineTo(w, h);
            path.lineTo(0, h);
            path.close();
            p.setColor(cols[i]);
            c.drawPath(path, p);
        }
        return b;
    }
}
