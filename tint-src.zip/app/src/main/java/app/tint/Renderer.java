package app.tint;

import android.graphics.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

/** Applies a Filter to a bitmap using only Canvas/ColorMatrix (fast, no libraries). */
final class Renderer {
    private static Bitmap noise;

    private static synchronized Bitmap noise() {
        if (noise == null) {
            int n = 192;
            int[] px = new int[n * n];
            Random r = new Random(7);
            for (int i = 0; i < px.length; i++) {
                int v = (int) (128 + r.nextGaussian() * 38);
                v = Math.max(0, Math.min(255, v));
                px[i] = 0xFF000000 | (v << 16) | (v << 8) | v;
            }
            noise = Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888);
        }
        return noise;
    }

    static ColorMatrix matrix(Filter f) {
        ColorMatrix cm = new ColorMatrix();
        float r = f.r * (1 + f.warm * 0.14f);
        float g = f.g * (1 - f.tint * 0.10f);
        float b = f.b * (1 - f.warm * 0.14f);
        cm.setScale(r, g, b, 1);

        ColorMatrix s = new ColorMatrix();
        s.setSaturation(f.mono ? 0 : f.sat);
        cm.postConcat(s);

        if (f.sepia > 0) {
            float k = f.sepia;
            float[] sp = {0.393f, 0.769f, 0.189f, 0, 0,
                          0.349f, 0.686f, 0.168f, 0, 0,
                          0.272f, 0.534f, 0.131f, 0, 0,
                          0, 0, 0, 1, 0};
            float[] m = new float[20];
            for (int i = 0; i < 20; i++) {
                float id = (i == 0 || i == 6 || i == 12 || i == 18) ? 1 : 0;
                m[i] = id * (1 - k) + sp[i] * k;
            }
            cm.postConcat(new ColorMatrix(m));
        }

        float c = f.con, t = 128f * (1 - c) + f.bri * 255f;
        cm.postConcat(new ColorMatrix(new float[]{
                c, 0, 0, 0, t,
                0, c, 0, 0, t,
                0, 0, c, 0, t,
                0, 0, 0, 1, 0}));

        if (f.fade > 0) {
            float k = 1 - f.fade * 0.28f, o = f.fade * 58f;
            cm.postConcat(new ColorMatrix(new float[]{
                    k, 0, 0, 0, o,
                    0, k, 0, 0, o,
                    0, 0, k, 0, o,
                    0, 0, 0, 1, 0}));
        }
        return cm;
    }

    private static int a(float v) { return (int) (255 * Math.max(0, Math.min(1, v))); }

    /** Returns a new bitmap with the full-strength look applied. */
    static Bitmap render(Bitmap src, Filter f) {
        int w = src.getWidth(), h = src.getHeight();
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        ColorMatrix cm = matrix(f);

        if (f.split > 0) {
            c.drawColor(Color.BLACK);
            float d = f.split * w;
            float[] off = {-d, 0, d};
            p.setBlendMode(BlendMode.PLUS);
            for (int i = 0; i < 3; i++) {
                float[] iso = new float[20];
                iso[i * 6] = 1;      // keep only channel i
                iso[18] = 1;
                ColorMatrix m = new ColorMatrix(cm);
                m.postConcat(new ColorMatrix(iso));
                p.setColorFilter(new ColorMatrixColorFilter(m));
                c.drawBitmap(src, off[i], 0, p);
            }
            p.setBlendMode(null);
            p.setColorFilter(null);
        } else {
            p.setColorFilter(new ColorMatrixColorFilter(cm));
            c.drawBitmap(src, 0, 0, p);
            p.setColorFilter(null);
        }

        if (f.ovA > 0) {
            Paint op = new Paint();
            op.setColor(f.ovColor);
            op.setAlpha(a(f.ovA));
            op.setBlendMode(f.ovMode);
            c.drawRect(0, 0, w, h, op);
        }

        if (f.glow > 0) {
            Bitmap mid = Bitmap.createScaledBitmap(out, Math.max(2, w / 6), Math.max(2, h / 6), true);
            Bitmap small = Bitmap.createScaledBitmap(mid, Math.max(2, w / 28), Math.max(2, h / 28), true);
            mid.recycle();
            Paint gp = new Paint(Paint.FILTER_BITMAP_FLAG);
            gp.setColorFilter(new ColorMatrixColorFilter(new ColorMatrix(new float[]{
                    1.6f, 0, 0, 0, -90,
                    0, 1.6f, 0, 0, -90,
                    0, 0, 1.6f, 0, -90,
                    0, 0, 0, 1, 0})));
            gp.setBlendMode(BlendMode.SCREEN);
            gp.setAlpha(a(f.glow));
            c.drawBitmap(small, null, new Rect(0, 0, w, h), gp);
            small.recycle();
        }

        if (f.leak > 0) {
            float R = Math.max(w, h) * 0.85f;
            int clear = f.leakColor & 0x00FFFFFF;
            Paint lp = new Paint(Paint.ANTI_ALIAS_FLAG);
            lp.setBlendMode(BlendMode.SCREEN);
            lp.setShader(new RadialGradient(w * 0.02f, h * 0.12f, R,
                    new int[]{f.leakColor, clear | 0x55000000, clear},
                    new float[]{0, 0.35f, 1}, Shader.TileMode.CLAMP));
            lp.setAlpha(a(f.leak));
            c.drawRect(0, 0, w, h, lp);
            lp.setShader(new RadialGradient(w, h * 0.95f, R * 0.6f,
                    new int[]{f.leakColor, clear}, null, Shader.TileMode.CLAMP));
            lp.setAlpha(a(f.leak * 0.5f));
            c.drawRect(0, 0, w, h, lp);
        }

        if (f.vig > 0) {
            Paint vp = new Paint(Paint.ANTI_ALIAS_FLAG);
            float R = (float) Math.hypot(w, h) / 2f;
            vp.setShader(new RadialGradient(w / 2f, h / 2f, R,
                    new int[]{0, 0, 0xFF000000}, new float[]{0, 0.5f, 1}, Shader.TileMode.CLAMP));
            vp.setAlpha(a(f.vig));
            c.drawRect(0, 0, w, h, vp);
        }

        if (f.scan > 0) {
            Paint sp = new Paint();
            sp.setColor(Color.BLACK);
            sp.setAlpha(a(f.scan));
            float step = Math.max(2f, h / 320f);
            for (float y = 0; y < h; y += step) c.drawRect(0, y, w, y + step * 0.45f, sp);
        }

        if (f.grain > 0) {
            Paint np = new Paint(Paint.FILTER_BITMAP_FLAG);
            BitmapShader bs = new BitmapShader(noise(), Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
            float s = Math.max(1f, w / 1500f);
            Matrix m = new Matrix();
            m.setScale(s, s);
            bs.setLocalMatrix(m);
            np.setShader(bs);
            np.setBlendMode(BlendMode.OVERLAY);
            np.setAlpha(a(f.grain));
            c.drawRect(0, 0, w, h, np);
        }

        if (f.dust > 0) {
            Random r = new Random(11);
            Paint dp = new Paint(Paint.ANTI_ALIAS_FLAG);
            float u = w / 1000f;
            int n = (int) (f.dust * 90);
            for (int i = 0; i < n; i++) {
                dp.setColor(r.nextFloat() < 0.7f ? Color.WHITE : Color.BLACK);
                dp.setAlpha(60 + r.nextInt(120));
                float x = r.nextFloat() * w, y = r.nextFloat() * h;
                if (r.nextFloat() < 0.12f) {
                    dp.setStyle(Paint.Style.STROKE);
                    dp.setStrokeWidth(Math.max(0.6f, u * 1.2f));
                    Path path = new Path();
                    path.moveTo(x, y);
                    path.quadTo(x + (r.nextFloat() - .5f) * 40 * u, y + (r.nextFloat() - .5f) * 40 * u,
                            x + (r.nextFloat() - .5f) * 70 * u, y + (r.nextFloat() - .5f) * 70 * u);
                    c.drawPath(path, dp);
                } else {
                    dp.setStyle(Paint.Style.FILL);
                    c.drawCircle(x, y, Math.max(0.5f, (0.6f + r.nextFloat() * 2.2f) * u), dp);
                }
            }
        }

        if (f.bars) {
            float target = w / 2.39f;
            if (target < h) {
                float bh = (h - target) / 2f;
                Paint bp = new Paint();
                bp.setColor(Color.BLACK);
                c.drawRect(0, 0, w, bh, bp);
                c.drawRect(0, h - bh, w, h, bp);
            }
        }

        if (f.date) {
            String s = new SimpleDateFormat("''yy  MM  dd", Locale.US).format(new Date());
            Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
            tp.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            float size = Math.min(w, h) * 0.055f;
            tp.setTextSize(size);
            tp.setColor(0xFFFF9A2E);
            tp.setShadowLayer(size * 0.35f, 0, 0, 0xCCFF5A00);
            tp.setTextAlign(Paint.Align.RIGHT);
            c.drawText(s, w - size * 1.1f, h - size * 1.1f, tp);
        }
        return out;
    }

    /** Mixes fx over a mutable src at strength k (0..1). */
    static void blendInto(Bitmap src, Bitmap fx, float k) {
        Canvas c = new Canvas(src);
        Paint p = new Paint();
        p.setAlpha(a(k));
        c.drawBitmap(fx, 0, 0, p);
    }

    /** High-quality square thumbnail (centre crop). */
    static Bitmap thumb(Bitmap s, int size) {
        int m = Math.min(s.getWidth(), s.getHeight());
        int x = (s.getWidth() - m) / 2, y = (s.getHeight() - m) / 2;
        Paint fp = new Paint(Paint.FILTER_BITMAP_FLAG);
        int mid = Math.min(m, size * 3);
        Bitmap step = Bitmap.createBitmap(mid, mid, Bitmap.Config.ARGB_8888);
        new Canvas(step).drawBitmap(s, new Rect(x, y, x + m, y + m), new Rect(0, 0, mid, mid), fp);
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        new Canvas(out).drawBitmap(step, null, new Rect(0, 0, size, size), fp);
        step.recycle();
        return out;
    }

    /** Built-in sunset scene so the app looks alive before a photo is opened. */
    static Bitmap sample(int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, 0, h * 0.62f,
                new int[]{0xFF2B3A67, 0xFF8E6C9A, 0xFFF2A07B, 0xFFFCD9A8},
                new float[]{0, .45f, .8f, 1}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(new RadialGradient(w * .62f, h * .5f, w * .32f,
                new int[]{0xFFFFF4D6, 0x88FFE2B0, 0x00FFE2B0}, new float[]{0, .25f, 1}, Shader.TileMode.CLAMP));
        c.drawCircle(w * .62f, h * .5f, w * .32f, p);
        p.setShader(null);
        p.setColor(0xFFFFF7E6);
        c.drawCircle(w * .62f, h * .5f, w * .07f, p);

        int[] cols = {0xFF6E5A87, 0xFF3E3F6B, 0xFF1E2140};
        float[] base = {.58f, .68f, .80f};
        for (int i = 0; i < 3; i++) {
            float y = h * base[i];
            Path path = new Path();
            path.moveTo(0, y);
            path.cubicTo(w * .25f, y - h * .08f, w * .45f, y + h * .05f, w * .7f, y - h * .02f);
            path.cubicTo(w * .85f, y - h * .06f, w * .95f, y, w, y - h * .03f);
            path.lineTo(w, h);
            path.lineTo(0, h);
            path.close();
            p.setColor(cols[i]);
            c.drawPath(path, p);
        }
        return b;
    }
}
