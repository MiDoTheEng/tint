package app.tint;

import android.graphics.BlendMode;

/** One look. All values are applied by Renderer; defaults mean "no change". */
final class Filter {
    final String name, cat;

    // colour
    float sat = 1, con = 1, bri = 0, warm = 0, tint = 0, fade = 0, sepia = 0, hue = 0;
    float r = 1, g = 1, b = 1;
    boolean mono, invert, swap;
    int duoLo, duoHi; boolean duo;
    int[] grad; float gradMix = 1;   // gradient map (luminance -> colours)
    int poster;                      // posterize levels (0 = off)

    // colour wash
    int ovColor; BlendMode ovMode = BlendMode.SCREEN; float ovA;

    // geometry
    int mirror;      // 1 left->right, 2 top->bottom, 3 kaleido
    int pixel;       // blocks across (0 = off)

    // texture & light
    float grain, vig, glow, split, dust, scan, leak, sparkle, rainbow;
    int leakColor;
    int frame;       // 1 instant (white), 2 film (black)
    boolean bars, date;

    Filter(String name, String cat) { this.name = name; this.cat = cat; }

    boolean isOriginal() { return cat.isEmpty(); }
    Pro pro;                         // professional colour grade (Pro Filters)

    boolean needsPixels() { return grad != null || poster > 0 || pro != null; }

    Filter sat(float v) { sat = v; return this; }
    Filter con(float v) { con = v; return this; }
    Filter bri(float v) { bri = v; return this; }
    Filter warm(float v) { warm = v; return this; }
    Filter tint(float v) { tint = v; return this; }
    Filter fade(float v) { fade = v; return this; }
    Filter sepia(float v) { sepia = v; return this; }
    Filter hue(float deg) { hue = deg; return this; }
    Filter gains(float rr, float gg, float bb) { r = rr; g = gg; b = bb; return this; }
    Filter mono() { mono = true; return this; }
    Filter invert() { invert = true; return this; }
    Filter infrared() { swap = true; return this; }
    Filter duo(int lo, int hi) { duo = true; duoLo = lo; duoHi = hi; return this; }
    Filter grad(float mix, int... colors) { grad = colors; gradMix = mix; return this; }
    Filter poster(int levels) { poster = levels; return this; }
    Filter pro(Pro p) { pro = p; return this; }
    Filter wash(int color, BlendMode mode, float a) { ovColor = color; ovMode = mode; ovA = a; return this; }
    Filter mirror(int m) { mirror = m; return this; }
    Filter pixel(int blocks) { pixel = blocks; return this; }
    Filter grain(float v) { grain = v; return this; }
    Filter vig(float v) { vig = v; return this; }
    Filter glow(float v) { glow = v; return this; }
    Filter split(float v) { split = v; return this; }
    Filter dust(float v) { dust = v; return this; }
    Filter scan(float v) { scan = v; return this; }
    Filter sparkle(float v) { sparkle = v; return this; }
    Filter rainbow(float v) { rainbow = v; return this; }
    Filter leak(int color, float a) { leakColor = color; leak = a; return this; }
    Filter frame(int f) { frame = f; return this; }
    Filter bars() { bars = true; return this; }
    Filter date() { date = true; return this; }
}
