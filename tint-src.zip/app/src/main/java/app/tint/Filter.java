package app.tint;

import android.graphics.BlendMode;

/** One look. All values are applied by Renderer; defaults mean "no change". */
final class Filter {
    final String name, cat;

    // colour
    float sat = 1, con = 1, bri = 0, warm = 0, tint = 0, fade = 0, sepia = 0;
    float r = 1, g = 1, b = 1;
    boolean mono;

    // colour wash
    int ovColor; BlendMode ovMode = BlendMode.SCREEN; float ovA;

    // texture & light
    float grain, vig, glow, split, dust, scan, leak;
    int leakColor;
    boolean bars, date;

    Filter(String name, String cat) { this.name = name; this.cat = cat; }

    boolean isOriginal() { return cat.isEmpty(); }

    Filter sat(float v) { sat = v; return this; }
    Filter con(float v) { con = v; return this; }
    Filter bri(float v) { bri = v; return this; }
    Filter warm(float v) { warm = v; return this; }
    Filter tint(float v) { tint = v; return this; }
    Filter fade(float v) { fade = v; return this; }
    Filter sepia(float v) { sepia = v; return this; }
    Filter gains(float rr, float gg, float bb) { r = rr; g = gg; b = bb; return this; }
    Filter mono() { mono = true; return this; }
    Filter wash(int color, BlendMode mode, float a) { ovColor = color; ovMode = mode; ovA = a; return this; }
    Filter grain(float v) { grain = v; return this; }
    Filter vig(float v) { vig = v; return this; }
    Filter glow(float v) { glow = v; return this; }
    Filter split(float v) { split = v; return this; }
    Filter dust(float v) { dust = v; return this; }
    Filter scan(float v) { scan = v; return this; }
    Filter leak(int color, float a) { leakColor = color; leak = a; return this; }
    Filter bars() { bars = true; return this; }
    Filter date() { date = true; return this; }
}
