package app.tint;

import android.graphics.*;

/** Anything placed on top of the photo (text or another picture). Positions are fractions of the image. */
abstract class Item {
    float x = 0.5f, y = 0.5f, rot = 0, size;
    final RectF bounds = new RectF();   // un-rotated box from the last draw, in canvas pixels

    abstract void draw(Canvas c, int w, int h);
    abstract Item copy();
    abstract float minSize();
    abstract float maxSize();

    void copyBase(Item o) { o.x = x; o.y = y; o.rot = rot; o.size = size; }

    /** A picture placed on the photo, optionally with its background removed. */
    static final class Sticker extends Item {
        Bitmap original, bmp, outlined;
        boolean outline, flip, cutout;
        float opacity = 1;

        Sticker(Bitmap b) { original = b; bmp = b; size = 0.5f; }

        @Override float minSize() { return 0.05f; }
        @Override float maxSize() { return 2.5f; }

        void setBitmap(Bitmap b) {
            bmp = b;
            outlined = outline ? makeOutline(b) : null;
        }

        void setOutline(boolean on) {
            outline = on;
            outlined = on ? makeOutline(bmp) : null;
        }

        @Override
        void draw(Canvas c, int w, int h) {
            Bitmap s = (outline && outlined != null) ? outlined : bmp;
            float scale = size * w / bmp.getWidth();
            float sw = s.getWidth() * scale, sh = s.getHeight() * scale;
            float cx = x * w, cy = y * h;
            bounds.set(cx - sw / 2, cy - sh / 2, cx + sw / 2, cy + sh / 2);
            c.save();
            c.rotate(rot, cx, cy);
            if (flip) c.scale(-1, 1, cx, cy);
            Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
            p.setAlpha((int) (255 * opacity));
            c.drawBitmap(s, null, bounds, p);
            c.restore();
        }

        @Override
        Item copy() {
            Sticker s = new Sticker(original);
            copyBase(s);
            s.bmp = bmp; s.outlined = outlined; s.outline = outline;
            s.flip = flip; s.cutout = cutout; s.opacity = opacity;
            return s;
        }

        /** White "cut-out sticker" border around the visible shape. */
        static Bitmap makeOutline(Bitmap b) {
            int r = Math.max(3, Math.round(Math.max(b.getWidth(), b.getHeight()) * 0.018f));
            Bitmap alpha = b.extractAlpha();
            Bitmap out = Bitmap.createBitmap(b.getWidth() + 2 * r, b.getHeight() + 2 * r, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(out);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            p.setColor(Color.WHITE);
            float[] radii = {r, r * 0.66f, r * 0.33f};
            for (float rr : radii)
                for (int i = 0; i < 24; i++) {
                    double a = i * Math.PI * 2 / 24;
                    c.drawBitmap(alpha, r + (float) (rr * Math.cos(a)), r + (float) (rr * Math.sin(a)), p);
                }
            c.drawBitmap(b, r, r, null);
            alpha.recycle();
            return out;
        }
    }
}
