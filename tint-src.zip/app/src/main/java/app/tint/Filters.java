package app.tint;

import android.graphics.BlendMode;
import java.util.ArrayList;
import java.util.List;

final class Filters {
    static final String FAV = "★ Favorites";
    static final String PRO = "Pro Filters";
    static final String[] CATEGORIES = {"All", Filters.FAV, Filters.PRO, "Neon", "Sparkle", "Film", "Vintage", "Mood", "Cinema", "Pastel", "B&W", "Retro", "Art", "Mirror", "Frames", "Glow"};

    private static Filter f(List<Filter> l, String cat, String name) {
        Filter x = new Filter(name, cat); l.add(x); return x;
    }

    static List<Filter> all() {
        List<Filter> l = new ArrayList<>();
        f(l, "", "ORIGINAL");



        // ---------- PRO FILTERS (professional colour grades) ----------
        final int R = Pro.RED, O = Pro.ORANGE, Y = Pro.YELLOW, G = Pro.GREEN, A = Pro.AQUA, B = Pro.BLUE, P = Pro.PURPLE, M = Pro.MAGENTA;
        f(l, PRO, "CLEAN PRO").pro(new Pro().tone(-.45f, .35f).contrast(.22f).color(.25f, 1).clarity(.2f).ends(.15f, .1f));
        f(l, PRO, "PORTRAIT").pro(new Pro().wb(.12f, .03f).tone(-.35f, .25f).contrast(.12f).color(.12f, .97f)
                .hsl(O, 2, .88f, .1f).hsl(R, 4, .9f, .04f).hsl(Y, -4, .85f, 0).clarity(-.12f).fade(.08f));
        f(l, PRO, "SKIN TRUE").pro(new Pro().wb(.05f, 0).tone(-.25f, .2f).contrast(.1f).color(.1f, 1)
                .hsl(O, 3, .92f, .06f).hsl(R, 5, .95f, .03f).clarity(-.05f));
        f(l, PRO, "TEAL & ORANGE").pro(new Pro().tone(-.35f, .2f).contrast(.3f).color(.15f, .95f)
                .hsl(O, -2, 1.15f, .05f).hsl(Y, -12, 1.05f, 0).hsl(G, 35, .6f, -.05f).hsl(A, 8, 1.1f, -.05f).hsl(B, -18, 1.1f, -.08f)
                .split(0xFF1F7A80, .55f, 0xFFFF9A4D, .35f).clarity(.12f));
        f(l, PRO, "BLOCKBUSTER").pro(new Pro().tone(-.4f, .05f).contrast(.45f).ends(.1f, -.15f).color(.05f, .9f)
                .hsl(O, -3, 1.2f, .06f).hsl(B, -20, 1.15f, -.12f).hsl(G, 40, .5f, -.1f)
                .split(0xFF0F5C6E, .7f, 0xFFFFA25A, .4f).clarity(.25f)).vig(.2f);
        f(l, PRO, "CINEMATIC").pro(new Pro().tone(-.3f, .1f).contrast(.35f).color(0, .85f)
                .lgg(.0f, .03f, .07f, 1.03f, 1f, .95f).fade(.1f).clarity(.15f).hsl(G, 20, .7f, -.05f)).vig(.15f);
        f(l, PRO, "MOODY").pro(new Pro().exposure(-.15f).tone(-.45f, -.05f).contrast(.35f).color(-.05f, .78f)
                .hsl(G, 25, .5f, -.15f).hsl(Y, -10, .7f, -.05f).hsl(B, -10, .8f, -.15f)
                .split(0xFF23485A, .45f, 0xFFE8C9A0, .15f).fade(.15f)).vig(.25f);
        f(l, PRO, "GOLDEN HOUR").pro(new Pro().wb(.45f, .05f).tone(-.35f, .25f).contrast(.15f).color(.25f, 1.08f)
                .hsl(O, -3, 1.15f, .05f).hsl(Y, -8, 1.1f, .05f).split(0xFF5A3A6E, .2f, 0xFFFFB45A, .4f));
        f(l, PRO, "AIRY BRIGHT").pro(new Pro().exposure(.25f).wb(-.05f, 0).tone(-.25f, .45f).contrast(-.1f).color(.05f, .88f)
                .hsl(O, 0, .9f, .08f).hsl(G, 15, .75f, .1f).fade(.08f).clarity(-.05f));
        f(l, PRO, "MATTE EDITORIAL").pro(new Pro().wb(.05f, 0).tone(-.2f, .1f).contrast(.2f).color(-.05f, .85f).fade(.28f)
                .split(0xFF3A4A5A, .25f, 0xFFF0DCC0, .2f));
        f(l, PRO, "FILM PRO").pro(new Pro().wb(.1f, -.02f).tone(-.3f, .15f).contrast(.22f).color(.05f, .92f)
                .hsl(R, 6, 1.05f, 0).hsl(G, -18, .8f, 0).hsl(B, -8, .9f, -.05f).fade(.12f).rolloff(1)
                .split(0xFF2F5C5A, .25f, 0xFFFFD9A0, .2f)).grain(.18f);
        f(l, PRO, "CRISP LANDSCAPE").pro(new Pro().tone(-.6f, .45f).contrast(.18f).color(.35f, 1.05f)
                .hsl(B, -5, 1.2f, -.18f).hsl(A, -5, 1.15f, -.1f).hsl(G, -8, 1.15f, 0).hsl(Y, -5, 1.05f, 0).clarity(.45f).ends(.15f, .15f));
        f(l, PRO, "HDR NATURAL").pro(new Pro().tone(-.8f, .6f).contrast(.2f).color(.3f, 1.03f).clarity(.55f).ends(.2f, .05f));
        f(l, PRO, "DESERT").pro(new Pro().wb(.35f, .03f).tone(-.35f, .2f).contrast(.22f).color(.2f, 1.05f)
                .hsl(O, -4, 1.18f, .04f).hsl(Y, -10, 1.1f, .02f).hsl(B, -15, 1.05f, -.1f).hsl(A, -10, 1, 0)
                .split(0xFF2A6E78, .3f, 0xFFFFB866, .3f).clarity(.18f));
        f(l, PRO, "URBAN STREET").pro(new Pro().wb(-.15f, -.03f).tone(-.4f, .2f).contrast(.35f).color(-.15f, .75f)
                .hsl(O, 0, 1.05f, 0).hsl(B, -10, .8f, -.1f).clarity(.38f).ends(0, -.1f));
        f(l, PRO, "NORDIC").pro(new Pro().wb(-.3f, 0).tone(-.25f, .15f).contrast(.1f).color(-.1f, .75f)
                .hsl(G, 30, .55f, 0).hsl(Y, 20, .6f, 0).hsl(B, -5, .85f, 0).fade(.12f).split(0xFF3A5A6E, .25f, 0xFFE0E8F0, .1f));
        f(l, PRO, "ICE").pro(new Pro().wb(-.35f, -.02f).tone(-.3f, .2f).contrast(.08f).color(.05f, .85f)
                .hsl(B, -5, 1.15f, .05f).hsl(A, 0, 1.1f, .05f).ends(.15f, 0).clarity(.1f));
        f(l, PRO, "CHOCOLATE").pro(new Pro().wb(.3f, .03f).tone(-.35f, .05f).contrast(.25f).color(-.1f, .7f)
                .hsl(G, -35, .5f, -.1f).hsl(Y, -15, .75f, -.05f).hsl(B, 0, .6f, -.1f).split(0xFF4A2E22, .45f, 0xFFF0C99A, .2f).fade(.1f));
        f(l, PRO, "FOOD POP").pro(new Pro().wb(.15f, 0).tone(-.25f, .2f).contrast(.15f).color(.4f, 1.05f)
                .hsl(R, 0, 1.15f, 0).hsl(O, 0, 1.15f, .04f).hsl(Y, 0, 1.12f, .04f).hsl(G, 0, 1.1f, 0).clarity(.25f));
        f(l, PRO, "SUNSET BOOST").pro(new Pro().wb(.2f, .08f).tone(-.45f, .15f).contrast(.18f).color(.3f, 1.08f)
                .hsl(M, 0, 1.2f, 0).hsl(P, -10, 1.2f, 0).hsl(O, 0, 1.2f, 0).hsl(R, 5, 1.1f, 0)
                .split(0xFF4A2A6E, .3f, 0xFFFF8A6B, .3f));
        f(l, PRO, "NIGHT NEON").pro(new Pro().wb(-.22f, .03f).tone(-.5f, .15f).contrast(.3f).color(.3f, 1.1f)
                .hsl(M, 0, 1.25f, 0).hsl(P, -5, 1.25f, 0).hsl(B, 12, 1.15f, 0).hsl(O, -8, .9f, 0)
                .split(0xFF1A3A6E, .4f, 0xFFFF6AC8, .25f).clarity(.15f));
        f(l, PRO, "VINTAGE PRO").pro(new Pro().wb(.12f, 0).tone(-.3f, .15f).contrast(.15f).color(-.05f, .85f)
                .lgg(.02f, .05f, .07f, 1.02f, 1f, .92f).hsl(G, -12, .75f, 0).fade(.2f)
                .split(0xFF2E5A50, .3f, 0xFFF5DDB0, .3f)).grain(.15f);
        f(l, PRO, "B&W PRO").pro(new Pro().mono(.45f, .4f, .15f).tone(-.45f, .25f).contrast(.4f).clarity(.35f).ends(.15f, .1f)).grain(.12f);
        f(l, PRO, "B&W SOFT").pro(new Pro().mono(.35f, .5f, .15f).tone(-.35f, .3f).contrast(.12f).fade(.15f).clarity(-.05f));
        f(l, PRO, "B&W DRAMA").pro(new Pro().mono(.65f, .3f, .05f).tone(-.5f, -.1f).contrast(.55f).clarity(.45f).ends(.1f, -.15f)).vig(.3f);
        f(l, PRO, "SEPIA PRO").pro(new Pro().mono(.4f, .45f, .15f).tone(-.3f, .2f).contrast(.2f).fade(.12f)
                .split(0xFF4A3020, .6f, 0xFFF5DDB0, .45f)).grain(.1f);

        // ---------- NEON ----------
        f(l, "Neon", "NEON").sat(1.3f).tint(.3f).warm(-.3f).glow(.4f).con(1.1f);
        f(l, "Neon", "CYBERPUNK").tint(.35f).warm(-.4f).sat(1.4f).con(1.2f).glow(.45f).wash(0xFFFF00C8, BlendMode.OVERLAY, .2f);
        f(l, "Neon", "VAPORWAVE").grad(.75f, 0xFF1A0B3D, 0xFF7B2FF7, 0xFFFF4FD8, 0xFFFFD1F5).glow(.3f).scan(.08f);
        f(l, "Neon", "SYNTHWAVE").grad(.85f, 0xFF0B0221, 0xFF5B1E9E, 0xFFFF2E88, 0xFFFFB86B).glow(.4f);
        f(l, "Neon", "PINK GLOW").duo(0xFF14003A, 0xFFFF4FD8).glow(.5f).con(1.1f);
        f(l, "Neon", "ELECTRIC").duo(0xFF000A2E, 0xFF3DE8FF).glow(.5f).con(1.1f);
        f(l, "Neon", "ACID").hue(90).sat(1.6f).con(1.15f).glow(.3f);
        f(l, "Neon", "LASER").split(.006f).tint(.3f).sat(1.4f).glow(.5f).con(1.2f).wash(0xFF00F0FF, BlendMode.OVERLAY, .15f);
        f(l, "Neon", "MIAMI").grad(.6f, 0xFF1B1464, 0xFFE84393, 0xFFFDCB6E).glow(.3f);
        f(l, "Neon", "NIGHT CITY").warm(-.5f).tint(.25f).con(1.2f).sat(1.3f).glow(.45f).vig(.3f);
        f(l, "Neon", "UV").duo(0xFF0A0020, 0xFFB388FF).glow(.55f).con(1.15f);
        f(l, "Neon", "TOXIC").duo(0xFF001A0A, 0xFF7CFF4F).glow(.5f).con(1.1f);

        // ---------- SPARKLE ----------
        f(l, "Sparkle", "GLITTER").sparkle(.8f).glow(.25f);
        f(l, "Sparkle", "STARRY").sparkle(1).bri(.02f).con(1.05f);
        f(l, "Sparkle", "DIAMOND").sparkle(.9f).warm(-.2f).glow(.3f).sat(.9f);
        f(l, "Sparkle", "FAIRY").sparkle(.7f).glow(.45f).fade(.15f).tint(.15f);
        f(l, "Sparkle", "GOLD DUST").sparkle(.8f).warm(.5f).leak(0xFFFFB04A, .25f);
        f(l, "Sparkle", "RAINBOW").rainbow(.6f).fade(.1f).glow(.15f);
        f(l, "Sparkle", "PRISM GLINT").rainbow(.4f).sparkle(.6f).glow(.25f);
        f(l, "Sparkle", "DREAM").sparkle(.6f).glow(.5f).fade(.2f).bri(.03f);

        // ---------- FILM ----------
        f(l, "Film", "F200").warm(.35f).sat(1.1f).con(1.05f).fade(.15f).grain(.35f);
        f(l, "Film", "F160 SKIN").warm(.2f).sat(.9f).con(.95f).fade(.2f).gains(1, 1.02f, 1).grain(.25f);
        f(l, "Film", "F400 GREEN").warm(-.1f).tint(-.15f).sat(1.05f).con(1.08f).fade(.12f).grain(.3f);
        f(l, "Film", "GOLDEN").warm(.5f).sat(1.15f).con(1.1f).wash(0xFFFFB347, BlendMode.SOFT_LIGHT, .25f).grain(.3f);
        f(l, "Film", "STREET").tint(-.25f).con(1.12f).sat(1.1f).grain(.3f);
        f(l, "Film", "VIVID 100").sat(1.35f).con(1.15f).warm(.15f).grain(.2f);
        f(l, "Film", "800T").warm(-.45f).con(1.1f).sat(.95f).glow(.35f).grain(.35f);
        f(l, "Film", "EXPIRED").fade(.35f).sat(.8f).tint(.25f).warm(.3f).grain(.45f).leak(0xFFFF5A36, .35f);
        f(l, "Film", "35MM").con(1.12f).sat(1.05f).warm(.1f).vig(.35f).grain(.4f).dust(.4f);
        f(l, "Film", "SLIDE").sat(1.25f).con(1.25f).bri(-.03f).warm(-.05f).vig(.25f);

        f(l, "Film", "HALATION").glow(.4f).leak(0xFFFF3B1F, .2f).grain(.35f).con(1.08f).warm(.1f);
        f(l, "Film", "MATTE").fade(.5f).con(.9f).sat(.9f).grain(.2f);
        f(l, "Film", "BLEACH").sat(.55f).con(1.35f).bri(-.02f).grain(.3f);
        f(l, "Film", "CROSS").tint(-.2f).warm(-.15f).sat(1.3f).con(1.2f).wash(0xFFFFE14D, BlendMode.OVERLAY, .25f);

        // ---------- VINTAGE ----------
        f(l, "Vintage", "1970").sepia(.35f).fade(.25f).warm(.4f).vig(.4f).grain(.3f);
        f(l, "Vintage", "INSTANT").fade(.3f).sat(.85f).con(.9f).tint(.1f).wash(0xFFFFF1D6, BlendMode.MULTIPLY, .35f).vig(.2f);
        f(l, "Vintage", "SEPIA").sepia(1).con(1.05f).vig(.35f).grain(.3f);
        f(l, "Vintage", "FADED").fade(.45f).sat(.7f).con(.9f);
        f(l, "Vintage", "DUSTY").sepia(.2f).fade(.3f).dust(1).grain(.5f).vig(.3f);
        f(l, "Vintage", "RETRO 80").sat(1.2f).tint(.2f).warm(.3f).fade(.2f).leak(0xFFFF8A3D, .3f);
        f(l, "Vintage", "CHROMA").sat(1.3f).con(1.2f).warm(.1f);
        f(l, "Vintage", "LOMO").sat(1.35f).con(1.25f).vig(.7f).warm(.1f);
        f(l, "Vintage", "AGED").sepia(.5f).fade(.35f).dust(.6f).grain(.55f).vig(.45f);

        // ---------- MOOD ----------
        f(l, "Mood", "MOODY").sat(.75f).con(1.15f).bri(-.05f).warm(-.15f).fade(.1f).vig(.3f);
        f(l, "Mood", "DUSK").wash(0xFF6A4CFF, BlendMode.SCREEN, .14f).warm(.2f).con(1.05f);
        f(l, "Mood", "FOREST").tint(-.35f).sat(.8f).con(1.1f).fade(.15f);
        f(l, "Mood", "RAIN").warm(-.4f).sat(.7f).fade(.2f).con(.95f);
        f(l, "Mood", "WINE").tint(.35f).warm(.2f).sat(.9f).con(1.1f).vig(.3f);
        f(l, "Mood", "DREAMY").glow(.5f).fade(.2f).sat(.9f).bri(.03f);
        f(l, "Mood", "MIDNIGHT").warm(-.6f).bri(-.08f).con(1.15f).sat(.8f).vig(.4f);
        f(l, "Mood", "AUTUMN").warm(.55f).sat(1.15f).gains(1, .97f, 1);
        f(l, "Mood", "HAZE").fade(.4f).bri(.05f).sat(.8f).wash(0xFFFFE6CC, BlendMode.SCREEN, .15f);

        // ---------- CINEMA ----------
        f(l, "Cinema", "TEAL·ORANGE").warm(.3f).con(1.12f).wash(0xFF0E6B73, BlendMode.OVERLAY, .35f).sat(1.05f);
        f(l, "Cinema", "SCOPE").con(1.1f).sat(.9f).warm(.1f).vig(.2f).bars();
        f(l, "Cinema", "CODE").tint(-.5f).sat(.6f).con(1.2f).bri(-.03f);
        f(l, "Cinema", "AMBER").wash(0xFFFF7A00, BlendMode.OVERLAY, .3f).con(1.15f).sat(.9f).fade(.1f);
        f(l, "Cinema", "ARCTIC").warm(-.5f).sat(.8f).bri(.04f).con(1.05f);
        f(l, "Cinema", "VELVET").tint(.25f).warm(-.15f).con(1.1f).sat(1.05f).glow(.2f);
        
        // ---------- PASTEL ----------
        f(l, "Pastel", "PEACH").warm(.3f).fade(.3f).sat(.85f).bri(.05f).wash(0xFFFFC0A8, BlendMode.SCREEN, .12f);
        f(l, "Pastel", "LILAC").tint(.25f).warm(-.1f).fade(.3f).bri(.05f).sat(.85f);
        f(l, "Pastel", "MINT").tint(-.2f).warm(-.2f).fade(.3f).bri(.05f);
        f(l, "Pastel", "CREAM").warm(.2f).fade(.35f).sat(.75f).bri(.06f);
        f(l, "Pastel", "CANDY").sat(1.2f).tint(.15f).fade(.25f).bri(.05f).glow(.2f);
        f(l, "Pastel", "SOFT").fade(.25f).con(.9f).sat(.9f).glow(.3f);
        f(l, "Pastel", "CLOUD").bri(.08f).fade(.4f).sat(.7f).warm(-.05f);

        // ---------- B&W ----------
        f(l, "B&W", "MONO").mono().con(1.05f);
        f(l, "B&W", "400 BW").mono().con(1.15f).grain(.5f);
        f(l, "B&W", "NOIR").mono().con(1.45f).bri(-.03f).vig(.5f);
        f(l, "B&W", "SILVER").mono().con(.95f).fade(.2f).bri(.03f).glow(.2f);
        f(l, "B&W", "INK").mono().con(1.7f).bri(-.05f);
        f(l, "B&W", "SELENIUM").mono().con(1.1f).wash(0xFF8C7B9A, BlendMode.OVERLAY, .4f);
        f(l, "B&W", "CYANO").mono().con(1.1f).wash(0xFF6FA8FF, BlendMode.MULTIPLY, .7f);
        f(l, "B&W", "3200").mono().con(1.2f).grain(.85f).vig(.3f);

        // ---------- RETRO ----------
        f(l, "Retro", "THROWAWAY").warm(.3f).sat(1.1f).con(1.1f).grain(.35f).glow(.15f).date();
        f(l, "Retro", "'98").bri(.06f).con(1.15f).sat(1.1f).vig(.2f).grain(.3f).date();
        f(l, "Retro", "VHS").split(.006f).sat(1.2f).fade(.15f).grain(.4f).con(1.05f).scan(.18f);
        f(l, "Retro", "GLITCH").split(.014f).sat(1.3f).con(1.2f).scan(.2f);
        f(l, "Retro", "CCD").bri(.04f).con(1.15f).sat(1.15f).warm(-.1f).glow(.25f).date();
        f(l, "Retro", "RGB").split(.009f).con(1.1f);
        f(l, "Retro", "Y2K").sat(1.3f).tint(.2f).glow(.35f).fade(.1f).split(.003f);
        f(l, "Retro", "CAMCORDER").split(.004f).scan(.25f).sat(.9f).fade(.2f).warm(.15f).date();

        f(l, "Retro", "8-BIT").pixel(72).sat(1.3f).con(1.1f).poster(6);
        f(l, "Retro", "PIXEL").pixel(120);
        f(l, "Retro", "HANDHELD").pixel(96).grad(1, 0xFF0F380F, 0xFF306230, 0xFF8BAC0F, 0xFF9BBC0F);

        // ---------- ART ----------
        f(l, "Art", "INFRARED").infrared().sat(1.3f).con(1.1f);
        f(l, "Art", "THERMAL").grad(1, 0xFF000020, 0xFF3B0CA3, 0xFFD6227A, 0xFFFF8C1A, 0xFFFFF35C, 0xFFFFFFFF);
        f(l, "Art", "X-RAY").mono().invert().con(1.2f).wash(0xFF8FD3FF, BlendMode.MULTIPLY, .6f);
        f(l, "Art", "NEGATIVE").invert();
        f(l, "Art", "POP ART").poster(3).sat(1.8f).con(1.3f);
        f(l, "Art", "POSTER").poster(4).sat(1.3f).con(1.1f);
        f(l, "Art", "DUO RED").duo(0xFF1A0010, 0xFFFF5A5A);
        f(l, "Art", "DUO MINT").duo(0xFF06261F, 0xFF9BFFD9);
        f(l, "Art", "DUO GOLD").duo(0xFF1C1206, 0xFFFFD27A);
        f(l, "Art", "SUNPRINT").grad(1, 0xFF0B1F4D, 0xFF2D6CDF, 0xFFE8F1FF);

        // ---------- MIRROR ----------
        f(l, "Mirror", "MIRROR").mirror(1);
        f(l, "Mirror", "REFLECT").mirror(2);
        f(l, "Mirror", "KALEIDO").mirror(3).sat(1.2f).con(1.05f);
        f(l, "Mirror", "NEON TWIN").mirror(1).duo(0xFF14003A, 0xFFFF4FD8).glow(.45f);

        // ---------- FRAMES ----------
        f(l, "Frames", "INSTANT").frame(1).fade(.2f).warm(.15f).sat(.9f);
        f(l, "Frames", "INSTANT BW").frame(1).mono().fade(.15f);
        f(l, "Frames", "FILM STRIP").frame(2).grain(.35f).con(1.08f).warm(.1f);
        f(l, "Frames", "FILM 400").frame(2).grain(.45f).fade(.15f).tint(-.1f).date();

        // ---------- GLOW ----------
        f(l, "Glow", "BLOOM").glow(.6f).con(1.05f);
        f(l, "Glow", "HALO").glow(.5f).warm(.3f).fade(.1f);
        f(l, "Glow", "ANGEL").glow(.55f).bri(.06f).fade(.2f).sat(.85f);
        f(l, "Glow", "SUNSET").leak(0xFFFF6A2B, .6f).warm(.25f);
        f(l, "Glow", "PRISM").leak(0xFFB84DFF, .5f).glow(.2f).tint(.1f);
        f(l, "Glow", "GOLD HOUR").warm(.6f).leak(0xFFFFB04A, .4f).glow(.25f).sat(1.1f);
        f(l, "Glow", "FLARE").leak(0xFFFFE0A0, .7f).glow(.3f).fade(.1f);
        return l;
    }
}
