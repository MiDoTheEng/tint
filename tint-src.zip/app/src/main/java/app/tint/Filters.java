package app.tint;

import android.graphics.BlendMode;
import java.util.ArrayList;
import java.util.List;

final class Filters {
    static final String[] CATEGORIES = {"All", "Film", "Vintage", "Mood", "Cinema", "Pastel", "B&W", "Retro", "Glow"};

    private static Filter f(List<Filter> l, String cat, String name) {
        Filter x = new Filter(name, cat); l.add(x); return x;
    }

    static List<Filter> all() {
        List<Filter> l = new ArrayList<>();
        f(l, "", "ORIGINAL");

        // ---------- FILM ----------
        f(l, "Film", "F200").warm(.35f).sat(1.1f).con(1.05f).fade(.15f).grain(.35f);
        f(l, "Film", "F160 SKIN").warm(.2f).sat(.9f).con(.95f).fade(.2f).gains(1, 1.02f, 1).grain(.25f);
        f(l, "Film", "F400 GREEN").warm(-.1f).tint(-.15f).sat(1.05f).con(1.08f).fade(.12f).grain(.3f);
        f(l, "Film", "GOLDEN").warm(.5f).sat(1.15f).con(1.1f).wash(0xFFFFB347, BlendMode.SOFT_LIGHT, .25f).grain(.3f);
        f(l, "Film", "STREET").tint(-.25f).con(1.12f).sat(1.1f).grain(.3f);
        f(l, "Film", "VIVID 100").sat(1.35f).con(1.15f).warm(.15f).grain(.2f);
        f(l, "Film", "800T").warm(-.45f).con(1.1f).sat(.95f).glow(.35f).grain(.35f);
        f(l, "Film", "EXPIRED").fade(.35f).sat(.8f).tint(.25f).warm(.3f).grain(.45f).leak(0xFFFF5A36, .35f);
        f(l, "Film", "35MM").con(1.12f).sat(1.05f).warm(.1f).vig(.35f).grain(.4f).dust(.4f);
        f(l, "Film", "SLIDE").sat(1.25f).con(1.25f).bri(-.03f).warm(-.05f).vig(.25f);

        // ---------- VINTAGE ----------
        f(l, "Vintage", "1970").sepia(.35f).fade(.25f).warm(.4f).vig(.4f).grain(.3f);
        f(l, "Vintage", "INSTANT").fade(.3f).sat(.85f).con(.9f).tint(.1f).wash(0xFFFFF1D6, BlendMode.MULTIPLY, .35f).vig(.2f);
        f(l, "Vintage", "SEPIA").sepia(1).con(1.05f).vig(.35f).grain(.3f);
        f(l, "Vintage", "FADED").fade(.45f).sat(.7f).con(.9f);
        f(l, "Vintage", "DUSTY").sepia(.2f).fade(.3f).dust(1).grain(.5f).vig(.3f);
        f(l, "Vintage", "RETRO 80").sat(1.2f).tint(.2f).warm(.3f).fade(.2f).leak(0xFFFF8A3D, .3f);
        f(l, "Vintage", "CHROMA").sat(1.3f).con(1.2f).warm(.1f);
        f(l, "Vintage", "LOMO").sat(1.35f).con(1.25f).vig(.7f).warm(.1f);
        f(l, "Vintage", "AGED").sepia(.5f).fade(.35f).dust(.6f).grain(.55f).vig(.45f);

        // ---------- MOOD ----------
        f(l, "Mood", "MOODY").sat(.75f).con(1.15f).bri(-.05f).warm(-.15f).fade(.1f).vig(.3f);
        f(l, "Mood", "DUSK").wash(0xFF6A4CFF, BlendMode.SCREEN, .14f).warm(.2f).con(1.05f);
        f(l, "Mood", "FOREST").tint(-.35f).sat(.8f).con(1.1f).fade(.15f);
        f(l, "Mood", "RAIN").warm(-.4f).sat(.7f).fade(.2f).con(.95f);
        f(l, "Mood", "WINE").tint(.35f).warm(.2f).sat(.9f).con(1.1f).vig(.3f);
        f(l, "Mood", "DREAMY").glow(.5f).fade(.2f).sat(.9f).bri(.03f);
        f(l, "Mood", "MIDNIGHT").warm(-.6f).bri(-.08f).con(1.15f).sat(.8f).vig(.4f);
        f(l, "Mood", "AUTUMN").warm(.55f).sat(1.15f).gains(1, .97f, 1);
        f(l, "Mood", "HAZE").fade(.4f).bri(.05f).sat(.8f).wash(0xFFFFE6CC, BlendMode.SCREEN, .15f);

        // ---------- CINEMA ----------
        f(l, "Cinema", "TEAL·ORANGE").warm(.3f).con(1.12f).wash(0xFF0E6B73, BlendMode.OVERLAY, .35f).sat(1.05f);
        f(l, "Cinema", "SCOPE").con(1.1f).sat(.9f).warm(.1f).vig(.2f).bars();
        f(l, "Cinema", "CODE").tint(-.5f).sat(.6f).con(1.2f).bri(-.03f);
        f(l, "Cinema", "AMBER").wash(0xFFFF7A00, BlendMode.OVERLAY, .3f).con(1.15f).sat(.9f).fade(.1f);
        f(l, "Cinema", "ARCTIC").warm(-.5f).sat(.8f).bri(.04f).con(1.05f);
        f(l, "Cinema", "VELVET").tint(.25f).warm(-.15f).con(1.1f).sat(1.05f).glow(.2f);
        f(l, "Cinema", "NEON").sat(1.3f).tint(.3f).warm(-.3f).glow(.4f).con(1.1f);

        // ---------- PASTEL ----------
        f(l, "Pastel", "PEACH").warm(.3f).fade(.3f).sat(.85f).bri(.05f).wash(0xFFFFC0A8, BlendMode.SCREEN, .12f);
        f(l, "Pastel", "LILAC").tint(.25f).warm(-.1f).fade(.3f).bri(.05f).sat(.85f);
        f(l, "Pastel", "MINT").tint(-.2f).warm(-.2f).fade(.3f).bri(.05f);
        f(l, "Pastel", "CREAM").warm(.2f).fade(.35f).sat(.75f).bri(.06f);
        f(l, "Pastel", "CANDY").sat(1.2f).tint(.15f).fade(.25f).bri(.05f).glow(.2f);
        f(l, "Pastel", "SOFT").fade(.25f).con(.9f).sat(.9f).glow(.3f);
        f(l, "Pastel", "CLOUD").bri(.08f).fade(.4f).sat(.7f).warm(-.05f);

        // ---------- B&W ----------
        f(l, "B&W", "MONO").mono().con(1.05f);
        f(l, "B&W", "400 BW").mono().con(1.15f).grain(.5f);
        f(l, "B&W", "NOIR").mono().con(1.45f).bri(-.03f).vig(.5f);
        f(l, "B&W", "SILVER").mono().con(.95f).fade(.2f).bri(.03f).glow(.2f);
        f(l, "B&W", "INK").mono().con(1.7f).bri(-.05f);
        f(l, "B&W", "SELENIUM").mono().con(1.1f).wash(0xFF8C7B9A, BlendMode.OVERLAY, .4f);
        f(l, "B&W", "CYANO").mono().con(1.1f).wash(0xFF6FA8FF, BlendMode.MULTIPLY, .7f);
        f(l, "B&W", "3200").mono().con(1.2f).grain(.85f).vig(.3f);

        // ---------- RETRO ----------
        f(l, "Retro", "THROWAWAY").warm(.3f).sat(1.1f).con(1.1f).grain(.35f).glow(.15f).date();
        f(l, "Retro", "'98").bri(.06f).con(1.15f).sat(1.1f).vig(.2f).grain(.3f).date();
        f(l, "Retro", "VHS").split(.006f).sat(1.2f).fade(.15f).grain(.4f).con(1.05f).scan(.18f);
        f(l, "Retro", "GLITCH").split(.014f).sat(1.3f).con(1.2f).scan(.2f);
        f(l, "Retro", "CCD").bri(.04f).con(1.15f).sat(1.15f).warm(-.1f).glow(.25f).date();
        f(l, "Retro", "RGB").split(.009f).con(1.1f);
        f(l, "Retro", "Y2K").sat(1.3f).tint(.2f).glow(.35f).fade(.1f).split(.003f);
        f(l, "Retro", "CAMCORDER").split(.004f).scan(.25f).sat(.9f).fade(.2f).warm(.15f).date();

        // ---------- GLOW ----------
        f(l, "Glow", "BLOOM").glow(.6f).con(1.05f);
        f(l, "Glow", "HALO").glow(.5f).warm(.3f).fade(.1f);
        f(l, "Glow", "ANGEL").glow(.55f).bri(.06f).fade(.2f).sat(.85f);
        f(l, "Glow", "SUNSET").leak(0xFFFF6A2B, .6f).warm(.25f);
        f(l, "Glow", "PRISM").leak(0xFFB84DFF, .5f).glow(.2f).tint(.1f);
        f(l, "Glow", "GOLD HOUR").warm(.6f).leak(0xFFFFB04A, .4f).glow(.25f).sat(1.1f);
        f(l, "Glow", "FLARE").leak(0xFFFFE0A0, .7f).glow(.3f).fade(.1f);
        return l;
    }
}
