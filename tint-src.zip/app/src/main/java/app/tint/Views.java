package app.tint;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.List;

final class Views {

    /** A frame that always has the photo's exact shape, fitted into the space available. */
    static final class AspectFrame extends FrameLayout {
        float ratio = 0.8f;

        AspectFrame(Context c) { super(c); }

        void setRatio(float r) {
            if (Math.abs(r - ratio) < 0.0001f) return;
            ratio = r;
            requestLayout();
        }

        @Override
        protected void onMeasure(int ws, int hs) {
            int W = MeasureSpec.getSize(ws), H = MeasureSpec.getSize(hs);
            int w = W, h = Math.round(W / ratio);
            if (h > H) { h = H; w = Math.round(H * ratio); }
            super.onMeasure(MeasureSpec.makeMeasureSpec(Math.max(1, w), MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(Math.max(1, h), MeasureSpec.EXACTLY));
        }
    }

    /**
     * Draws text and pictures over the photo. While editing, the selected item shows a box with
     * a ✕ (delete) corner and a ↻ corner (drag to rotate + resize). Two fingers also rotate + resize.
     */
    static final class Overlay extends View {
        interface Listener {
            void onSelect(Item it);
            void onChanged();
            void onDelete(Item it);
        }

        final List<Item> items = new ArrayList<>();
        Item selected;
        boolean editing;
        Listener listener;

        private static final int NONE = 0, DRAG = 1, HANDLE = 2, PINCH = 3;
        private int mode;
        private float lx, ly, startAngle, startDist, startRot, startSize;
        private final float d;
        private final Paint box = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint knob = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glyph = new Paint(Paint.ANTI_ALIAS_FLAG);

        Overlay(Context c) {
            super(c);
            d = getResources().getDisplayMetrics().density;
            box.setStyle(Paint.Style.STROKE);
            box.setStrokeWidth(1.5f * d);
            box.setColor(0xDDFFFFFF);
            box.setPathEffect(new DashPathEffect(new float[]{6 * d, 5 * d}, 0));
            box.setShadowLayer(2 * d, 0, 0, 0x66000000);
            knob.setShadowLayer(3 * d, 0, d, 0x66000000);
            glyph.setTextAlign(Paint.Align.CENTER);
            glyph.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            glyph.setTextSize(14 * d);
        }

        /** Corner of the selected item's box after rotation: tl = top-left (✕), else bottom-right (↻). */
        private float[] corner(Item it, boolean tl) {
            float cx = it.x * getWidth(), cy = it.y * getHeight();
            float px = tl ? it.bounds.left : it.bounds.right;
            float py = tl ? it.bounds.top : it.bounds.bottom;
            double a = Math.toRadians(it.rot);
            float dx = px - cx, dy = py - cy;
            return new float[]{cx + (float) (dx * Math.cos(a) - dy * Math.sin(a)),
                               cy + (float) (dx * Math.sin(a) + dy * Math.cos(a))};
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            for (Item it : items) it.draw(c, w, h);
            if (!editing || selected == null) return;
            float cx = selected.x * w, cy = selected.y * h, r = 10 * d;
            c.save();
            c.rotate(selected.rot, cx, cy);
            c.drawRoundRect(selected.bounds, r, r, box);
            c.restore();
            drawKnob(c, corner(selected, true), Color.WHITE, 0xFF111111, "✕");
            drawKnob(c, corner(selected, false), 0xFFFF4D2E, Color.WHITE, "↻");
        }

        private void drawKnob(Canvas c, float[] p, int fill, int ink, String s) {
            knob.setColor(fill);
            c.drawCircle(p[0], p[1], 13 * d, knob);
            glyph.setColor(ink);
            c.drawText(s, p[0], p[1] - (glyph.descent() + glyph.ascent()) / 2, glyph);
        }

        private Item hit(float x, float y) {
            float slop = 12 * d;
            for (int i = items.size() - 1; i >= 0; i--) {
                Item it = items.get(i);
                float cx = it.x * getWidth(), cy = it.y * getHeight();
                double a = Math.toRadians(-it.rot);
                float dx = x - cx, dy = y - cy;
                float rx = cx + (float) (dx * Math.cos(a) - dy * Math.sin(a));
                float ry = cy + (float) (dx * Math.sin(a) + dy * Math.cos(a));
                RectF b = it.bounds;
                if (rx >= b.left - slop && rx <= b.right + slop && ry >= b.top - slop && ry <= b.bottom + slop)
                    return it;
            }
            return null;
        }

        private static float dist(float x1, float y1, float x2, float y2) { return (float) Math.hypot(x2 - x1, y2 - y1); }
        private static float angle(float x1, float y1, float x2, float y2) { return (float) Math.toDegrees(Math.atan2(y2 - y1, x2 - x1)); }

        private float snap(float r) {
            float m = ((r % 360) + 360) % 360;
            for (int k = 0; k <= 360; k += 90) if (Math.abs(m - k) < 4) return r - (m - k);
            return r;
        }

        private void setSize(float v) {
            selected.size = Math.max(selected.minSize(), Math.min(selected.maxSize(), v));
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (!editing) return false;
            int a = e.getActionMasked();
            float x = e.getX(), y = e.getY();
            switch (a) {
                case MotionEvent.ACTION_DOWN: {
                    mode = NONE;
                    float hr = 24 * d;
                    if (selected != null) {
                        float[] del = corner(selected, true);
                        if (dist(x, y, del[0], del[1]) < hr) {
                            if (listener != null) listener.onDelete(selected);
                            return true;
                        }
                        float[] rot = corner(selected, false);
                        if (dist(x, y, rot[0], rot[1]) < hr) {
                            float cx = selected.x * getWidth(), cy = selected.y * getHeight();
                            mode = HANDLE;
                            startAngle = angle(cx, cy, x, y);
                            startDist = Math.max(1, dist(cx, cy, x, y));
                            startRot = selected.rot;
                            startSize = selected.size;
                            return true;
                        }
                    }
                    Item it = hit(x, y);
                    if (it == null) return false;          // lets the photo handle hold-to-compare
                    if (it != selected) {
                        selected = it;
                        if (listener != null) listener.onSelect(it);
                    }
                    mode = DRAG;
                    lx = x; ly = y;
                    invalidate();
                    return true;
                }
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (selected != null && e.getPointerCount() >= 2) {
                        mode = PINCH;
                        startAngle = angle(e.getX(0), e.getY(0), e.getX(1), e.getY(1));
                        startDist = Math.max(1, dist(e.getX(0), e.getY(0), e.getX(1), e.getY(1)));
                        startRot = selected.rot;
                        startSize = selected.size;
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (selected == null) return true;
                    if (mode == DRAG) {
                        selected.x = Math.max(0f, Math.min(1f, selected.x + (x - lx) / getWidth()));
                        selected.y = Math.max(0f, Math.min(1f, selected.y + (y - ly) / getHeight()));
                        lx = x; ly = y;
                    } else if (mode == HANDLE) {
                        float cx = selected.x * getWidth(), cy = selected.y * getHeight();
                        selected.rot = snap(startRot + angle(cx, cy, x, y) - startAngle);
                        setSize(startSize * dist(cx, cy, x, y) / startDist);
                    } else if (mode == PINCH && e.getPointerCount() >= 2) {
                        float ang = angle(e.getX(0), e.getY(0), e.getX(1), e.getY(1));
                        float dd = dist(e.getX(0), e.getY(0), e.getX(1), e.getY(1));
                        selected.rot = snap(startRot + ang - startAngle);
                        setSize(startSize * dd / startDist);
                    } else return true;
                    invalidate();
                    if (listener != null) listener.onChanged();
                    return true;
                case MotionEvent.ACTION_POINTER_UP: {
                    int keep = e.getActionIndex() == 0 ? 1 : 0;
                    lx = e.getX(keep);
                    ly = e.getY(keep);
                    mode = selected != null ? DRAG : NONE;
                    return true;
                }
                default:
                    mode = NONE;
                    return true;
            }
        }
    }
}
