package app.tint;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.List;

final class Views {

    /** A frame that always has the photo's exact shape, fitted into the space available. */
    static final class AspectFrame extends FrameLayout {
        float ratio = 0.8f;
        boolean fill;              // true: take the whole space (full-screen camera)

        AspectFrame(Context c) { super(c); }

        void setRatio(float r) {
            if (Math.abs(r - ratio) < 0.0001f) return;
            ratio = r;
            requestLayout();
        }

        @Override
        protected void onMeasure(int ws, int hs) {
            int W = MeasureSpec.getSize(ws), H = MeasureSpec.getSize(hs);
            if (fill) {
                super.onMeasure(MeasureSpec.makeMeasureSpec(W, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(H, MeasureSpec.EXACTLY));
                return;
            }
            int w = W, h = Math.round(W / ratio);
            if (h > H) { h = H; w = Math.round(H * ratio); }
            super.onMeasure(MeasureSpec.makeMeasureSpec(Math.max(1, w), MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(Math.max(1, h), MeasureSpec.EXACTLY));
        }
    }

    /**
     * Holds the photo stage and lets two fingers zoom into it and move around (like the gallery).
     * One finger still does whatever the tab does (draw, drag text, hold to compare).
     * Two fingers on a picked text/picture still resize that item instead.
     */
    static final class ZoomHolder extends FrameLayout {
        View stage;
        Overlay overlay;
        android.widget.TextView badge;     // "2.4×" pill; tap it to go back to the whole photo
        float s = 1, tx, ty;
        private boolean zooming, swallow;
        private float s0, tx0, ty0, f0x, f0y, d0;

        ZoomHolder(Context c) { super(c); }

        boolean zoomed() { return s > 1.001f; }

        void reset(boolean animate) {
            s = 1; tx = 0; ty = 0;
            if (stage == null) return;
            if (animate) stage.animate().scaleX(1).scaleY(1).translationX(0).translationY(0).setDuration(220).start();
            else { stage.animate().cancel(); stage.setScaleX(1); stage.setScaleY(1); stage.setTranslationX(0); stage.setTranslationY(0); }
            showBadge();
        }

        private void apply() {
            float L = stage.getLeft(), T = stage.getTop(), w = stage.getWidth() * s, h = stage.getHeight() * s;
            int HW = getWidth(), HH = getHeight();
            if (w <= HW) tx = (HW - w) / 2 - L; else tx = Math.max(HW - w - L, Math.min(-L, tx));
            if (h <= HH) ty = (HH - h) / 2 - T; else ty = Math.max(HH - h - T, Math.min(-T, ty));
            if (s <= 1.001f) { tx = 0; ty = 0; }
            stage.setPivotX(0); stage.setPivotY(0);
            stage.setScaleX(s); stage.setScaleY(s);
            stage.setTranslationX(tx); stage.setTranslationY(ty);
            showBadge();
        }

        private void showBadge() {
            if (badge == null) return;
            boolean on = s > 1.01f;
            badge.setVisibility(on ? VISIBLE : GONE);
            if (on) badge.setText(String.format(java.util.Locale.US, "%.1f×   ⤢", s));
        }

        @Override
        public boolean dispatchTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) { zooming = false; swallow = false; }
            if (badge != null && badge.getVisibility() == VISIBLE && !zooming && !swallow && a == MotionEvent.ACTION_DOWN) {
                if (e.getX() >= badge.getLeft() && e.getX() <= badge.getRight() && e.getY() >= badge.getTop() && e.getY() <= badge.getBottom())
                    return super.dispatchTouchEvent(e);
            }
            if (!zooming && a == MotionEvent.ACTION_POINTER_DOWN && e.getPointerCount() == 2 && stage != null
                    && (overlay == null || !overlay.grabbingItem())) {
                // a second finger: this is a zoom, not a stroke or a compare; cancel what the first finger began
                if (overlay != null) overlay.abortGesture();
                MotionEvent c = MotionEvent.obtain(e);
                c.setAction(MotionEvent.ACTION_CANCEL);
                super.dispatchTouchEvent(c);
                c.recycle();
                zooming = true;
                s0 = s; tx0 = tx; ty0 = ty;
                f0x = (e.getX(0) + e.getX(1)) / 2; f0y = (e.getY(0) + e.getY(1)) / 2;
                d0 = Math.max(1, (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)));
                getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            }
            if (zooming) {
                if (a == MotionEvent.ACTION_MOVE && e.getPointerCount() >= 2) {
                    float fx = (e.getX(0) + e.getX(1)) / 2, fy = (e.getY(0) + e.getY(1)) / 2;
                    float dd = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                    float ns = Math.max(0.85f, Math.min(10f, s0 * dd / d0));
                    float L = stage.getLeft(), T = stage.getTop();
                    float px = (f0x - L - tx0) / s0, py = (f0y - T - ty0) / s0;   // the photo point that was under the fingers
                    s = ns;
                    tx = fx - L - s * px;
                    ty = fy - T - s * py;
                    float keepS = s;
                    if (s < 1) s = 1;
                    apply();
                    if (keepS < 1) { stage.setScaleX(keepS); stage.setScaleY(keepS); }   // a little give below 1×
                } else if (a == MotionEvent.ACTION_POINTER_UP && e.getPointerCount() == 2) {
                    zooming = false;
                    swallow = true;                         // the finger left behind shouldn't start drawing
                    if (s < 1.04f) reset(true);
                    else apply();
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    zooming = false;
                    if (s < 1.04f) reset(true);
                }
                return true;
            }
            if (swallow) {
                if (a == MotionEvent.ACTION_POINTER_DOWN && e.getPointerCount() == 2 && stage != null) {
                    zooming = true; swallow = false;
                    s0 = s; tx0 = tx; ty0 = ty;
                    f0x = (e.getX(0) + e.getX(1)) / 2; f0y = (e.getY(0) + e.getY(1)) / 2;
                    d0 = Math.max(1, (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)));
                }
                if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) swallow = false;
                return true;
            }
            return super.dispatchTouchEvent(e);
        }
    }

    /**
     * Draws text and pictures over the photo. While editing, the selected item shows a box with
     * a ✕ (delete) corner and a ↻ corner (drag to rotate + resize). Two fingers also rotate + resize.
     */
    static final class Overlay extends View {
        interface Listener {
            void onSelect(Item it);
            void onChanged();
            void onDelete(Item it);
        }

        final List<Item> items = new ArrayList<>();
        Item selected;
        boolean editing;
        Listener listener;
        ColorFilter liveFilter;   // quick preview of the photo filter on a picture being edited
        Doodle doodle;            // hand drawing (drawn under text)
        boolean drawing;          // Draw tab: fingers paint instead of moving things
        int brush, brushColor = Color.WHITE;
        float brushSize = 0.012f;
        Runnable onStroke;
        private Doodle.Stroke live;

        // ---- colour picker (eyedropper): touch the photo, a loupe shows the colour under your finger
        private java.util.function.IntConsumer eyedrop;
        private Bitmap eyeSrc;
        private boolean eyeActive;
        private float ex, ey;
        private int eyeColor;
        private final Paint eyeFill = new Paint(Paint.ANTI_ALIAS_FLAG), eyeRing = new Paint(Paint.ANTI_ALIAS_FLAG);

        /** Next touch on the photo picks a colour and hands it to `done`. */
        void startEyedrop(java.util.function.IntConsumer done) {
            cancelEyedrop();
            View p = (View) getParent();
            if (p == null || p.getWidth() == 0 || p.getHeight() == 0) return;
            try {
                eyeSrc = Bitmap.createBitmap(p.getWidth(), p.getHeight(), Bitmap.Config.ARGB_8888);
                p.draw(new Canvas(eyeSrc));        // exactly what you see: filter, pictures, text, drawing
            } catch (Throwable t) { eyeSrc = null; return; }
            eyedrop = done;
        }

        boolean eyedropping() { return eyedrop != null; }

        /** A finger is holding a text/picture: two fingers then resize it rather than zoom the photo. */
        boolean grabbingItem() { return editing && !drawing && eyedrop == null && selected != null && (mode == DRAG || mode == HANDLE || mode == PINCH); }

        /** The first finger's touch turned out to be the start of a zoom: undo whatever it began. */
        void abortGesture() {
            if (live != null && doodle != null) doodle.strokes.remove(live);
            live = null;
            mode = NONE;
            if (eyeActive) { eyeActive = false; }
            invalidate();
        }

        void cancelEyedrop() {
            eyedrop = null;
            eyeActive = false;
            if (eyeSrc != null) { eyeSrc.recycle(); eyeSrc = null; }
            invalidate();
        }

        private int sample(float x, float y) {
            int cx = Math.round(x), cy = Math.round(y), r = 0, g = 0, b = 0, n = 0;
            for (int j = -2; j <= 2; j++)
                for (int i = -2; i <= 2; i++) {
                    int px = Math.max(0, Math.min(eyeSrc.getWidth() - 1, cx + i));
                    int py = Math.max(0, Math.min(eyeSrc.getHeight() - 1, cy + j));
                    int c = eyeSrc.getPixel(px, py);
                    r += Color.red(c); g += Color.green(c); b += Color.blue(c); n++;
                }
            return Color.rgb(r / n, g / n, b / n);
        }

        private void drawLoupe(Canvas c) {
            float k = 1f / Math.max(1f, ((View) getParent()).getScaleX());
            float lx = ex, ly = ey - 78 * d * k, R = 34 * d * k;
            if (ly - R < 0) ly = ey + 78 * d * k;      // near the top: show it under the finger
            eyeRing.setStyle(Paint.Style.STROKE);
            eyeRing.setStrokeWidth(2 * d * k);
            eyeRing.setColor(0xCCFFFFFF);
            eyeRing.setShadowLayer(3 * d, 0, 0, 0x99000000);
            c.drawCircle(ex, ey, 9 * d * k, eyeRing);              // where the colour comes from
            eyeFill.setColor(eyeColor);
            eyeFill.setShadowLayer(8 * d, 0, 2 * d, 0x88000000);
            c.drawCircle(lx, ly, R, eyeFill);
            eyeRing.setStrokeWidth(4 * d * k);
            eyeRing.setColor(Color.WHITE);
            c.drawCircle(lx, ly, R, eyeRing);
        }
        float liveK = 1;

        private static final int NONE = 0, DRAG = 1, HANDLE = 2, PINCH = 3;
        private int mode;
        private float lx, ly, startAngle, startDist, startRot, startSize;
        private final float d;
        private final Paint box = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint knob = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glyph = new Paint(Paint.ANTI_ALIAS_FLAG);

        Overlay(Context c) {
            super(c);
            d = getResources().getDisplayMetrics().density;
            box.setStyle(Paint.Style.STROKE);
            box.setStrokeWidth(1.5f * d);
            box.setColor(0xDDFFFFFF);
            box.setPathEffect(new DashPathEffect(new float[]{6 * d, 5 * d}, 0));
            box.setShadowLayer(2 * d, 0, 0, 0x66000000);
            knob.setShadowLayer(3 * d, 0, d, 0x66000000);
            glyph.setTextAlign(Paint.Align.CENTER);
            glyph.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            glyph.setTextSize(14 * d);
        }

        /** Corner of the selected item's box after rotation: tl = top-left (✕), else bottom-right (↻). */
        private float[] corner(Item it, boolean tl) {
            float cx = it.x * getWidth(), cy = it.y * getHeight();
            float px = tl ? it.bounds.left : it.bounds.right;
            float py = tl ? it.bounds.top : it.bounds.bottom;
            double a = Math.toRadians(it.rot);
            float dx = px - cx, dy = py - cy;
            return new float[]{cx + (float) (dx * Math.cos(a) - dy * Math.sin(a)),
                               cy + (float) (dx * Math.sin(a) + dy * Math.cos(a))};
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            if (doodle != null) doodle.draw(c, w, h);
            try { drawItems(c, w, h); } finally { if (eyeActive) drawLoupe(c); }
        }

        private void drawItems(Canvas c, int w, int h) {
            for (Item it : items) {
                if (it instanceof Item.Sticker) {
                    Item.Sticker s = (Item.Sticker) it;
                    if (it.baked) s.layout(w, h);
                    else s.drawWith(c, w, h, liveFilter, liveK);
                } else if (MainActivity.isEmptyText(it)) {
                    it.bounds.setEmpty();             // nothing typed yet: no box on the photo
                } else {
                    it.draw(c, w, h);
                }
            }
            if (!editing || selected == null || MainActivity.isEmptyText(selected)) return;
            float cx = selected.x * w, cy = selected.y * h, r = 10 * d;
            c.save();
            c.rotate(selected.rot, cx, cy);
            c.drawRoundRect(selected.bounds, r, r, box);
            c.restore();
            drawKnob(c, corner(selected, true), Color.WHITE, 0xFF111111, "✕");
            drawKnob(c, corner(selected, false), 0xFFFF4D2E, Color.WHITE, "↻");
        }

        private void drawKnob(Canvas c, float[] p, int fill, int ink, String s) {
            knob.setColor(fill);
            c.drawCircle(p[0], p[1], 13 * d, knob);
            glyph.setColor(ink);
            c.drawText(s, p[0], p[1] - (glyph.descent() + glyph.ascent()) / 2, glyph);
        }

        private Item hit(float x, float y) {
            float slop = 12 * d;
            for (int i = items.size() - 1; i >= 0; i--) {
                Item it = items.get(i);
                if (MainActivity.isEmptyText(it)) continue;
                float cx = it.x * getWidth(), cy = it.y * getHeight();
                double a = Math.toRadians(-it.rot);
                float dx = x - cx, dy = y - cy;
                float rx = cx + (float) (dx * Math.cos(a) - dy * Math.sin(a));
                float ry = cy + (float) (dx * Math.sin(a) + dy * Math.cos(a));
                RectF b = it.bounds;
                if (rx >= b.left - slop && rx <= b.right + slop && ry >= b.top - slop && ry <= b.bottom + slop)
                    return it;
            }
            return null;
        }

        private static float dist(float x1, float y1, float x2, float y2) { return (float) Math.hypot(x2 - x1, y2 - y1); }
        private static float angle(float x1, float y1, float x2, float y2) { return (float) Math.toDegrees(Math.atan2(y2 - y1, x2 - x1)); }

        private float snap(float r) {
            float m = ((r % 360) + 360) % 360;
            for (int k = 0; k <= 360; k += 90) if (Math.abs(m - k) < 4) return r - (m - k);
            return r;
        }

        private void setSize(float v) {
            selected.size = Math.max(selected.minSize(), Math.min(selected.maxSize(), v));
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (eyedrop != null && eyeSrc != null) {
                float sx = (float) eyeSrc.getWidth() / Math.max(1, getWidth()), sy = (float) eyeSrc.getHeight() / Math.max(1, getHeight());
                ex = Math.max(0, Math.min(getWidth() - 1, e.getX()));
                ey = Math.max(0, Math.min(getHeight() - 1, e.getY()));
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        getParent().requestDisallowInterceptTouchEvent(true);
                        eyeActive = true;
                        // fall through
                    case MotionEvent.ACTION_MOVE: {
                        int was = eyeColor;
                        eyeColor = sample(ex * sx, ey * sy);
                        if (was != eyeColor && e.getActionMasked() == MotionEvent.ACTION_MOVE && Math.random() < 0.15)
                            performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK);
                        break;
                    }
                    case MotionEvent.ACTION_UP: {
                        java.util.function.IntConsumer done = eyedrop;
                        int col = eyeColor;
                        cancelEyedrop();
                        performHapticFeedback(android.view.HapticFeedbackConstants.CONFIRM);
                        if (done != null) done.accept(col);
                        return true;
                    }
                    case MotionEvent.ACTION_CANCEL:
                        eyeActive = false;
                        break;
                }
                invalidate();
                return true;
            }
            if (drawing && doodle != null) {
                float W = getWidth(), H = getHeight();
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        getParent().requestDisallowInterceptTouchEvent(true);
                        live = new Doodle.Stroke(brush, brushColor, brushSize);
                        live.add(e.getX() / W, e.getY() / H);
                        doodle.strokes.add(live);
                        break;
                    case MotionEvent.ACTION_MOVE:
                        if (live == null || e.getPointerCount() > 1) break;
                        for (int i = 0; i < e.getHistorySize(); i++)
                            live.add(e.getHistoricalX(i) / W, e.getHistoricalY(i) / H);
                        live.add(e.getX() / W, e.getY() / H);
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        live = null;
                        if (onStroke != null) onStroke.run();
                        break;
                }
                invalidate();
                return true;
            }
            if (!editing) return false;
            int a = e.getActionMasked();
            float x = e.getX(), y = e.getY();
            switch (a) {
                case MotionEvent.ACTION_DOWN: {
                    mode = NONE;
                    float hr = 24 * d;
                    if (selected != null && !MainActivity.isEmptyText(selected)) {
                        float[] del = corner(selected, true);
                        if (dist(x, y, del[0], del[1]) < hr) {
                            if (listener != null) listener.onDelete(selected);
                            return true;
                        }
                        float[] rot = corner(selected, false);
                        if (dist(x, y, rot[0], rot[1]) < hr) {
                            float cx = selected.x * getWidth(), cy = selected.y * getHeight();
                            mode = HANDLE;
                            startAngle = angle(cx, cy, x, y);
                            startDist = Math.max(1, dist(cx, cy, x, y));
                            startRot = selected.rot;
                            startSize = selected.size;
                            return true;
                        }
                    }
                    Item it = hit(x, y);
                    if (it == null) return false;          // lets the photo handle hold-to-compare
                    if (it != selected) {
                        selected = it;
                        if (listener != null) listener.onSelect(it);
                    }
                    mode = DRAG;
                    lx = x; ly = y;
                    invalidate();
                    return true;
                }
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (selected != null && e.getPointerCount() >= 2) {
                        mode = PINCH;
                        startAngle = angle(e.getX(0), e.getY(0), e.getX(1), e.getY(1));
                        startDist = Math.max(1, dist(e.getX(0), e.getY(0), e.getX(1), e.getY(1)));
                        startRot = selected.rot;
                        startSize = selected.size;
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (selected == null) return true;
                    if (mode == DRAG) {
                        selected.x = Math.max(0f, Math.min(1f, selected.x + (x - lx) / getWidth()));
                        selected.y = Math.max(0f, Math.min(1f, selected.y + (y - ly) / getHeight()));
                        lx = x; ly = y;
                    } else if (mode == HANDLE) {
                        float cx = selected.x * getWidth(), cy = selected.y * getHeight();
                        selected.rot = snap(startRot + angle(cx, cy, x, y) - startAngle);
                        setSize(startSize * dist(cx, cy, x, y) / startDist);
                    } else if (mode == PINCH && e.getPointerCount() >= 2) {
                        float ang = angle(e.getX(0), e.getY(0), e.getX(1), e.getY(1));
                        float dd = dist(e.getX(0), e.getY(0), e.getX(1), e.getY(1));
                        selected.rot = snap(startRot + ang - startAngle);
                        setSize(startSize * dd / startDist);
                    } else return true;
                    invalidate();
                    if (listener != null) listener.onChanged();
                    return true;
                case MotionEvent.ACTION_POINTER_UP: {
                    int keep = e.getActionIndex() == 0 ? 1 : 0;
                    lx = e.getX(keep);
                    ly = e.getY(keep);
                    mode = selected != null ? DRAG : NONE;
                    return true;
                }
                default:
                    mode = NONE;
                    return true;
            }
        }
    }

    /** Crop box over a picture: drag corners to resize, drag inside to move. */
    static final class CropView extends View {
        final Bitmap bmp;
        final RectF img = new RectF(), crop = new RectF();
        float aspect;           // 0 = free
        boolean circle;
        private int drag;       // 0 none, 1 move, 2 tl, 3 tr, 4 bl, 5 br
        private float lx, ly;
        private final float d;
        private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        private final Paint shade = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint knob = new Paint(Paint.ANTI_ALIAS_FLAG);

        CropView(Context c, Bitmap b) {
            super(c);
            bmp = b;
            d = getResources().getDisplayMetrics().density;
            shade.setColor(0xB0000000);
            line.setStyle(Paint.Style.STROKE);
            line.setColor(Color.WHITE);
            knob.setColor(Color.WHITE);
            knob.setStyle(Paint.Style.STROKE);
            knob.setStrokeWidth(4 * d);
            knob.setStrokeCap(Paint.Cap.ROUND);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            float pad = 24 * d;
            float s = Math.min((w - 2 * pad) / bmp.getWidth(), (h - 2 * pad) / bmp.getHeight());
            float iw = bmp.getWidth() * s, ih = bmp.getHeight() * s;
            img.set((w - iw) / 2, (h - ih) / 2, (w + iw) / 2, (h + ih) / 2);
            setAspect(aspect, circle);
        }

        void setAspect(float a, boolean circ) {
            aspect = a;
            circle = circ;
            if (img.isEmpty()) return;
            if (a <= 0) { crop.set(img); }
            else {
                float w = img.width(), h = w / a;
                if (h > img.height()) { h = img.height(); w = h * a; }
                crop.set(img.centerX() - w / 2, img.centerY() - h / 2, img.centerX() + w / 2, img.centerY() + h / 2);
            }
            invalidate();
        }

        /** Crop rectangle in bitmap pixels. */
        Rect result() {
            float s = bmp.getWidth() / img.width();
            int l = Math.round((crop.left - img.left) * s), t = Math.round((crop.top - img.top) * s);
            int r = Math.round((crop.right - img.left) * s), b = Math.round((crop.bottom - img.top) * s);
            l = Math.max(0, l); t = Math.max(0, t);
            r = Math.min(bmp.getWidth(), Math.max(l + 1, r)); b = Math.min(bmp.getHeight(), Math.max(t + 1, b));
            return new Rect(l, t, r, b);
        }

        @Override
        protected void onDraw(Canvas c) {
            c.drawBitmap(bmp, null, img, paint);
            Path p = new Path();
            p.setFillType(Path.FillType.EVEN_ODD);
            p.addRect(img, Path.Direction.CW);
            if (circle) p.addOval(crop, Path.Direction.CW); else p.addRect(crop, Path.Direction.CW);
            c.drawPath(p, shade);
            line.setStrokeWidth(d);
            line.setAlpha(110);
            for (int i = 1; i < 3; i++) {
                float x = crop.left + crop.width() * i / 3, y = crop.top + crop.height() * i / 3;
                c.drawLine(x, crop.top, x, crop.bottom, line);
                c.drawLine(crop.left, y, crop.right, y, line);
            }
            line.setAlpha(255);
            line.setStrokeWidth(1.5f * d);
            if (circle) c.drawOval(crop, line); else c.drawRect(crop, line);
            float k = 18 * d;
            float[][] cs = {{crop.left, crop.top, 1, 1}, {crop.right, crop.top, -1, 1},
                            {crop.left, crop.bottom, 1, -1}, {crop.right, crop.bottom, -1, -1}};
            for (float[] q : cs) {
                c.drawLine(q[0], q[1], q[0] + k * q[2], q[1], knob);
                c.drawLine(q[0], q[1], q[0], q[1] + k * q[3], knob);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            float x = e.getX(), y = e.getY();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: {
                    float r = 32 * d;
                    float[][] cs = {{crop.left, crop.top}, {crop.right, crop.top}, {crop.left, crop.bottom}, {crop.right, crop.bottom}};
                    drag = 0;
                    for (int i = 0; i < 4; i++)
                        if (Math.hypot(x - cs[i][0], y - cs[i][1]) < r) { drag = 2 + i; break; }
                    if (drag == 0 && crop.contains(x, y)) drag = 1;
                    lx = x; ly = y;
                    return true;
                }
                case MotionEvent.ACTION_MOVE: {
                    if (drag == 1) {
                        float dx = Math.max(img.left - crop.left, Math.min(img.right - crop.right, x - lx));
                        float dy = Math.max(img.top - crop.top, Math.min(img.bottom - crop.bottom, y - ly));
                        crop.offset(dx, dy);
                    } else if (drag >= 2) {
                        boolean left = drag == 2 || drag == 4, top = drag == 2 || drag == 3;
                        float ox = left ? crop.right : crop.left, oy = top ? crop.bottom : crop.top;
                        float px = Math.max(img.left, Math.min(img.right, x));
                        float py = Math.max(img.top, Math.min(img.bottom, y));
                        float min = 48 * d;
                        float w = Math.max(min, Math.abs(px - ox)), h = Math.max(min, Math.abs(py - oy));
                        if (aspect > 0) { if (w / h > aspect) w = h * aspect; else h = w / aspect; }
                        float nl = left ? ox - w : ox, nr = left ? ox : ox + w;
                        float nt = top ? oy - h : oy, nb = top ? oy : oy + h;
                        if (nl >= img.left - 0.5f && nr <= img.right + 0.5f && nt >= img.top - 0.5f && nb <= img.bottom + 0.5f)
                            crop.set(nl, nt, nr, nb);
                    }
                    lx = x; ly = y;
                    invalidate();
                    return true;
                }
                default:
                    drag = 0;
                    return true;
            }
        }
    }

    /** Refine a cut-out by hand: one finger paints (erase / restore), two fingers zoom and move. */
    static final class MaskBrushView extends View {
        final Bitmap img;
        Bitmap mask;
        final BaseEdit edit;
        boolean restore;
        float brushDp = 34;
        final java.util.ArrayDeque<Bitmap> undo = new java.util.ArrayDeque<>();
        Runnable onUndoChanged;

        private final Matrix view = new Matrix(), inv = new Matrix();
        private final float d;
        private final Paint imgP = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final Paint ghost = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final Paint maskP = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Canvas mc;
        private android.graphics.drawable.Drawable checker;
        private boolean painting, transforming, fitted;
        private float lx, ly, fx, fy, startDist, startScale;
        private float pmx, pmy;
        private final float[] pt = new float[2];

        MaskBrushView(Context c, Bitmap img, Bitmap mask, BaseEdit edit, android.graphics.drawable.Drawable checker) {
            super(c);
            this.img = img;
            this.mask = mask;
            this.edit = edit;
            this.checker = checker;
            d = getResources().getDisplayMetrics().density;
            mc = new Canvas(mask);
            ghost.setAlpha(70);
            maskP.setColorFilter(edit.levels());
            maskP.setBlendMode(BlendMode.DST_IN);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(1.5f * d);
            ring.setColor(Color.WHITE);
            ring.setShadowLayer(2 * d, 0, 0, 0xAA000000);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            stroke.setStrokeJoin(Paint.Join.ROUND);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            if (fitted) return;
            fitted = true;
            float pad = 16 * d;
            float s = Math.min((w - 2 * pad) / img.getWidth(), (h - 2 * pad) / img.getHeight());
            view.setScale(s, s);
            view.postTranslate((w - img.getWidth() * s) / 2, (h - img.getHeight() * s) / 2);
        }

        private float scale() { float[] v = new float[9]; view.getValues(v); return v[0]; }

        @Override
        protected void onDraw(Canvas c) {
            checker.setBounds(0, 0, getWidth(), getHeight());
            checker.draw(c);
            c.save();
            c.concat(view);
            c.drawBitmap(img, 0, 0, ghost);                      // faint original: shows what can be restored
            int sc = c.saveLayer(0, 0, img.getWidth(), img.getHeight(), null);
            c.drawBitmap(img, 0, 0, imgP);
            c.drawBitmap(mask, null, new RectF(0, 0, img.getWidth(), img.getHeight()), maskP);
            c.restoreToCount(sc);
            c.restore();
            if (painting) c.drawCircle(fx, fy, brushDp * d / 2, ring);
        }

        private void pushUndo() {
            undo.push(mask.copy(Bitmap.Config.ARGB_8888, false));
            while (undo.size() > 6) undo.removeLast().recycle();
            if (onUndoChanged != null) onUndoChanged.run();
        }

        void undo() {
            if (undo.isEmpty()) return;
            Bitmap b = undo.pop();
            mc.drawColor(0, PorterDuff.Mode.CLEAR);
            mc.drawBitmap(b, 0, 0, null);
            b.recycle();
            invalidate();
            if (onUndoChanged != null) onUndoChanged.run();
        }

        private void toMask(float x, float y) {
            view.invert(inv);
            pt[0] = x; pt[1] = y;
            inv.mapPoints(pt);
            pt[0] *= (float) mask.getWidth() / img.getWidth();
            pt[1] *= (float) mask.getHeight() / img.getHeight();
        }

        private void paintTo(float x, float y, boolean first) {
            toMask(x, y);
            float w = brushDp * d / scale() * mask.getWidth() / img.getWidth();
            stroke.setStrokeWidth(w);
            stroke.setMaskFilter(new BlurMaskFilter(Math.max(1, w * 0.12f), BlurMaskFilter.Blur.NORMAL));
            if (restore) {
                stroke.setXfermode(null);
                stroke.setColor(0xFF000000);
            } else {
                stroke.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
                stroke.setColor(0xFF000000);
            }
            if (first) { pmx = pt[0]; pmy = pt[1]; }
            mc.drawLine(pmx, pmy, pt[0] + 0.01f, pt[1], stroke);
            pmx = pt[0]; pmy = pt[1];
        }

        private static float dist(MotionEvent e) { return (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)); }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    transforming = false;
                    painting = true;
                    fx = e.getX(); fy = e.getY();
                    pushUndo();
                    paintTo(fx, fy, true);
                    invalidate();
                    return true;
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (e.getPointerCount() == 2) {
                        if (painting) undo();            // the first finger was the start of a zoom, not a stroke
                        painting = false;
                        transforming = true;
                        startDist = Math.max(1, dist(e));
                        startScale = scale();
                        lx = (e.getX(0) + e.getX(1)) / 2;
                        ly = (e.getY(0) + e.getY(1)) / 2;
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (transforming && e.getPointerCount() >= 2) {
                        float mx = (e.getX(0) + e.getX(1)) / 2, my = (e.getY(0) + e.getY(1)) / 2;
                        float target = Math.max(0.2f, Math.min(startScale * 12, startScale * dist(e) / startDist));
                        float f = target / scale();
                        view.postTranslate(mx - lx, my - ly);
                        view.postScale(f, f, mx, my);
                        lx = mx; ly = my;
                    } else if (painting) {
                        fx = e.getX(); fy = e.getY();
                        paintTo(fx, fy, false);
                    }
                    invalidate();
                    return true;
                default:
                    if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                        painting = false;
                        transforming = false;
                    }
                    invalidate();
                    return true;
            }
        }
    }

    /** Lays children out in rows and wraps to the next row when full; rows are centred. */
    static final class Flow extends android.view.ViewGroup {
        int gap;

        Flow(Context c, int gapPx) { super(c); gap = gapPx; }

        @Override
        protected void onMeasure(int ws, int hs) {
            int maxW = MeasureSpec.getSize(ws) - getPaddingLeft() - getPaddingRight();
            int x = 0, y = 0, rowH = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View ch = getChildAt(i);
                if (ch.getVisibility() == GONE) continue;
                LayoutParams lp = ch.getLayoutParams();
                ch.measure(MeasureSpec.makeMeasureSpec(lp.width, MeasureSpec.EXACTLY),
                        MeasureSpec.makeMeasureSpec(lp.height, MeasureSpec.EXACTLY));
                if (x > 0 && x + ch.getMeasuredWidth() > maxW) { x = 0; y += rowH + gap; rowH = 0; }
                x += ch.getMeasuredWidth() + gap;
                rowH = Math.max(rowH, ch.getMeasuredHeight());
            }
            setMeasuredDimension(MeasureSpec.getSize(ws), y + rowH + getPaddingTop() + getPaddingBottom());
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int maxW = r - l - getPaddingLeft() - getPaddingRight();
            int i = 0, y = getPaddingTop();
            while (i < getChildCount()) {
                int j = i, w = 0, rowH = 0;
                while (j < getChildCount()) {
                    View ch = getChildAt(j);
                    if (ch.getVisibility() == GONE) { j++; continue; }
                    int add = (w > 0 ? gap : 0) + ch.getMeasuredWidth();
                    if (w > 0 && w + add > maxW) break;
                    w += add;
                    rowH = Math.max(rowH, ch.getMeasuredHeight());
                    j++;
                }
                int x = getPaddingLeft() + (maxW - w) / 2;
                for (int k = i; k < j; k++) {
                    View ch = getChildAt(k);
                    if (ch.getVisibility() == GONE) continue;
                    ch.layout(x, y, x + ch.getMeasuredWidth(), y + ch.getMeasuredHeight());
                    x += ch.getMeasuredWidth() + gap;
                }
                y += rowH + gap;
                i = j;
            }
        }
    }

    /** Hue / saturation / brightness picker. */
    static final class ColorPicker extends View {
        interface Listener { void onColor(int c); }

        final float[] hsv = new float[3];
        Listener listener;
        private final RectF sv = new RectF(), hue = new RectF();
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint knob = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;
        private int drag;          // 1 = square, 2 = hue bar

        ColorPicker(Context c, int color) {
            super(c);
            d = getResources().getDisplayMetrics().density;
            Color.colorToHSV(color, hsv);
            knob.setStyle(Paint.Style.STROKE);
            knob.setStrokeWidth(3 * d);
            knob.setColor(Color.WHITE);
            knob.setShadowLayer(3 * d, 0, d, 0x88000000);
        }

        int color() { return Color.HSVToColor(hsv); }

        void setColor(int c) { Color.colorToHSV(c, hsv); invalidate(); }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            float pad = 6 * d, barH = 26 * d, gap = 18 * d;
            sv.set(pad, pad, w - pad, h - pad - barH - gap);
            hue.set(pad, h - pad - barH, w - pad, h - pad);
        }

        @Override
        protected void onDraw(Canvas c) {
            float r = 16 * d;
            int pure = Color.HSVToColor(new float[]{hsv[0], 1, 1});
            p.setShader(new LinearGradient(sv.left, 0, sv.right, 0, Color.WHITE, pure, Shader.TileMode.CLAMP));
            c.drawRoundRect(sv, r, r, p);
            p.setShader(new LinearGradient(0, sv.top, 0, sv.bottom, 0x00000000, 0xFF000000, Shader.TileMode.CLAMP));
            c.drawRoundRect(sv, r, r, p);
            int[] hues = new int[7];
            for (int i = 0; i < 7; i++) hues[i] = Color.HSVToColor(new float[]{i * 60f, 1, 1});
            p.setShader(new LinearGradient(hue.left, 0, hue.right, 0, hues, null, Shader.TileMode.CLAMP));
            c.drawRoundRect(hue, hue.height() / 2, hue.height() / 2, p);
            p.setShader(null);
            float kx = sv.left + hsv[1] * sv.width(), ky = sv.top + (1 - hsv[2]) * sv.height();
            p.setColor(color());
            c.drawCircle(kx, ky, 11 * d, p);
            c.drawCircle(kx, ky, 11 * d, knob);
            float hx = hue.left + hsv[0] / 360f * hue.width();
            p.setColor(pure);
            c.drawCircle(hx, hue.centerY(), 13 * d, p);
            c.drawCircle(hx, hue.centerY(), 13 * d, knob);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            float x = e.getX(), y = e.getY();
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                drag = y > sv.bottom + 6 * d ? 2 : 1;
                getParent().requestDisallowInterceptTouchEvent(true);
            }
            if (drag == 1) {
                hsv[1] = Math.max(0, Math.min(1, (x - sv.left) / sv.width()));
                hsv[2] = 1 - Math.max(0, Math.min(1, (y - sv.top) / sv.height()));
            } else if (drag == 2) {
                hsv[0] = Math.max(0, Math.min(359.9f, (x - hue.left) / hue.width() * 360f));
            }
            invalidate();
            if (listener != null) listener.onColor(color());
            if (e.getActionMasked() == MotionEvent.ACTION_UP) drag = 0;
            return true;
        }
    }
}
