package app.tint;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.List;

final class Views {

    /** A frame that always has the photo's exact shape, fitted into the space available. */
    static final class AspectFrame extends FrameLayout {
        float ratio = 0.8f;

        AspectFrame(Context c) { super(c); }

        void setRatio(float r) {
            if (Math.abs(r - ratio) < 0.0001f) return;
            ratio = r;
            requestLayout();
        }

        @Override
        protected void onMeasure(int ws, int hs) {
            int W = MeasureSpec.getSize(ws), H = MeasureSpec.getSize(hs);
            int w = W, h = Math.round(W / ratio);
            if (h > H) { h = H; w = Math.round(H * ratio); }
            super.onMeasure(MeasureSpec.makeMeasureSpec(Math.max(1, w), MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(Math.max(1, h), MeasureSpec.EXACTLY));
        }
    }

    /** Draws the text layers over the photo. In edit mode they can be dragged and pinched. */
    static final class TextOverlay extends View {
        interface Listener { void onSelect(TextArt.Layer l); void onChanged(); }

        final List<TextArt.Layer> layers = new ArrayList<>();
        TextArt.Layer selected;
        boolean editing;
        Listener listener;

        private float lx, ly;
        private boolean dragging;
        private final Paint sel = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final ScaleGestureDetector scaler;

        TextOverlay(Context c) {
            super(c);
            float d = getResources().getDisplayMetrics().density;
            sel.setStyle(Paint.Style.STROKE);
            sel.setStrokeWidth(1.5f * d);
            sel.setColor(0xCCFFFFFF);
            sel.setPathEffect(new DashPathEffect(new float[]{6 * d, 5 * d}, 0));
            scaler = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector det) {
                    if (selected == null) return false;
                    selected.size = Math.max(0.02f, Math.min(0.5f, selected.size * det.getScaleFactor()));
                    invalidate();
                    if (listener != null) listener.onChanged();
                    return true;
                }
            });
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            for (TextArt.Layer l : layers) TextArt.draw(c, w, h, l);
            if (editing && selected != null) {
                float r = 10 * getResources().getDisplayMetrics().density;
                c.drawRoundRect(selected.bounds, r, r, sel);
            }
        }

        private TextArt.Layer hit(float x, float y) {
            float slop = 14 * getResources().getDisplayMetrics().density;
            for (int i = layers.size() - 1; i >= 0; i--) {
                RectF b = layers.get(i).bounds;
                if (x >= b.left - slop && x <= b.right + slop && y >= b.top - slop && y <= b.bottom + slop)
                    return layers.get(i);
            }
            return null;
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (!editing) return false;
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                TextArt.Layer l = hit(e.getX(), e.getY());
                if (l == null) return false;           // let the photo handle hold-to-compare
                if (l != selected) {
                    selected = l;
                    if (listener != null) listener.onSelect(l);
                }
                dragging = true;
                lx = e.getX();
                ly = e.getY();
                invalidate();
            }
            scaler.onTouchEvent(e);
            if (a == MotionEvent.ACTION_MOVE && dragging && selected != null && e.getPointerCount() == 1
                    && !scaler.isInProgress()) {
                selected.x += (e.getX() - lx) / getWidth();
                selected.y += (e.getY() - ly) / getHeight();
                selected.x = Math.max(0f, Math.min(1f, selected.x));
                selected.y = Math.max(0f, Math.min(1f, selected.y));
                invalidate();
            }
            if (a == MotionEvent.ACTION_MOVE || a == MotionEvent.ACTION_POINTER_UP) {
                lx = e.getX();
                ly = e.getY();
            }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) dragging = false;
            return true;
        }
    }
}
