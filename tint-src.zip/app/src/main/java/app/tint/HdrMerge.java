package app.tint;

import android.graphics.Bitmap;
import android.media.Image;

import java.nio.ByteBuffer;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * HDR+-style burst merge, done on the phone:
 *  1. each frame of a fast burst is aligned to the first one (cancels hand shake),
 *  2. frames are averaged, skipping pixels that moved (no ghosts) → much less noise,
 *  3. local tone mapping lifts shadows and keeps highlights, local contrast + gentle sharpening,
 *  4. chroma follows brightness so colours stay rich in lifted shadows.
 * Works on YUV frames to keep memory low (about 80 MB for a 12 MP photo).
 */
final class HdrMerge {
    static final ExecutorService POOL = Executors.newFixedThreadPool(Math.max(2, Math.min(6, Runtime.getRuntime().availableProcessors())));

    final int w, h, cw, ch;
    final float gain;              // brightness to restore (bursts are shot a little darker to protect highlights)
    final boolean night;           // stronger noise cleaning and shadow lift
    byte[] refY, refU, refV, curY, curU, curV;
    short[] sumY, sumU, sumV;
    byte[] refS;                   // 1/8 size reference for alignment
    int sw, sh, n;
    float sigma = -1;              // estimated per-frame noise (luma levels)

    HdrMerge(int w, int h, float gain, boolean night) {
        this.w = w; this.h = h; this.gain = gain; this.night = night;
        cw = w / 2; ch = h / 2;
        sw = w / 8; sh = h / 8;
    }

    interface Rows { void run(int from, int to); }

    static void parallel(int rows, Rows r) {
        int parts = 6;
        CountDownLatch done = new CountDownLatch(parts);
        for (int i = 0; i < parts; i++) {
            final int a = rows * i / parts, b = rows * (i + 1) / parts;
            POOL.execute(() -> { try { r.run(a, b); } finally { done.countDown(); } });
        }
        try { done.await(); } catch (InterruptedException ignored) { }
    }

    // ------------------------------------------------------------------ reading frames

    private static void readPlane(Image.Plane p, byte[] dst, int pw, int ph) {
        ByteBuffer b = p.getBuffer();
        int rs = p.getRowStride(), ps = p.getPixelStride();
        if (ps == 1) {
            for (int y = 0; y < ph; y++) {
                b.position(y * rs);
                b.get(dst, y * pw, pw);
            }
        } else {
            byte[] row = new byte[rs];
            int need = (pw - 1) * ps + 1;
            for (int y = 0; y < ph; y++) {
                b.position(y * rs);
                b.get(row, 0, Math.min(need, b.remaining()));
                for (int x = 0, o = y * pw; x < pw; x++) dst[o + x] = row[x * ps];
            }
        }
    }

    private byte[] small(byte[] y) {
        byte[] s = new byte[sw * sh];
        parallel(sh, (a, b) -> {
            for (int j = a; j < b; j++)
                for (int i = 0; i < sw; i++) {
                    int sum = 0;
                    for (int yy = 0; yy < 8; yy += 2)
                        for (int xx = 0; xx < 8; xx += 2) sum += y[(j * 8 + yy) * w + i * 8 + xx] & 255;
                    s[j * sw + i] = (byte) (sum >> 4);
                }
        });
        return s;
    }

    /** Adds one frame. The first frame is the reference everything else is aligned to. */
    void add(Image img) {
        Image.Plane[] p = img.getPlanes();
        if (curY == null) { curY = new byte[w * h]; curU = new byte[cw * ch]; curV = new byte[cw * ch]; }
        readPlane(p[0], curY, w, h);
        readPlane(p[1], curU, cw, ch);
        readPlane(p[2], curV, cw, ch);
        if (n == 0) {
            refY = curY; refU = curU; refV = curV;
            curY = null; curU = null; curV = null;
            sumY = new short[w * h];
            sumU = new short[cw * ch];
            sumV = new short[cw * ch];
            final byte[] ry = refY, ru = refU, rv = refV;
            parallel(h, (a, b) -> { for (int i = a * w; i < b * w; i++) sumY[i] = (short) (ry[i] & 255); });
            for (int i = 0; i < cw * ch; i++) { sumU[i] = (short) (ru[i] & 255); sumV[i] = (short) (rv[i] & 255); }
            refS = small(refY);
            n = 1;
            return;
        }
        int[] off = align();
        if (sigma < 0) sigma = noise(off[0], off[1]);
        int thr = Math.round(Math.max(10, Math.min(48, sigma * 3.2f)));
        merge(curY, refY, sumY, w, h, off[0], off[1], thr);
        merge(curU, refU, sumU, cw, ch, off[0] / 2, off[1] / 2, Math.max(8, thr * 3 / 4));
        merge(curV, refV, sumV, cw, ch, off[0] / 2, off[1] / 2, Math.max(8, thr * 3 / 4));
        n++;
    }

    /** Finds the shift (dx, dy) that best lines the current frame up with the reference. */
    private int[] align() {
        byte[] cs = small(curY);
        int best = Integer.MAX_VALUE, bx = 0, by = 0, R = 12;
        int x0 = sw / 6, x1 = sw - sw / 6, y0 = sh / 6, y1 = sh - sh / 6;
        for (int dy = -R; dy <= R; dy++)
            for (int dx = -R; dx <= R; dx++) {
                int sad = 0;
                for (int y = y0; y < y1 && sad < best; y += 2) {
                    int sy = y + dy;
                    if (sy < 0 || sy >= sh) { sad += 4096; continue; }
                    for (int x = x0; x < x1; x += 2) {
                        int sx = x + dx;
                        if (sx < 0 || sx >= sw) { sad += 64; continue; }
                        sad += Math.abs((cs[sy * sw + sx] & 255) - (refS[y * sw + x] & 255));
                    }
                }
                if (sad < best) { best = sad; bx = dx; by = dy; }
            }
        // refine at full resolution around the coarse answer
        int fx = bx * 8, fy = by * 8, fbest = Integer.MAX_VALUE, rx = fx, ry = fy;
        int X0 = w / 5, X1 = w - w / 5, Y0 = h / 5, Y1 = h - h / 5;
        for (int dy = fy - 7; dy <= fy + 7; dy++)
            for (int dx = fx - 7; dx <= fx + 7; dx++) {
                int sad = 0;
                for (int y = Y0; y < Y1 && sad < fbest; y += 12) {
                    int sy = y + dy;
                    if (sy < 0 || sy >= h) continue;
                    for (int x = X0; x < X1; x += 12) {
                        int sx = x + dx;
                        if (sx < 0 || sx >= w) continue;
                        sad += Math.abs((curY[sy * w + sx] & 255) - (refY[y * w + x] & 255));
                    }
                }
                if (sad < fbest) { fbest = sad; rx = dx; ry = dy; }
            }
        return new int[]{rx, ry};
    }

    /** Estimates sensor noise from the difference between two aligned frames (median, so motion is ignored). */
    private float noise(int dx, int dy) {
        int[] hist = new int[256];
        int cnt = 0;
        for (int y = h / 6; y < h - h / 6; y += 7) {
            int sy = y + dy;
            if (sy < 0 || sy >= h) continue;
            for (int x = w / 6; x < w - w / 6; x += 7) {
                int sx = x + dx;
                if (sx < 0 || sx >= w) continue;
                hist[Math.abs((curY[sy * w + sx] & 255) - (refY[y * w + x] & 255))]++;
                cnt++;
            }
        }
        int half = cnt / 2, acc = 0, med = 0;
        for (int i = 0; i < 256; i++) { acc += hist[i]; if (acc >= half) { med = i; break; } }
        return Math.max(1.5f, med / 0.954f);     // median |a-b| = 0.954·σ for two noisy frames
    }

    /** Robust average: a pixel that differs a lot from the reference (something moved) is not used. */
    private static void merge(byte[] cur, byte[] ref, short[] sum, int pw, int ph, int dx, int dy, int thr) {
        parallel(ph, (a, b) -> {
            for (int y = a; y < b; y++) {
                int sy = y + dy;
                boolean rowOk = sy >= 0 && sy < ph;
                for (int x = 0; x < pw; x++) {
                    int i = y * pw + x;
                    int r = ref[i] & 255, v = r;
                    int sx = x + dx;
                    if (rowOk && sx >= 0 && sx < pw) {
                        int c = cur[sy * pw + sx] & 255;
                        int d = Math.abs(c - r);
                        if (d <= thr) v = c;
                        else if (d < thr * 2) v = (c * (thr * 2 - d) + r * (d - thr)) / thr;
                    }
                    sum[i] += v;
                }
            }
        });
    }

    // ------------------------------------------------------------------ finishing

    private short[] boxChroma(short[] s) {
        short[] o = new short[s.length];
        parallel(ch, (a, b) -> {
            for (int y = a; y < b; y++)
                for (int x = 0; x < cw; x++) {
                    int sum = 0, c = 0;
                    for (int j = -1; j <= 1; j++) {
                        int yy = y + j;
                        if (yy < 0 || yy >= ch) continue;
                        for (int i = -1; i <= 1; i++) {
                            int xx = x + i;
                            if (xx < 0 || xx >= cw) continue;
                            sum += s[yy * cw + xx]; c++;
                        }
                    }
                    o[y * cw + x] = (short) (sum / c);
                }
        });
        return o;
    }

    private static float clamp(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }

    /** Tone maps the merged frames and returns the final colour photo. */
    Bitmap finish() {
        final int N = n;
        // merged brightness
        final byte[] Y = refY;                          // reuse memory
        parallel(h, (a, b) -> { for (int i = a * w; i < b * w; i++) Y[i] = (byte) Math.min(255, (sumY[i] + N / 2) / N); });
        sumY = null;
        curY = null;
        // very blurred "base" layer (1/16 size, smoothed) for local tone mapping
        final int bw = Math.max(2, w / 16), bh = Math.max(2, h / 16);
        final float[] base = new float[bw * bh];
        parallel(bh, (a, b) -> {
            for (int j = a; j < b; j++)
                for (int i = 0; i < bw; i++) {
                    int s = 0, c = 0;
                    for (int yy = 0; yy < 16; yy += 4)
                        for (int xx = 0; xx < 16; xx += 4) {
                            int yv = j * 16 + yy, xv = i * 16 + xx;
                            if (yv < h && xv < w) { s += Y[yv * w + xv] & 255; c++; }
                        }
                    base[j * bw + i] = c == 0 ? 0 : s / (float) c;
                }
        });
        float[] tmp = new float[bw * bh];
        for (int pass = 0; pass < 3; pass++) {                      // 3 box blurs ≈ gaussian
            for (int j = 0; j < bh; j++)
                for (int i = 0; i < bw; i++) {
                    float s = 0; int c = 0;
                    for (int k = -2; k <= 2; k++) { int ii = i + k; if (ii >= 0 && ii < bw) { s += base[j * bw + ii]; c++; } }
                    tmp[j * bw + i] = s / c;
                }
            for (int j = 0; j < bh; j++)
                for (int i = 0; i < bw; i++) {
                    float s = 0; int c = 0;
                    for (int k = -2; k <= 2; k++) { int jj = j + k; if (jj >= 0 && jj < bh) { s += tmp[jj * bw + i]; c++; } }
                    base[j * bw + i] = s / c;
                }
        }
        // chroma noise cleanup: 3×3 average of the (already half-size) colour planes
        final short[] SU = night ? boxChroma(boxChroma(sumU)) : boxChroma(sumU);
        final short[] SV = night ? boxChroma(boxChroma(sumV)) : boxChroma(sumV);
        sumU = sumV = null;
        final float res = Math.max(1f, (sigma < 0 ? 4 : sigma) / (float) Math.sqrt(N)) * gain;   // noise left after merging
        final float flat = res * (night ? 3.3f : 2.6f) + 1.5f;
        final float smooth = night ? 0.85f : 0.7f, liftK = night ? 0.62f : 0.42f;
        final Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        parallel(h, (a, b) -> {
            int[] row = new int[w];
            for (int y = a; y < b; y++) {
                float fy = y * (bh - 1f) / Math.max(1, h - 1);
                int by0 = Math.min(bh - 2, (int) fy);
                float ty = fy - by0;
                int yUp = Math.max(0, y - 1), yDn = Math.min(h - 1, y + 1);
                int cy = Math.min(ch - 1, y / 2);
                for (int x = 0; x < w; x++) {
                    float fx = x * (bw - 1f) / Math.max(1, w - 1);
                    int bx0 = Math.min(bw - 2, (int) fx);
                    float tx = fx - bx0;
                    float B = (base[by0 * bw + bx0] * (1 - tx) + base[by0 * bw + bx0 + 1] * tx) * (1 - ty)
                            + (base[(by0 + 1) * bw + bx0] * (1 - tx) + base[(by0 + 1) * bw + bx0 + 1] * tx) * ty;
                    int i = y * w + x;
                    float L = Y[i] & 255;
                    // gentle sharpening from the 4 neighbours
                    int xl = Math.max(0, x - 1), xr = Math.min(w - 1, x + 1);
                    float nb = ((Y[y * w + xl] & 255) + (Y[y * w + xr] & 255) + (Y[yUp * w + x] & 255) + (Y[yDn * w + x] & 255)) * 0.25f;
                    float diff = L - nb;
                    float ad = Math.abs(diff);
                    float sharp;
                    if (ad < flat) {                 // flat area: smooth away the remaining grain
                        L = L + (nb - L) * smooth * (1 - ad / flat);
                        sharp = 0;
                    } else {                          // real edge: crisp it up
                        sharp = diff * 0.5f;
                    }
                    // local tone mapping: brighten the base (shadows most), keep detail, protect highlights
                    float b0 = clamp(B / 255f * gain);
                    float lifted = b0 + liftK * b0 * (1 - b0) * (1 - b0) * 1.6f;          // shadow lift
                    lifted = lifted > 0.8f ? 0.8f + (1 - (float) Math.exp(-(lifted - 0.8f) / 0.2f)) * 0.2f : lifted;
                    float detail = (L - B) / 255f * gain * 1.15f;                           // local contrast
                    float Lo = clamp(lifted + detail + sharp / 255f);
                    // colour follows brightness (keeps lifted shadows colourful, not grey)
                    float k = (Lo * 255 + 10) / (L + 10);
                    k = Math.max(0.7f, Math.min(1.9f, k)) * 1.07f;
                    int ci = cy * cw + Math.min(cw - 1, x / 2);
                    float U = ((float) SU[ci] / N - 128) * k;
                    float V = ((float) SV[ci] / N - 128) * k;
                    float Yo = Lo * 255;
                    int r = (int) (Yo + 1.402f * V), g = (int) (Yo - 0.344136f * U - 0.714136f * V), bl = (int) (Yo + 1.772f * U);
                    r = r < 0 ? 0 : (r > 255 ? 255 : r);
                    g = g < 0 ? 0 : (g > 255 ? 255 : g);
                    bl = bl < 0 ? 0 : (bl > 255 ? 255 : bl);
                    row[x] = 0xFF000000 | (r << 16) | (g << 8) | bl;
                }
                synchronized (out) { out.setPixels(row, 0, w, 0, y, w, 1); }
            }
        });
        refY = refU = refV = null;
        sumU = sumV = null;
        out.setHasAlpha(false);
        return out;
    }
}
