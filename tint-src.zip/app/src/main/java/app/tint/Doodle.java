package app.tint;

import android.graphics.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Hand drawing. Strokes are kept as points (fractions of the image), so they are redrawn
 * sharply at any size: on screen, in thumbnails and at full resolution when saving.
 */
final class Doodle {
    static final int PEN = 0, MARKER = 1, NEON = 2, DOTS = 3, ERASER = 4;
    static final String[] NAMES = {"Pen", "Marker", "Neon", "Dots", "Eraser"};

    static final class Stroke {
        final int brush, color;
        final float size;               // fraction of image width
        float[] pts = new float[64];    // x0,y0,x1,y1,... as fractions
        int n;                          // number of floats used

        Stroke(int brush, int color, float size) { this.brush = brush; this.color = color; this.size = size; }

        void add(float x, float y) {
            if (n >= 2 && Math.abs(pts[n - 2] - x) < 0.0008f && Math.abs(pts[n - 1] - y) < 0.0008f) return;
            if (n + 2 > pts.length) pts = java.util.Arrays.copyOf(pts, pts.length * 2);
            pts[n++] = x;
            pts[n++] = y;
        }
    }

    final List<Stroke> strokes = new ArrayList<>();

    boolean isEmpty() { return strokes.isEmpty(); }

    Doodle copy() {
        Doodle d = new Doodle();
        d.strokes.addAll(strokes);
        return d;
    }

    private static Path path(Stroke s, int w, int h) {
        Path p = new Path();
        if (s.n < 2) return p;
        float px = s.pts[0] * w, py = s.pts[1] * h;
        p.moveTo(px, py);
        if (s.n == 2) { p.lineTo(px + 0.1f, py); return p; }
        for (int i = 2; i < s.n; i += 2) {
            float x = s.pts[i] * w, y = s.pts[i + 1] * h;
            p.quadTo(px, py, (px + x) / 2, (py + y) / 2);   // smooth curve through the points
            px = x; py = y;
        }
        p.lineTo(px, py);
        return p;
    }

    void draw(Canvas c, int w, int h) {
        if (strokes.isEmpty()) return;
        int layer = c.saveLayer(0, 0, w, h, null);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        for (Stroke s : strokes) {
            float sw = Math.max(1, s.size * w);
            Path path = path(s, w, h);
            p.reset();
            p.setAntiAlias(true);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStrokeWidth(sw);
            p.setColor(s.color);
            switch (s.brush) {
                case MARKER:
                    p.setAlpha(120);
                    p.setStrokeCap(Paint.Cap.SQUARE);
                    p.setStrokeWidth(sw * 1.6f);
                    c.drawPath(path, p);
                    break;
                case NEON: {
                    p.setShadowLayer(sw * 1.4f, 0, 0, s.color);
                    c.drawPath(path, p);
                    p.setShadowLayer(sw * 0.5f, 0, 0, s.color);
                    c.drawPath(path, p);
                    p.clearShadowLayer();
                    int core = Color.rgb(Color.red(s.color) + (255 - Color.red(s.color)) * 3 / 4,
                            Color.green(s.color) + (255 - Color.green(s.color)) * 3 / 4,
                            Color.blue(s.color) + (255 - Color.blue(s.color)) * 3 / 4);
                    p.setColor(core);
                    p.setStrokeWidth(sw * 0.45f);
                    c.drawPath(path, p);
                    break;
                }
                case DOTS:
                    p.setPathEffect(new DashPathEffect(new float[]{0.01f, sw * 1.9f}, 0));
                    c.drawPath(path, p);
                    break;
                case ERASER:
                    p.setColor(Color.BLACK);
                    p.setBlendMode(BlendMode.DST_OUT);
                    p.setStrokeWidth(sw * 1.5f);
                    c.drawPath(path, p);
                    break;
                default:
                    c.drawPath(path, p);
            }
        }
        c.restoreToCount(layer);
    }

    JSONArray toJson() throws Exception {
        JSONArray a = new JSONArray();
        for (Stroke s : strokes) {
            JSONArray pts = new JSONArray();
            for (int i = 0; i < s.n; i++) pts.put(Math.round(s.pts[i] * 10000) / 10000.0);
            a.put(new JSONObject().put("b", s.brush).put("c", s.color).put("s", s.size).put("p", pts));
        }
        return a;
    }

    static Doodle fromJson(JSONArray a) {
        Doodle d = new Doodle();
        if (a == null) return d;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            Stroke s = new Stroke(o.optInt("b"), o.optInt("c", Color.WHITE), (float) o.optDouble("s", 0.01));
            JSONArray p = o.optJSONArray("p");
            if (p == null) continue;
            for (int k = 0; k + 1 < p.length(); k += 2) s.add((float) p.optDouble(k), (float) p.optDouble(k + 1));
            d.strokes.add(s);
        }
        return d;
    }
}
