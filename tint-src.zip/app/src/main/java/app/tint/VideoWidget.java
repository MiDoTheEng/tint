package app.tint;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

/** Home-screen widget: opens Tint's camera in Video mode. */
public class VideoWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_video);
            v.setOnClickPendingIntent(R.id.w_video, CameraWidget.open(c, CameraWidget.OPEN_VIDEO, 2));
            m.updateAppWidget(id, v);
        }
    }
}
