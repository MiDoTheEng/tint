package app.tint;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final int REQ_PICK = 1;
    static final int BG = 0xFF0A0A0B, SURFACE = 0xFF17171A, SURFACE2 = 0xFF222226, TEXT = 0xFFF4F4F5,
            DIM = 0xFF8B8B92, ACCENT = 0xFFFF4D2E, LINE = 0x26FFFFFF;
    static final int PREVIEW_MAX = 2048;

    final ExecutorService exec = Executors.newSingleThreadExecutor();
    final ExecutorService thumbExec = Executors.newSingleThreadExecutor();
    final Handler ui = new Handler(Looper.getMainLooper());

    final List<Filter> all = Filters.all();
    final Map<Filter, Bitmap> thumbs = new HashMap<>();
    final Map<Filter, View> itemViews = new HashMap<>();
    final Map<String, TextView> chips = new LinkedHashMap<>();
    final List<TextView> styleChips = new ArrayList<>();
    final List<View> colorDots = new ArrayList<>();

    String category = "All";
    Filter current;
    int intensity = 100;
    Uri photoUri;
    Bitmap preview, thumbSrc;
    volatile int gen, thumbGen;
    boolean saving, textMode, syncingText;

    Views.AspectFrame stage;
    Views.TextOverlay overlay;
    ImageView ivOrig, ivFx;
    TextView tvName, tvPct, btnSave, openPill, hint, tabFilters, tabText, btnDelete;
    SeekBar seek, sizeSeek;
    LinearLayout chipRow, strip, filterPanel, textPanel;
    HorizontalScrollView stripScroll;
    EditText input;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window win = getWindow();
        win.setStatusBarColor(Color.TRANSPARENT);
        win.setNavigationBarColor(Color.TRANSPARENT);
        win.setNavigationBarContrastEnforced(false);
        if (Build.VERSION.SDK_INT >= 30) {
            win.setDecorFitsSystemWindows(false);
        } else {
            win.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        current = all.get(0);
        setContentView(buildUi());
        refreshChips();
        buildStrip();
        setMode(false);
        setSource(Renderer.sample(1080, 1350), null);
        handleIncoming(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIncoming(intent);
    }

    @Override
    protected void onDestroy() {
        exec.shutdownNow();
        thumbExec.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (textMode) { setMode(false); return; }
        super.onBackPressed();
    }

    // ------------------------------------------------------------------ UI helpers

    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    GradientDrawable round(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    TextView pill(String text, boolean filled) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setPadding(dp(18), dp(9), dp(18), dp(9));
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = round(filled ? ACCENT : Color.TRANSPARENT, dp(100));
        if (!filled) g.setStroke(dp(1), LINE);
        t.setBackground(g);
        t.setTextColor(filled ? Color.WHITE : TEXT);
        return t;
    }

    HorizontalScrollView hscroll(View child) {
        HorizontalScrollView s = new HorizontalScrollView(this);
        s.setHorizontalScrollBarEnabled(false);
        s.setHorizontalFadingEdgeEnabled(true);
        s.setFadingEdgeLength(dp(24));
        s.addView(child);
        return s;
    }

    SeekBar slider(int max, int value) {
        SeekBar s = new SeekBar(this);
        s.setMax(max);
        s.setProgress(value);
        s.setProgressTintList(ColorStateList.valueOf(ACCENT));
        s.setProgressBackgroundTintList(ColorStateList.valueOf(0x40FFFFFF));
        s.setThumbTintList(ColorStateList.valueOf(Color.WHITE));
        s.setPadding(dp(24), dp(12), dp(24), dp(12));
        return s;
    }

    interface Progress { void on(int p); }

    void onSlide(SeekBar s, Progress p) {
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int v, boolean user) { p.on(v); }
            public void onStartTrackingTouch(SeekBar b) { }
            public void onStopTrackingTouch(SeekBar b) { }
        });
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ------------------------------------------------------------------ layout

    View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            int t, b, l, r;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                Insets k = ins.getInsets(WindowInsets.Type.ime());
                t = i.top; b = Math.max(i.bottom, k.bottom); l = i.left; r = i.right;
            } else {
                t = ins.getSystemWindowInsetTop(); b = ins.getSystemWindowInsetBottom();
                l = ins.getSystemWindowInsetLeft(); r = ins.getSystemWindowInsetRight();
            }
            v.setPadding(l, t, r, b + dp(10));
            return ins;
        });

        // top bar
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(22), dp(10), dp(14), dp(10));
        TextView logo = new TextView(this);
        logo.setText("TINT");
        logo.setTextColor(TEXT);
        logo.setTextSize(20);
        logo.setLetterSpacing(0.28f);
        logo.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        top.addView(logo);
        View dot = new View(this);
        GradientDrawable dd = new GradientDrawable();
        dd.setShape(GradientDrawable.OVAL);
        dd.setColor(ACCENT);
        dot.setBackground(dd);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(6), dp(6));
        dlp.setMargins(dp(2), 0, 0, dp(8));
        top.addView(dot, dlp);
        top.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        TextView open = pill("Open", false);
        open.setOnClickListener(v -> pick());
        top.addView(open);
        btnSave = pill("Save", true);
        btnSave.setOnClickListener(v -> save());
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
        slp.setMargins(dp(8), 0, 0, 0);
        top.addView(btnSave, slp);
        root.addView(top);

        // photo stage: takes the exact shape of the photo
        FrameLayout holder = new FrameLayout(this);
        stage = new Views.AspectFrame(this);
        stage.setBackground(round(SURFACE, dp(22)));
        stage.setClipToOutline(true);
        ivOrig = new ImageView(this);
        ivOrig.setScaleType(ImageView.ScaleType.FIT_XY);
        ivFx = new ImageView(this);
        ivFx.setScaleType(ImageView.ScaleType.FIT_XY);
        overlay = new Views.TextOverlay(this);
        stage.addView(ivOrig, new FrameLayout.LayoutParams(-1, -1));
        stage.addView(ivFx, new FrameLayout.LayoutParams(-1, -1));
        stage.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        hint = new TextView(this);
        hint.setText("Hold to compare");
        hint.setTextColor(0xDDFFFFFF);
        hint.setTextSize(11);
        hint.setPadding(dp(12), dp(5), dp(12), dp(5));
        hint.setBackground(round(0x66000000, dp(100)));
        FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        hlp.topMargin = dp(12);
        stage.addView(hint, hlp);

        openPill = new TextView(this);
        openPill.setText("＋   Open a photo");
        openPill.setTextColor(Color.BLACK);
        openPill.setTextSize(15);
        openPill.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        openPill.setPadding(dp(22), dp(12), dp(22), dp(12));
        openPill.setBackground(round(Color.WHITE, dp(100)));
        openPill.setElevation(dp(6));
        openPill.setOnClickListener(v -> pick());
        FrameLayout.LayoutParams olp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        olp.bottomMargin = dp(20);
        stage.addView(openPill, olp);

        stage.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                ivFx.setVisibility(View.INVISIBLE);
                overlay.setVisibility(View.INVISIBLE);
                hint.setText("Original");
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                ivFx.setVisibility(View.VISIBLE);
                overlay.setVisibility(View.VISIBLE);
                hint.setText(textMode ? "Drag · pinch to resize" : "Hold to compare");
            }
            return true;
        });

        holder.addView(stage, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, 0, 1f);
        hp.setMargins(dp(14), dp(2), dp(14), dp(10));
        root.addView(holder, hp);

        // Filters | Text tabs
        LinearLayout tabs = new LinearLayout(this);
        tabs.setBackground(round(SURFACE, dp(100)));
        tabs.setPadding(dp(4), dp(4), dp(4), dp(4));
        tabFilters = tab("Filters");
        tabText = tab("Text  ·  نص");
        tabFilters.setOnClickListener(v -> setMode(false));
        tabText.setOnClickListener(v -> setMode(true));
        tabs.addView(tabFilters);
        tabs.addView(tabText);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-2, -2);
        tlp.gravity = Gravity.CENTER_HORIZONTAL;
        tlp.bottomMargin = dp(8);
        root.addView(tabs, tlp);

        root.addView(buildFilterPanel());
        root.addView(buildTextPanel());

        tvName.setText(current.name);
        return root;
    }

    TextView tab(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(13);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setPadding(dp(20), dp(7), dp(20), dp(7));
        return t;
    }

    View buildFilterPanel() {
        filterPanel = new LinearLayout(this);
        filterPanel.setOrientation(LinearLayout.VERTICAL);

        LinearLayout info = new LinearLayout(this);
        info.setGravity(Gravity.CENTER_VERTICAL);
        info.setPadding(dp(24), 0, dp(24), 0);
        tvName = new TextView(this);
        tvName.setTextColor(TEXT);
        tvName.setTextSize(15);
        tvName.setLetterSpacing(0.12f);
        tvName.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        info.addView(tvName);
        info.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        tvPct = new TextView(this);
        tvPct.setTextColor(DIM);
        tvPct.setTextSize(13);
        tvPct.setTypeface(Typeface.MONOSPACE);
        tvPct.setText("100");
        info.addView(tvPct);
        filterPanel.addView(info);

        seek = slider(100, 100);
        onSlide(seek, p -> {
            intensity = p;
            tvPct.setText(String.valueOf(p));
            ivFx.setAlpha(p / 100f);
        });
        filterPanel.addView(seek);

        chipRow = new LinearLayout(this);
        chipRow.setPadding(dp(14), dp(4), dp(14), dp(4));
        for (String cat : Filters.CATEGORIES) {
            TextView chip = new TextView(this);
            chip.setText(cat);
            chip.setTextSize(13);
            chip.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            chip.setPadding(dp(15), dp(7), dp(15), dp(7));
            chip.setOnClickListener(v -> {
                if (cat.equals(category)) return;
                category = cat;
                v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                refreshChips();
                buildStrip();
            });
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
            clp.setMargins(dp(2), 0, dp(2), 0);
            chipRow.addView(chip, clp);
            chips.put(cat, chip);
        }
        filterPanel.addView(hscroll(chipRow));

        strip = new LinearLayout(this);
        strip.setPadding(dp(12), dp(12), dp(12), dp(4));
        stripScroll = hscroll(strip);
        filterPanel.addView(stripScroll);
        return filterPanel;
    }

    View buildTextPanel() {
        textPanel = new LinearLayout(this);
        textPanel.setOrientation(LinearLayout.VERTICAL);

        // input row
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), 0, dp(16), 0);
        input = new EditText(this);
        input.setHint("Type here…  اكتب هنا");
        input.setHintTextColor(DIM);
        input.setTextColor(TEXT);
        input.setTextSize(15);
        input.setBackground(round(SURFACE, dp(16)));
        input.setPadding(dp(16), dp(11), dp(16), dp(11));
        input.setMaxLines(3);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        input.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(Editable s) {
                if (syncingText) return;
                if (overlay.selected == null) {
                    if (s.length() == 0) return;
                    addLayer(false);
                }
                overlay.selected.text = s.toString();
                overlay.invalidate();
            }
        });
        row.addView(input, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView add = pill("＋", true);
        add.setTextSize(18);
        add.setPadding(dp(16), dp(6), dp(16), dp(6));
        add.setOnClickListener(v -> addLayer(true));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-2, -2);
        alp.setMargins(dp(8), 0, 0, 0);
        row.addView(add, alp);
        btnDelete = pill("✕", false);
        btnDelete.setTextSize(16);
        btnDelete.setPadding(dp(15), dp(7), dp(15), dp(7));
        btnDelete.setOnClickListener(v -> deleteLayer());
        row.addView(btnDelete, alp);
        textPanel.addView(row);

        // styles
        LinearLayout styles = new LinearLayout(this);
        styles.setPadding(dp(14), dp(12), dp(14), dp(2));
        for (int i = 0; i < TextArt.STYLES.length; i++) {
            final int idx = i;
            TextView s = new TextView(this);
            s.setText(TextArt.STYLES[i]);
            s.setTypeface(TextArt.typeface(i));
            s.setTextSize(15);
            s.setTextColor(TEXT);
            s.setPadding(dp(16), dp(9), dp(16), dp(9));
            s.setOnClickListener(v -> {
                if (overlay.selected == null) addLayer(true);
                overlay.selected.style = idx;
                v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                refreshTextControls();
                overlay.invalidate();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.setMargins(dp(3), 0, dp(3), 0);
            styles.addView(s, lp);
            styleChips.add(s);
        }
        textPanel.addView(hscroll(styles));

        // colours
        LinearLayout colors = new LinearLayout(this);
        colors.setPadding(dp(16), dp(10), dp(16), dp(2));
        colors.setGravity(Gravity.CENTER_VERTICAL);
        for (int col : TextArt.COLORS) {
            View d = new View(this);
            d.setTag(col);
            d.setOnClickListener(v -> {
                if (overlay.selected == null) addLayer(true);
                overlay.selected.color = col;
                v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                refreshTextControls();
                overlay.invalidate();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(30), dp(30));
            lp.setMargins(dp(5), 0, dp(5), 0);
            colors.addView(d, lp);
            colorDots.add(d);
        }
        textPanel.addView(hscroll(colors));

        // size
        sizeSeek = slider(100, 35);
        onSlide(sizeSeek, p -> {
            if (syncingText || overlay.selected == null) return;
            overlay.selected.size = 0.02f + p / 100f * 0.28f;
            overlay.invalidate();
        });
        textPanel.addView(sizeSeek);

        overlay.listener = new Views.TextOverlay.Listener() {
            public void onSelect(TextArt.Layer l) { refreshTextControls(); }
            public void onChanged() { refreshTextControls(); }
        };
        return textPanel;
    }

    void setMode(boolean text) {
        textMode = text;
        filterPanel.setVisibility(text ? View.GONE : View.VISIBLE);
        textPanel.setVisibility(text ? View.VISIBLE : View.GONE);
        overlay.editing = text;
        overlay.invalidate();
        tabFilters.setBackground(text ? null : round(Color.WHITE, dp(100)));
        tabFilters.setTextColor(text ? DIM : Color.BLACK);
        tabText.setBackground(text ? round(Color.WHITE, dp(100)) : null);
        tabText.setTextColor(text ? Color.BLACK : DIM);
        hint.setText(text ? "Drag · pinch to resize" : "Hold to compare");
        if (text) {
            if (overlay.layers.isEmpty()) addLayer(true);
            else refreshTextControls();
        } else {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
            input.clearFocus();
        }
    }

    void addLayer(boolean showKeyboard) {
        TextArt.Layer l = new TextArt.Layer();
        TextArt.Layer prev = overlay.selected;
        if (prev != null) { l.style = prev.style; l.color = prev.color; }
        l.y = 0.5f + 0.08f * (overlay.layers.size() % 4);
        overlay.layers.add(l);
        overlay.selected = l;
        refreshTextControls();
        overlay.invalidate();
        if (showKeyboard) {
            input.requestFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
        }
    }

    void deleteLayer() {
        if (overlay.selected == null) return;
        overlay.layers.remove(overlay.selected);
        overlay.selected = overlay.layers.isEmpty() ? null : overlay.layers.get(overlay.layers.size() - 1);
        refreshTextControls();
        overlay.invalidate();
    }

    void refreshTextControls() {
        TextArt.Layer l = overlay.selected;
        syncingText = true;
        String t = l == null ? "" : l.text;
        if (!input.getText().toString().equals(t)) {
            input.setText(t);
            input.setSelection(t.length());
        }
        sizeSeek.setProgress(l == null ? 35 : Math.round((l.size - 0.02f) / 0.28f * 100));
        syncingText = false;
        int style = l == null ? -1 : l.style;
        for (int i = 0; i < styleChips.size(); i++) {
            TextView s = styleChips.get(i);
            boolean sel = i == style;
            s.setBackground(sel ? round(Color.WHITE, dp(100)) : round(SURFACE, dp(100)));
            s.setTextColor(sel ? Color.BLACK : TEXT);
        }
        int color = l == null ? 0 : l.color;
        for (View d : colorDots) {
            int c = (Integer) d.getTag();
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(c);
            boolean sel = l != null && c == color;
            g.setStroke(dp(sel ? 3 : 1), sel ? ACCENT : LINE);
            d.setBackground(g);
        }
        btnDelete.setAlpha(l == null ? 0.4f : 1f);
    }

    void refreshChips() {
        for (Map.Entry<String, TextView> e : chips.entrySet()) {
            boolean sel = e.getKey().equals(category);
            e.getValue().setBackground(sel ? round(Color.WHITE, dp(100)) : null);
            e.getValue().setTextColor(sel ? Color.BLACK : DIM);
        }
    }

    List<Filter> visible() {
        List<Filter> l = new ArrayList<>();
        for (Filter f : all)
            if (f.isOriginal() || category.equals("All") || f.cat.equals(category)) l.add(f);
        return l;
    }

    void buildStrip() {
        strip.removeAllViews();
        itemViews.clear();
        for (Filter f : visible()) strip.addView(makeItem(f));
        stripScroll.scrollTo(0, 0);
    }

    View makeItem(Filter f) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(5), 0, dp(5), 0);

        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackground(round(SURFACE, dp(18)));
        iv.setClipToOutline(true);
        Bitmap t = thumbs.get(f);
        iv.setImageBitmap(t != null ? t : thumbSrc);
        col.addView(iv, new LinearLayout.LayoutParams(dp(68), dp(68)));

        TextView name = new TextView(this);
        name.setText(f.name);
        name.setTextSize(10);
        name.setLetterSpacing(0.08f);
        name.setSingleLine(true);
        name.setMaxWidth(dp(76));
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-2, -2);
        nlp.topMargin = dp(7);
        col.addView(name, nlp);

        col.setOnClickListener(v -> select(f));
        itemViews.put(f, col);
        styleItem(col, f == current);
        return col;
    }

    void styleItem(View col, boolean sel) {
        ViewGroup g = (ViewGroup) col;
        ImageView iv = (ImageView) g.getChildAt(0);
        TextView tv = (TextView) g.getChildAt(1);
        if (sel) {
            GradientDrawable ring = new GradientDrawable();
            ring.setCornerRadius(dp(18));
            ring.setStroke(dp(2), ACCENT);
            iv.setForeground(ring);
        } else {
            iv.setForeground(null);
        }
        tv.setTextColor(sel ? TEXT : DIM);
    }

    void select(Filter f) {
        if (f == current) return;
        View old = itemViews.get(current);
        current = f;
        if (old != null) styleItem(old, false);
        View nv = itemViews.get(f);
        if (nv != null) {
            styleItem(nv, true);
            nv.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        }
        tvName.setText(f.name);
        renderPreview();
    }

    // ------------------------------------------------------------------ rendering

    void setSource(Bitmap bmp, Uri uri) {
        preview = bmp;
        photoUri = uri;
        stage.setRatio((float) bmp.getWidth() / bmp.getHeight());
        ivOrig.setImageBitmap(bmp);
        ivFx.setImageBitmap(null);
        openPill.setVisibility(uri == null ? View.VISIBLE : View.GONE);
        btnSave.setAlpha(uri == null ? 0.45f : 1f);
        thumbSrc = Renderer.thumb(bmp, dp(68));
        regenThumbs();
        renderPreview();
    }

    void renderPreview() {
        if (preview == null) return;
        final int g = ++gen;
        final Bitmap src = preview;
        final Filter f = current;
        exec.execute(() -> {
            if (g != gen) return;
            Bitmap out = f.isOriginal() ? null : Renderer.render(src, f);
            ui.post(() -> {
                if (g != gen) return;
                ivFx.setImageBitmap(out);
            });
        });
    }

    void regenThumbs() {
        final int tg = ++thumbGen;
        final Bitmap ts = thumbSrc;
        thumbs.clear();
        for (View v : itemViews.values())
            ((ImageView) ((ViewGroup) v).getChildAt(0)).setImageBitmap(ts);
        final List<Filter> order = new ArrayList<>(visible());
        for (Filter f : all) if (!order.contains(f)) order.add(f);
        thumbExec.execute(() -> {
            for (Filter f : order) {
                if (tg != thumbGen) return;
                Bitmap t = f.isOriginal() ? ts : Renderer.render(ts, f);
                ui.post(() -> {
                    if (tg != thumbGen) return;
                    thumbs.put(f, t);
                    View v = itemViews.get(f);
                    if (v != null) ((ImageView) ((ViewGroup) v).getChildAt(0)).setImageBitmap(t);
                });
            }
        });
    }

    // ------------------------------------------------------------------ open / save

    void pick() {
        Intent i;
        if (Build.VERSION.SDK_INT >= 33) {
            i = new Intent(MediaStore.ACTION_PICK_IMAGES);
            i.setType("image/*");
        } else {
            i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
        }
        try {
            startActivityForResult(i, REQ_PICK);
        } catch (Exception e) {
            Intent g = new Intent(Intent.ACTION_GET_CONTENT);
            g.setType("image/*");
            startActivityForResult(g, REQ_PICK);
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK && res == RESULT_OK && data != null && data.getData() != null)
            loadUri(data.getData());
    }

    void handleIncoming(Intent in) {
        if (in == null) return;
        String act = in.getAction();
        Uri u = null;
        if (Intent.ACTION_SEND.equals(act)) u = in.getParcelableExtra(Intent.EXTRA_STREAM);
        else if (Intent.ACTION_EDIT.equals(act) || Intent.ACTION_VIEW.equals(act)) u = in.getData();
        if (u != null) loadUri(u);
    }

    /** maxSide <= 0 means full original resolution. */
    Bitmap decode(Uri u, int maxSide, boolean mutable) throws IOException {
        ImageDecoder.Source s = ImageDecoder.createSource(getContentResolver(), u);
        return ImageDecoder.decodeBitmap(s, (dec, info, src) -> {
            dec.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            dec.setMutableRequired(mutable);
            if (maxSide > 0) {
                int w = info.getSize().getWidth(), h = info.getSize().getHeight();
                float sc = Math.min(1f, (float) maxSide / Math.max(w, h));
                if (sc < 1f) dec.setTargetSize(Math.max(1, Math.round(w * sc)), Math.max(1, Math.round(h * sc)));
            }
        });
    }

    void loadUri(Uri u) {
        exec.execute(() -> {
            try {
                Bitmap b = decode(u, PREVIEW_MAX, false);
                ui.post(() -> setSource(b, u));
            } catch (Throwable t) {
                ui.post(() -> toast("Couldn't open that photo"));
            }
        });
    }

    void save() {
        if (photoUri == null) { pick(); return; }
        if (saving) return;
        saving = true;
        btnSave.setText("Saving…");
        final Uri u = photoUri;
        final Filter f = current;
        final float k = intensity / 100f;
        final List<TextArt.Layer> texts = new ArrayList<>();
        for (TextArt.Layer l : overlay.layers) if (!l.text.trim().isEmpty()) texts.add(l.copy());

        exec.execute(() -> {
            String msg = "Saved to Pictures/Tint";
            Bitmap src = null;
            try {
                try {
                    src = decode(u, 0, true);                     // full original resolution
                } catch (OutOfMemoryError oom) {
                    System.gc();
                    src = decode(u, 6000, true);
                    msg = "Saved (reduced size — photo was very large)";
                }
                if (Build.VERSION.SDK_INT >= 34 && src.hasGainmap() && (!f.isOriginal() || !texts.isEmpty()))
                    src.setGainmap(null);
                if (!f.isOriginal() && k > 0) Renderer.applyFull(src, f, k);
                if (!texts.isEmpty()) {
                    Canvas c = new Canvas(src);
                    for (TextArt.Layer l : texts) TextArt.draw(c, src.getWidth(), src.getHeight(), l);
                }
                writeToGallery(src, u);
            } catch (OutOfMemoryError e) {
                msg = "Photo too large to save";
            } catch (Throwable t) {
                msg = "Couldn't save";
            }
            if (src != null) src.recycle();
            final String m = msg;
            ui.post(() -> {
                saving = false;
                btnSave.setText("Save");
                toast(m);
                if (m.startsWith("Saved")) btnSave.performHapticFeedback(Build.VERSION.SDK_INT >= 30
                        ? HapticFeedbackConstants.CONFIRM : HapticFeedbackConstants.LONG_PRESS);
            });
        });
    }

    static final String[] EXIF_TAGS = {
            ExifInterface.TAG_MAKE, ExifInterface.TAG_MODEL, ExifInterface.TAG_F_NUMBER,
            ExifInterface.TAG_EXPOSURE_TIME, ExifInterface.TAG_ISO_SPEED_RATINGS, ExifInterface.TAG_FOCAL_LENGTH,
            ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, ExifInterface.TAG_WHITE_BALANCE, ExifInterface.TAG_FLASH,
            ExifInterface.TAG_EXPOSURE_BIAS_VALUE, ExifInterface.TAG_LENS_MODEL};

    void writeToGallery(Bitmap b, Uri source) throws IOException {
        ContentResolver cr = getContentResolver();
        ContentValues cv = new ContentValues();
        String name = "TINT_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".jpg";
        cv.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Tint");
        cv.put(MediaStore.Images.Media.IS_PENDING, 1);
        Uri out = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
        if (out == null) throw new IOException("insert failed");
        try (OutputStream os = cr.openOutputStream(out)) {
            if (os == null || !b.compress(Bitmap.CompressFormat.JPEG, 98, os)) throw new IOException("write failed");
        } catch (IOException e) {
            cr.delete(out, null, null);
            throw e;
        }
        copyExif(source, out);
        cv.clear();
        cv.put(MediaStore.Images.Media.IS_PENDING, 0);
        cr.update(out, cv, null, null);
    }

    /** Keeps the camera details (phone model, lens, exposure…) of the original photo. */
    void copyExif(Uri from, Uri to) {
        try (InputStream in = getContentResolver().openInputStream(from)) {
            if (in == null) return;
            ExifInterface src = new ExifInterface(in);
            try (ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(to, "rw")) {
                if (pfd == null) return;
                ExifInterface dst = new ExifInterface(pfd.getFileDescriptor());
                for (String tag : EXIF_TAGS) {
                    String v = src.getAttribute(tag);
                    if (v != null) dst.setAttribute(tag, v);
                }
                dst.setAttribute(ExifInterface.TAG_SOFTWARE, "Tint");
                dst.setAttribute(ExifInterface.TAG_ORIENTATION, String.valueOf(ExifInterface.ORIENTATION_NORMAL));
                dst.saveAttributes();
            }
        } catch (Throwable ignored) {
            // metadata is a bonus; the photo is already saved
        }
    }
}
