package app.tint;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;

import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final int REQ_PICK = 1;
    static final int BG = 0xFF0A0A0B, SURFACE = 0xFF17171A, TEXT = 0xFFF4F4F5,
            DIM = 0xFF8B8B92, ACCENT = 0xFFFF4D2E, LINE = 0x26FFFFFF;

    final ExecutorService exec = Executors.newSingleThreadExecutor();
    final ExecutorService thumbExec = Executors.newSingleThreadExecutor();
    final Handler ui = new Handler(Looper.getMainLooper());

    final List<Filter> all = Filters.all();
    final Map<Filter, Bitmap> thumbs = new HashMap<>();
    final Map<Filter, View> itemViews = new HashMap<>();
    final Map<String, TextView> chips = new LinkedHashMap<>();

    String category = "All";
    Filter current;
    int intensity = 100;
    Uri photoUri;
    Bitmap preview, thumbSrc;
    volatile int gen, thumbGen;
    boolean saving;

    ImageView ivOrig, ivFx;
    TextView tvName, tvPct, btnSave, openPill, hint;
    SeekBar seek;
    LinearLayout chipRow, strip;
    HorizontalScrollView stripScroll;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window win = getWindow();
        win.setStatusBarColor(Color.TRANSPARENT);
        win.setNavigationBarColor(Color.TRANSPARENT);
        win.setNavigationBarContrastEnforced(false);
        if (Build.VERSION.SDK_INT >= 30) {
            win.setDecorFitsSystemWindows(false);
        } else {
            win.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        current = all.get(0);
        setContentView(buildUi());
        refreshChips();
        buildStrip();
        setSource(Renderer.sample(1080, 1350), null);
        handleIncoming(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIncoming(intent);
    }

    @Override
    protected void onDestroy() {
        exec.shutdownNow();
        thumbExec.shutdownNow();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ UI

    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    GradientDrawable round(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    TextView pill(String text, boolean filled) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setPadding(dp(18), dp(9), dp(18), dp(9));
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = round(filled ? ACCENT : Color.TRANSPARENT, dp(100));
        if (!filled) g.setStroke(dp(1), LINE);
        t.setBackground(g);
        t.setTextColor(filled ? Color.WHITE : TEXT);
        return t;
    }

    View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            int t, b, l, r;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                t = i.top; b = i.bottom; l = i.left; r = i.right;
            } else {
                t = ins.getSystemWindowInsetTop(); b = ins.getSystemWindowInsetBottom();
                l = ins.getSystemWindowInsetLeft(); r = ins.getSystemWindowInsetRight();
            }
            v.setPadding(l, t, r, b + dp(10));
            return ins;
        });

        // top bar
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(22), dp(10), dp(14), dp(10));
        TextView logo = new TextView(this);
        logo.setText("TINT");
        logo.setTextColor(TEXT);
        logo.setTextSize(20);
        logo.setLetterSpacing(0.28f);
        logo.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        top.addView(logo);
        View dot = new View(this);
        GradientDrawable dd = new GradientDrawable();
        dd.setShape(GradientDrawable.OVAL);
        dd.setColor(ACCENT);
        dot.setBackground(dd);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(6), dp(6));
        dlp.setMargins(dp(2), 0, 0, dp(8));
        top.addView(dot, dlp);
        top.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        TextView open = pill("Open", false);
        open.setOnClickListener(v -> pick());
        top.addView(open);
        btnSave = pill("Save", true);
        btnSave.setOnClickListener(v -> save());
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
        slp.setMargins(dp(8), 0, 0, 0);
        top.addView(btnSave, slp);
        root.addView(top);

        // photo stage
        FrameLayout stage = new FrameLayout(this);
        stage.setBackground(round(SURFACE, dp(26)));
        stage.setClipToOutline(true);
        ivOrig = new ImageView(this);
        ivOrig.setScaleType(ImageView.ScaleType.FIT_CENTER);
        ivFx = new ImageView(this);
        ivFx.setScaleType(ImageView.ScaleType.FIT_CENTER);
        stage.addView(ivOrig, new FrameLayout.LayoutParams(-1, -1));
        stage.addView(ivFx, new FrameLayout.LayoutParams(-1, -1));

        hint = new TextView(this);
        hint.setText("Hold to compare");
        hint.setTextColor(0xDDFFFFFF);
        hint.setTextSize(11);
        hint.setLetterSpacing(0.06f);
        hint.setPadding(dp(12), dp(5), dp(12), dp(5));
        hint.setBackground(round(0x66000000, dp(100)));
        FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        hlp.topMargin = dp(14);
        stage.addView(hint, hlp);

        openPill = new TextView(this);
        openPill.setText("＋   Open a photo");
        openPill.setTextColor(Color.BLACK);
        openPill.setTextSize(15);
        openPill.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        openPill.setPadding(dp(22), dp(12), dp(22), dp(12));
        openPill.setBackground(round(Color.WHITE, dp(100)));
        openPill.setElevation(dp(6));
        openPill.setOnClickListener(v -> pick());
        FrameLayout.LayoutParams olp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        olp.bottomMargin = dp(20);
        stage.addView(openPill, olp);

        stage.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                ivFx.setVisibility(View.INVISIBLE);
                hint.setText("Original");
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                ivFx.setVisibility(View.VISIBLE);
                hint.setText("Hold to compare");
            }
            return true;
        });

        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, 0, 1f);
        stp.setMargins(dp(14), dp(2), dp(14), dp(14));
        root.addView(stage, stp);

        // name + percentage
        LinearLayout info = new LinearLayout(this);
        info.setGravity(Gravity.CENTER_VERTICAL);
        info.setPadding(dp(24), 0, dp(24), 0);
        tvName = new TextView(this);
        tvName.setTextColor(TEXT);
        tvName.setTextSize(15);
        tvName.setLetterSpacing(0.12f);
        tvName.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        info.addView(tvName);
        info.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        tvPct = new TextView(this);
        tvPct.setTextColor(DIM);
        tvPct.setTextSize(13);
        tvPct.setTypeface(Typeface.MONOSPACE);
        tvPct.setText("100");
        info.addView(tvPct);
        root.addView(info);

        seek = new SeekBar(this);
        seek.setMax(100);
        seek.setProgress(100);
        seek.setProgressTintList(ColorStateList.valueOf(ACCENT));
        seek.setProgressBackgroundTintList(ColorStateList.valueOf(0x40FFFFFF));
        seek.setThumbTintList(ColorStateList.valueOf(Color.WHITE));
        seek.setPadding(dp(24), dp(12), dp(24), dp(12));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                intensity = p;
                tvPct.setText(String.valueOf(p));
                ivFx.setAlpha(p / 100f);
            }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        root.addView(seek);

        // categories
        HorizontalScrollView chipScroll = new HorizontalScrollView(this);
        chipScroll.setHorizontalScrollBarEnabled(false);
        chipScroll.setHorizontalFadingEdgeEnabled(true);
        chipScroll.setFadingEdgeLength(dp(24));
        chipRow = new LinearLayout(this);
        chipRow.setPadding(dp(14), dp(4), dp(14), dp(4));
        for (String cat : Filters.CATEGORIES) {
            TextView chip = new TextView(this);
            chip.setText(cat);
            chip.setTextSize(13);
            chip.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            chip.setPadding(dp(15), dp(7), dp(15), dp(7));
            chip.setOnClickListener(v -> {
                if (cat.equals(category)) return;
                category = cat;
                v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                refreshChips();
                buildStrip();
            });
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
            clp.setMargins(dp(2), 0, dp(2), 0);
            chipRow.addView(chip, clp);
            chips.put(cat, chip);
        }
        chipScroll.addView(chipRow);
        root.addView(chipScroll);

        // filter strip
        stripScroll = new HorizontalScrollView(this);
        stripScroll.setHorizontalScrollBarEnabled(false);
        stripScroll.setHorizontalFadingEdgeEnabled(true);
        stripScroll.setFadingEdgeLength(dp(24));
        strip = new LinearLayout(this);
        strip.setPadding(dp(12), dp(12), dp(12), dp(4));
        stripScroll.addView(strip);
        root.addView(stripScroll);

        tvName.setText(current.name);
        return root;
    }

    void refreshChips() {
        for (Map.Entry<String, TextView> e : chips.entrySet()) {
            boolean sel = e.getKey().equals(category);
            e.getValue().setBackground(sel ? round(Color.WHITE, dp(100)) : null);
            e.getValue().setTextColor(sel ? Color.BLACK : DIM);
        }
    }

    List<Filter> visible() {
        List<Filter> l = new ArrayList<>();
        for (Filter f : all)
            if (f.isOriginal() || category.equals("All") || f.cat.equals(category)) l.add(f);
        return l;
    }

    void buildStrip() {
        strip.removeAllViews();
        itemViews.clear();
        for (Filter f : visible()) strip.addView(makeItem(f));
        stripScroll.scrollTo(0, 0);
    }

    View makeItem(Filter f) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(5), 0, dp(5), 0);

        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackground(round(SURFACE, dp(18)));
        iv.setClipToOutline(true);
        Bitmap t = thumbs.get(f);
        iv.setImageBitmap(t != null ? t : thumbSrc);
        col.addView(iv, new LinearLayout.LayoutParams(dp(68), dp(68)));

        TextView name = new TextView(this);
        name.setText(f.name);
        name.setTextSize(10);
        name.setLetterSpacing(0.08f);
        name.setSingleLine(true);
        name.setMaxWidth(dp(76));
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-2, -2);
        nlp.topMargin = dp(7);
        col.addView(name, nlp);

        col.setOnClickListener(v -> select(f));
        itemViews.put(f, col);
        styleItem(col, f == current);
        return col;
    }

    void styleItem(View col, boolean sel) {
        ViewGroup g = (ViewGroup) col;
        ImageView iv = (ImageView) g.getChildAt(0);
        TextView tv = (TextView) g.getChildAt(1);
        if (sel) {
            GradientDrawable ring = new GradientDrawable();
            ring.setCornerRadius(dp(18));
            ring.setStroke(dp(2), ACCENT);
            iv.setForeground(ring);
        } else {
            iv.setForeground(null);
        }
        tv.setTextColor(sel ? TEXT : DIM);
    }

    void select(Filter f) {
        if (f == current) return;
        View old = itemViews.get(current);
        current = f;
        if (old != null) styleItem(old, false);
        View nv = itemViews.get(f);
        if (nv != null) {
            styleItem(nv, true);
            nv.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        }
        tvName.setText(f.name);
        renderPreview();
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ------------------------------------------------------------------ rendering

    void setSource(Bitmap bmp, Uri uri) {
        preview = bmp;
        photoUri = uri;
        ivOrig.setImageBitmap(bmp);
        openPill.setVisibility(uri == null ? View.VISIBLE : View.GONE);
        btnSave.setAlpha(uri == null ? 0.45f : 1f);
        thumbSrc = Renderer.thumb(bmp, dp(68));
        regenThumbs();
        renderPreview();
    }

    void renderPreview() {
        if (preview == null) return;
        final int g = ++gen;
        final Bitmap src = preview;
        final Filter f = current;
        exec.execute(() -> {
            if (g != gen) return;
            Bitmap out = f.isOriginal() ? null : Renderer.render(src, f);
            ui.post(() -> {
                if (g != gen) return;
                ivFx.setImageBitmap(out);
            });
        });
    }

    void regenThumbs() {
        final int tg = ++thumbGen;
        final Bitmap ts = thumbSrc;
        thumbs.clear();
        for (View v : itemViews.values())
            ((ImageView) ((ViewGroup) v).getChildAt(0)).setImageBitmap(ts);
        final List<Filter> order = new ArrayList<>(visible());
        for (Filter f : all) if (!order.contains(f)) order.add(f);
        thumbExec.execute(() -> {
            for (Filter f : order) {
                if (tg != thumbGen) return;
                Bitmap t = f.isOriginal() ? ts : Renderer.render(ts, f);
                ui.post(() -> {
                    if (tg != thumbGen) return;
                    thumbs.put(f, t);
                    View v = itemViews.get(f);
                    if (v != null) ((ImageView) ((ViewGroup) v).getChildAt(0)).setImageBitmap(t);
                });
            }
        });
    }

    // ------------------------------------------------------------------ open / save

    void pick() {
        Intent i;
        if (Build.VERSION.SDK_INT >= 33) {
            i = new Intent(MediaStore.ACTION_PICK_IMAGES);
            i.setType("image/*");
        } else {
            i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
        }
        try {
            startActivityForResult(i, REQ_PICK);
        } catch (Exception e) {
            Intent g = new Intent(Intent.ACTION_GET_CONTENT);
            g.setType("image/*");
            startActivityForResult(g, REQ_PICK);
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK && res == RESULT_OK && data != null && data.getData() != null)
            loadUri(data.getData());
    }

    void handleIncoming(Intent in) {
        if (in == null) return;
        String act = in.getAction();
        Uri u = null;
        if (Intent.ACTION_SEND.equals(act)) u = in.getParcelableExtra(Intent.EXTRA_STREAM);
        else if (Intent.ACTION_EDIT.equals(act) || Intent.ACTION_VIEW.equals(act)) u = in.getData();
        if (u != null) loadUri(u);
    }

    Bitmap decode(Uri u, int maxSide, boolean mutable) throws IOException {
        ImageDecoder.Source s = ImageDecoder.createSource(getContentResolver(), u);
        return ImageDecoder.decodeBitmap(s, (dec, info, src) -> {
            dec.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            dec.setMutableRequired(mutable);
            int w = info.getSize().getWidth(), h = info.getSize().getHeight();
            float sc = Math.min(1f, (float) maxSide / Math.max(w, h));
            if (sc < 1f) dec.setTargetSize(Math.max(1, Math.round(w * sc)), Math.max(1, Math.round(h * sc)));
        });
    }

    void loadUri(Uri u) {
        exec.execute(() -> {
            try {
                Bitmap b = decode(u, 1600, false);
                ui.post(() -> setSource(b, u));
            } catch (Throwable t) {
                ui.post(() -> toast("Couldn't open that photo"));
            }
        });
    }

    void save() {
        if (photoUri == null) { pick(); return; }
        if (saving) return;
        saving = true;
        btnSave.setText("Saving…");
        final Uri u = photoUri;
        final Filter f = current;
        final float k = intensity / 100f;
        exec.execute(() -> {
            String err = null;
            try {
                Bitmap src = decode(u, 4096, true);
                if (!f.isOriginal() && k > 0) {
                    Bitmap fx = Renderer.render(src, f);
                    Renderer.blendInto(src, fx, k);
                    fx.recycle();
                }
                writeToGallery(src);
                src.recycle();
            } catch (OutOfMemoryError e) {
                err = "Photo too large to save";
            } catch (Throwable t) {
                err = "Couldn't save";
            }
            final String e = err;
            ui.post(() -> {
                saving = false;
                btnSave.setText("Save");
                toast(e == null ? "Saved to Pictures/Tint" : e);
                if (e == null) btnSave.performHapticFeedback(Build.VERSION.SDK_INT >= 30
                        ? HapticFeedbackConstants.CONFIRM : HapticFeedbackConstants.LONG_PRESS);
            });
        });
    }

    void writeToGallery(Bitmap b) throws IOException {
        ContentResolver cr = getContentResolver();
        ContentValues cv = new ContentValues();
        String name = "TINT_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".jpg";
        cv.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Tint");
        cv.put(MediaStore.Images.Media.IS_PENDING, 1);
        Uri out = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
        if (out == null) throw new IOException("insert failed");
        try (OutputStream os = cr.openOutputStream(out)) {
            if (os == null || !b.compress(Bitmap.CompressFormat.JPEG, 95, os)) throw new IOException("write failed");
        } catch (IOException e) {
            cr.delete(out, null, null);
            throw e;
        }
        cv.clear();
        cv.put(MediaStore.Images.Media.IS_PENDING, 0);
        cr.update(out, cv, null, null);
    }
}
