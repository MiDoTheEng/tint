package app.tint;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation;
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenter;
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions;

public class MainActivity extends Activity {
    static final int REQ_PICK = 1, REQ_STICKER = 2, REQ_BGPHOTO = 3;
    static final int M_FILTERS = 0, M_TEXT = 1, M_PHOTO = 2, M_CUT = 3;
    static final int BG = 0xFF0A0A0B, SURFACE = 0xFF17171A, SURFACE2 = 0xFF222226, TEXT = 0xFFF4F4F5,
            DIM = 0xFF8B8B92, ACCENT = 0xFFFF4D2E, LINE = 0x26FFFFFF;
    static final int PREVIEW_MAX = 2048;

    final ExecutorService exec = Executors.newSingleThreadExecutor();
    final ExecutorService thumbExec = Executors.newSingleThreadExecutor();
    final Handler ui = new Handler(Looper.getMainLooper());

    final List<Filter> all = Filters.all();
    final Map<Filter, Bitmap> thumbs = new HashMap<>();
    final Map<Filter, View> itemViews = new HashMap<>();
    final Map<String, TextView> chips = new LinkedHashMap<>();
    final List<TextView> styleChips = new ArrayList<>();
    final List<View> colorDots = new ArrayList<>();

    String category = "All";
    Filter current;
    int intensity = 100;
    Uri photoUri;
    Bitmap preview, thumbSrc;
    volatile int gen, thumbGen;
    boolean saving, syncingText, cutting;
    int mode;
    SubjectSegmenter segmenter, maskSegmenter;
    Bitmap previewOrig;                  // main photo as opened (preview size)
    BaseEdit edit = new BaseEdit();      // cut-out, background, rotate, crop of the main photo
    boolean maskBusy, syncingCut;
    volatile int baseGen;
    TextView btnBg, btnBrush, tabCut;
    LinearLayout cutPanel, maskTools, bgTools, blurRow;
    SeekBar softSeek, growSeek, blurSeek;
    final List<View> bgSwatches = new ArrayList<>();
    final Runnable regenLater = this::regenThumbs;

    Views.AspectFrame stage;
    Views.Overlay overlay;
    ImageView ivOrig, ivFx;
    TextView tvName, tvPct, btnSave, openPill, hint, tabFilters, tabText, tabPhoto, btnCut, btnOutline;
    SeekBar seek, sizeSeek, opacitySeek;
    String fontCat = "All";
    // blank canvas
    boolean blank, blankTransparent;
    int blankColor = Color.WHITE;
    float blankRatio = 0.8f;
    // the canvas actually in use (the start screen choices only apply when "Create" is tapped)
    boolean canvasTransparent;
    int canvasColor = Color.WHITE;
    float canvasRatio = 0.8f;
    View startScreen, checker, recentBlock;
    LinearLayout recentRow;
    String projectId;
    Bitmap sampleBmp;
    Views.AspectFrame startPreview;
    View startPreviewFill;
    final List<View> startSwatches = new ArrayList<>();
    final List<TextView> startRatios = new ArrayList<>();
    LinearLayout fontRow, fontCatRow;
    final Map<String, TextView> fontChips = new HashMap<>();
    final Map<String, TextView> fontCatChips = new LinkedHashMap<>();
    LinearLayout chipRow, strip, filterPanel, textPanel, photoPanel;
    HorizontalScrollView stripScroll;
    EditText input;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window win = getWindow();
        win.setStatusBarColor(Color.TRANSPARENT);
        win.setNavigationBarColor(Color.TRANSPARENT);
        win.setNavigationBarContrastEnforced(false);
        if (Build.VERSION.SDK_INT >= 30) {
            win.setDecorFitsSystemWindows(false);
        } else {
            win.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        Fonts.init(this);
        current = all.get(0);
        FrameLayout frame = new FrameLayout(this);
        frame.addView(buildUi(), new FrameLayout.LayoutParams(-1, -1));
        startScreen = buildStartScreen();
        frame.addView(startScreen, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);
        refreshChips();
        buildStrip();
        setMode(M_FILTERS);
        sampleBmp = Renderer.sample(1080, 1350);
        setSource(sampleBmp, null);
        if (!handleIncoming(getIntent())) showStart(true);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIncoming(intent);
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveProject(null);
    }

    @Override
    protected void onDestroy() {
        exec.shutdownNow();
        thumbExec.shutdownNow();
        if (segmenter != null) segmenter.close();
        if (maskSegmenter != null) maskSegmenter.close();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (startScreen.getVisibility() == View.VISIBLE) {
            if (photoUri != null || blank) { showStart(false); return; }
            super.onBackPressed();
            return;
        }
        if (mode != M_FILTERS) { setMode(M_FILTERS); return; }
        super.onBackPressed();
    }

    // ------------------------------------------------------------------ UI helpers

    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    GradientDrawable round(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    TextView pill(String text, boolean filled) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setPadding(dp(18), dp(9), dp(18), dp(9));
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = round(filled ? ACCENT : Color.TRANSPARENT, dp(100));
        if (!filled) g.setStroke(dp(1), LINE);
        t.setBackground(g);
        t.setTextColor(filled ? Color.WHITE : TEXT);
        return t;
    }

    HorizontalScrollView hscroll(View child) {
        HorizontalScrollView s = new HorizontalScrollView(this);
        s.setHorizontalScrollBarEnabled(false);
        s.setHorizontalFadingEdgeEnabled(true);
        s.setFadingEdgeLength(dp(24));
        s.addView(child);
        return s;
    }

    SeekBar slider(int max, int value) {
        SeekBar s = new SeekBar(this);
        s.setMax(max);
        s.setProgress(value);
        s.setProgressTintList(ColorStateList.valueOf(ACCENT));
        s.setProgressBackgroundTintList(ColorStateList.valueOf(0x40FFFFFF));
        s.setThumbTintList(ColorStateList.valueOf(Color.WHITE));
        s.setPadding(dp(24), dp(12), dp(24), dp(12));
        return s;
    }

    interface Progress { void on(int p); }

    void onSlide(SeekBar s, Progress p) {
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int v, boolean user) { p.on(v); }
            public void onStartTrackingTouch(SeekBar b) { }
            public void onStopTrackingTouch(SeekBar b) { }
        });
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ------------------------------------------------------------------ layout

    View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            int t, b, l, r;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                Insets k = ins.getInsets(WindowInsets.Type.ime());
                t = i.top; b = Math.max(i.bottom, k.bottom); l = i.left; r = i.right;
            } else {
                t = ins.getSystemWindowInsetTop(); b = ins.getSystemWindowInsetBottom();
                l = ins.getSystemWindowInsetLeft(); r = ins.getSystemWindowInsetRight();
            }
            v.setPadding(l, t, r, b + dp(10));
            return ins;
        });

        // top bar
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(22), dp(10), dp(14), dp(10));
        TextView logo = new TextView(this);
        logo.setText("TINT");
        logo.setTextColor(TEXT);
        logo.setTextSize(20);
        logo.setLetterSpacing(0.28f);
        logo.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        top.addView(logo);
        View dot = new View(this);
        GradientDrawable dd = new GradientDrawable();
        dd.setShape(GradientDrawable.OVAL);
        dd.setColor(ACCENT);
        dot.setBackground(dd);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(6), dp(6));
        dlp.setMargins(dp(2), 0, 0, dp(8));
        top.addView(dot, dlp);
        top.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        TextView open = pill("New", false);
        open.setOnClickListener(v -> showStart(true));
        top.addView(open);
        btnSave = pill("Save", true);
        btnSave.setOnClickListener(v -> save());
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
        slp.setMargins(dp(8), 0, 0, 0);
        top.addView(btnSave, slp);
        root.addView(top);

        // photo stage: takes the exact shape of the photo
        FrameLayout holder = new FrameLayout(this);
        stage = new Views.AspectFrame(this);
        stage.setBackground(round(SURFACE, dp(22)));
        stage.setClipToOutline(true);
        ivOrig = new ImageView(this);
        ivOrig.setScaleType(ImageView.ScaleType.FIT_XY);
        ivFx = new ImageView(this);
        ivFx.setScaleType(ImageView.ScaleType.FIT_XY);
        overlay = new Views.Overlay(this);
        checker = new View(this);
        checker.setBackground(checkerDrawable());
        checker.setVisibility(View.GONE);
        stage.addView(checker, new FrameLayout.LayoutParams(-1, -1));
        stage.addView(ivOrig, new FrameLayout.LayoutParams(-1, -1));
        stage.addView(ivFx, new FrameLayout.LayoutParams(-1, -1));
        stage.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        hint = new TextView(this);
        hint.setText("Hold to compare");
        hint.setTextColor(0xDDFFFFFF);
        hint.setTextSize(11);
        hint.setPadding(dp(12), dp(5), dp(12), dp(5));
        hint.setBackground(round(0x66000000, dp(100)));
        FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        hlp.topMargin = dp(12);
        stage.addView(hint, hlp);

        openPill = new TextView(this);
        openPill.setText("＋   Open a photo");
        openPill.setTextColor(Color.BLACK);
        openPill.setTextSize(15);
        openPill.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        openPill.setPadding(dp(22), dp(12), dp(22), dp(12));
        openPill.setBackground(round(Color.WHITE, dp(100)));
        openPill.setElevation(dp(6));
        openPill.setOnClickListener(v -> pick());
        FrameLayout.LayoutParams olp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        olp.bottomMargin = dp(20);
        stage.addView(openPill, olp);

        stage.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (mode != M_FILTERS) {
                if (a == MotionEvent.ACTION_DOWN) deselect();
                return true;
            }
            if (a == MotionEvent.ACTION_DOWN) {
                ivFx.setVisibility(View.INVISIBLE);
                overlay.setVisibility(View.INVISIBLE);
                hint.setText("Original");
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                ivFx.setVisibility(View.VISIBLE);
                overlay.setVisibility(View.VISIBLE);
                hint.setText("Hold to compare");
            }
            return true;
        });

        holder.addView(stage, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, 0, 1f);
        hp.setMargins(dp(14), dp(2), dp(14), dp(10));
        root.addView(holder, hp);

        // Filters | Text tabs
        LinearLayout tabs = new LinearLayout(this);
        tabs.setBackground(round(SURFACE, dp(100)));
        tabs.setPadding(dp(4), dp(4), dp(4), dp(4));
        tabFilters = tab("Filters");
        tabText = tab("Text · نص");
        tabPhoto = tab("Add +");
        tabFilters.setOnClickListener(v -> setMode(M_FILTERS));
        tabText.setOnClickListener(v -> setMode(M_TEXT));
        tabPhoto.setOnClickListener(v -> setMode(M_PHOTO));
        tabCut = tab("Cut ✂");
        tabCut.setOnClickListener(v -> setMode(M_CUT));
        tabs.addView(tabFilters);
        tabs.addView(tabText);
        tabs.addView(tabPhoto);
        tabs.addView(tabCut);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-2, -2);
        tlp.gravity = Gravity.CENTER_HORIZONTAL;
        tlp.bottomMargin = dp(8);
        root.addView(tabs, tlp);

        root.addView(buildFilterPanel());
        root.addView(buildTextPanel());
        root.addView(buildPhotoPanel());
        root.addView(buildCutPanel());

        overlay.listener = new Views.Overlay.Listener() {
            public void onSelect(Item it) {
                if (it instanceof TextArt.Layer && mode != M_TEXT) setMode(M_TEXT);
                else if (it instanceof Item.Sticker && mode != M_PHOTO) setMode(M_PHOTO);
                refreshControls();
                renderPreview();
            }
            public void onChanged() { refreshControls(); }
            public void onDelete(Item it) { deleteItem(it); }
        };

        tvName.setText(current.name);
        return root;
    }

    TextView tab(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(13);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setPadding(dp(13), dp(7), dp(13), dp(7));
        return t;
    }

    View buildFilterPanel() {
        filterPanel = new LinearLayout(this);
        filterPanel.setOrientation(LinearLayout.VERTICAL);

        LinearLayout info = new LinearLayout(this);
        info.setGravity(Gravity.CENTER_VERTICAL);
        info.setPadding(dp(24), 0, dp(24), 0);
        tvName = new TextView(this);
        tvName.setTextColor(TEXT);
        tvName.setTextSize(15);
        tvName.setLetterSpacing(0.12f);
        tvName.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        info.addView(tvName);
        info.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        tvPct = new TextView(this);
        tvPct.setTextColor(DIM);
        tvPct.setTextSize(13);
        tvPct.setTypeface(Typeface.MONOSPACE);
        tvPct.setText("100");
        info.addView(tvPct);
        filterPanel.addView(info);

        seek = slider(100, 100);
        onSlide(seek, p -> {
            intensity = p;
            tvPct.setText(String.valueOf(p));
            ivFx.setAlpha(p / 100f);
            overlay.liveK = p / 100f;
            overlay.invalidate();
        });
        filterPanel.addView(seek);

        chipRow = new LinearLayout(this);
        chipRow.setPadding(dp(14), dp(4), dp(14), dp(4));
        for (String cat : Filters.CATEGORIES) {
            TextView chip = new TextView(this);
            chip.setText(cat);
            chip.setTextSize(13);
            chip.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            chip.setPadding(dp(15), dp(7), dp(15), dp(7));
            chip.setOnClickListener(v -> {
                if (cat.equals(category)) return;
                category = cat;
                v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                refreshChips();
                buildStrip();
            });
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
            clp.setMargins(dp(2), 0, dp(2), 0);
            chipRow.addView(chip, clp);
            chips.put(cat, chip);
        }
        filterPanel.addView(hscroll(chipRow));

        strip = new LinearLayout(this);
        strip.setPadding(dp(12), dp(12), dp(12), dp(4));
        stripScroll = hscroll(strip);
        filterPanel.addView(stripScroll);
        return filterPanel;
    }

    View buildTextPanel() {
        textPanel = new LinearLayout(this);
        textPanel.setOrientation(LinearLayout.VERTICAL);

        // input row
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), 0, dp(16), 0);
        input = new EditText(this);
        input.setHint("Type here…  اكتب هنا");
        input.setHintTextColor(DIM);
        input.setTextColor(TEXT);
        input.setTextSize(15);
        input.setBackground(round(SURFACE, dp(16)));
        input.setPadding(dp(16), dp(11), dp(16), dp(11));
        input.setMaxLines(3);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        input.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(Editable s) {
                if (syncingText) return;
                if (selText() == null) {
                    if (s.length() == 0) return;
                    addLayer(false);
                }
                selText().text = s.toString();
                overlay.invalidate();
            }
        });
        row.addView(input, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView add = pill("＋", true);
        add.setTextSize(18);
        add.setPadding(dp(16), dp(6), dp(16), dp(6));
        add.setOnClickListener(v -> addLayer(true));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-2, -2);
        alp.setMargins(dp(8), 0, 0, 0);
        row.addView(add, alp);
        TextView done = pill("✓", false);
        done.setTextSize(17);
        done.setPadding(dp(15), dp(6), dp(15), dp(6));
        done.setOnClickListener(v -> hideKeyboard());
        row.addView(done, alp);
        textPanel.addView(row);

        // styles
        LinearLayout styles = new LinearLayout(this);
        styles.setPadding(dp(14), dp(12), dp(14), dp(2));
        for (int i = 0; i < TextArt.STYLES.length; i++) {
            final int idx = i;
            TextView s = new TextView(this);
            s.setText(TextArt.STYLES[i]);
            s.setTypeface(TextArt.typeface(i));
            s.setTextSize(15);
            s.setTextColor(TEXT);
            s.setPadding(dp(16), dp(9), dp(16), dp(9));
            s.setOnClickListener(v -> {
                if (selText() == null) addLayer(true);
                selText().style = idx;
                v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                refreshControls();
                overlay.invalidate();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.setMargins(dp(3), 0, dp(3), 0);
            styles.addView(s, lp);
            styleChips.add(s);
        }
        textPanel.addView(hscroll(styles));

        // fonts: category chips + font list (each shown in its own font)
        fontCatRow = new LinearLayout(this);
        fontCatRow.setPadding(dp(14), dp(10), dp(14), 0);
        for (String cat : Fonts.CATEGORIES) {
            TextView ch = new TextView(this);
            ch.setText(cat.equals("Arabic") ? "Arabic · عربي" : cat);
            ch.setTextSize(12);
            ch.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            ch.setPadding(dp(13), dp(5), dp(13), dp(5));
            ch.setOnClickListener(v -> { fontCat = cat; buildFontRow(); });
            fontCatRow.addView(ch);
            fontCatChips.put(cat, ch);
        }
        textPanel.addView(hscroll(fontCatRow));
        fontRow = new LinearLayout(this);
        fontRow.setPadding(dp(14), dp(8), dp(14), 0);
        fontRow.setGravity(Gravity.CENTER_VERTICAL);
        textPanel.addView(hscroll(fontRow));
        buildFontRow();

        // colours
        LinearLayout colors = new LinearLayout(this);
        colors.setPadding(dp(16), dp(10), dp(16), dp(2));
        colors.setGravity(Gravity.CENTER_VERTICAL);
        for (int col : TextArt.COLORS) {
            View d = new View(this);
            d.setTag(col);
            d.setOnClickListener(v -> {
                if (selText() == null) addLayer(true);
                selText().color = col;
                v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                refreshControls();
                overlay.invalidate();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(30), dp(30));
            lp.setMargins(dp(5), 0, dp(5), 0);
            colors.addView(d, lp);
            colorDots.add(d);
        }
        textPanel.addView(hscroll(colors));

        // size
        sizeSeek = slider(100, 35);
        onSlide(sizeSeek, p -> {
            if (syncingText || selText() == null) return;
            selText().size = 0.02f + p / 100f * 0.28f;
            overlay.invalidate();
        });
        textPanel.addView(sizeSeek);

        return textPanel;
    }

    TextArt.Layer selText() {
        return overlay.selected instanceof TextArt.Layer ? (TextArt.Layer) overlay.selected : null;
    }

    Item.Sticker selSticker() {
        return overlay.selected instanceof Item.Sticker ? (Item.Sticker) overlay.selected : null;
    }

    void setMode(int m) {
        mode = m;
        filterPanel.setVisibility(m == M_FILTERS ? View.VISIBLE : View.GONE);
        textPanel.setVisibility(m == M_TEXT ? View.VISIBLE : View.GONE);
        photoPanel.setVisibility(m == M_PHOTO ? View.VISIBLE : View.GONE);
        cutPanel.setVisibility(m == M_CUT ? View.VISIBLE : View.GONE);
        overlay.editing = m == M_TEXT || m == M_PHOTO;
        if (m == M_CUT) overlay.selected = null;
        TextView[] ts = {tabFilters, tabText, tabPhoto, tabCut};
        for (int i = 0; i < 4; i++) {
            ts[i].setBackground(i == m ? round(Color.WHITE, dp(100)) : null);
            ts[i].setTextColor(i == m ? Color.BLACK : DIM);
        }
        hint.setText(m == M_FILTERS ? "Hold to compare" : m == M_CUT ? "Cut · crop · new background"
                : "Drag · twist · pinch · tap outside to deselect");
        if (m == M_TEXT) {
            if (selText() == null) {
                TextArt.Layer last = null;
                for (Item it : overlay.items) if (it instanceof TextArt.Layer) last = (TextArt.Layer) it;
                if (last != null) overlay.selected = last; else addLayer(true);
            }
        } else {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
            input.clearFocus();
        }
        if (m == M_PHOTO && selSticker() == null) {
            Item.Sticker last = null;
            for (Item it : overlay.items) if (it instanceof Item.Sticker) last = (Item.Sticker) it;
            overlay.selected = last;
        }
        refreshControls();
        overlay.invalidate();
        renderPreview();
    }

    void deselect() {
        if (overlay.selected == null) return;
        overlay.selected = null;
        hideKeyboard();
        refreshControls();
        overlay.invalidate();
        renderPreview();
    }

    void addLayer(boolean showKeyboard) {
        TextArt.Layer l = new TextArt.Layer();
        TextArt.Layer prev = selText();
        if (prev != null) { l.style = prev.style; l.color = prev.color; l.font = prev.font; }
        l.y = 0.5f + 0.08f * (overlay.items.size() % 4);
        overlay.items.add(l);
        overlay.selected = l;
        refreshControls();
        overlay.invalidate();
        if (showKeyboard) {
            input.requestFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
        }
    }

    void deleteItem(Item it) {
        overlay.items.remove(it);
        overlay.selected = null;
        for (Item o : overlay.items)
            if ((mode == M_TEXT && o instanceof TextArt.Layer) || (mode == M_PHOTO && o instanceof Item.Sticker))
                overlay.selected = o;
        refreshControls();
        overlay.invalidate();
        renderPreview();
    }

    void refreshControls() {
        refreshPhotoControls();
        TextArt.Layer l = selText();
        syncingText = true;
        String t = l == null ? "" : l.text;
        if (!input.getText().toString().equals(t)) {
            input.setText(t);
            input.setSelection(t.length());
        }
        sizeSeek.setProgress(l == null ? 35 : Math.round((l.size - 0.02f) / 0.28f * 100));
        syncingText = false;
        int style = l == null ? -1 : l.style;
        for (int i = 0; i < styleChips.size(); i++) {
            TextView s = styleChips.get(i);
            boolean sel = i == style;
            s.setBackground(sel ? round(Color.WHITE, dp(100)) : round(SURFACE, dp(100)));
            s.setTextColor(sel ? Color.BLACK : TEXT);
        }
        String fk = l == null ? "-" : String.valueOf(l.font);
        for (Map.Entry<String, TextView> e : fontChips.entrySet()) {
            boolean sel = l != null && e.getKey().equals(fk);
            e.getValue().setBackground(round(sel ? Color.WHITE : SURFACE, dp(100)));
            e.getValue().setTextColor(sel ? Color.BLACK : TEXT);
        }
        int color = l == null ? 0 : l.color;
        for (View d : colorDots) {
            int c = (Integer) d.getTag();
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(c);
            boolean sel = l != null && c == color;
            g.setStroke(dp(sel ? 3 : 1), sel ? ACCENT : LINE);
            d.setBackground(g);
        }
    }

    // ------------------------------------------------------------------ photo on photo

    TextView action(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(13);
        t.setTextColor(TEXT);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(10), dp(16), dp(10));
        t.setBackground(round(SURFACE, dp(100)));
        return t;
    }

    View buildPhotoPanel() {
        photoPanel = new LinearLayout(this);
        photoPanel.setOrientation(LinearLayout.VERTICAL);

        LinearLayout row = new LinearLayout(this);
        row.setPadding(dp(14), dp(2), dp(14), 0);
        TextView add = action("＋  Add photo");
        add.setBackground(round(ACCENT, dp(100)));
        add.setTextColor(Color.WHITE);
        add.setOnClickListener(v -> pick(REQ_STICKER));
        btnCut = action("✂  Remove background");
        btnCut.setOnClickListener(v -> toggleCutout());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(3), 0, dp(3), 0);
        TextView stk = action("☺  Stickers");
        stk.setOnClickListener(v -> openStickers());
        row.addView(add, lp);
        row.addView(stk, lp);
        row.addView(btnCut, lp);
        photoPanel.addView(hscroll(row));

        LinearLayout row2 = new LinearLayout(this);
        row2.setPadding(dp(14), dp(10), dp(14), 0);
        btnOutline = action("◯  Sticker outline");
        btnOutline.setOnClickListener(v -> {
            Item.Sticker s = selSticker();
            if (s == null) return;
            s.setOutline(!s.outline);
            refreshControls();
            overlay.invalidate();
        });
        TextView cropBtn = action("⌗  Crop");
        cropBtn.setOnClickListener(v -> openCrop());
        row2.addView(cropBtn, lp);
        TextView flip = action("⇋  Flip");
        flip.setOnClickListener(v -> {
            Item.Sticker s = selSticker();
            if (s == null) return;
            s.flip = !s.flip;
            overlay.invalidate();
        });
        TextView front = action("⬆  Bring to front");
        front.setOnClickListener(v -> {
            Item s = overlay.selected;
            if (s == null) return;
            overlay.items.remove(s);
            overlay.items.add(s);
            overlay.invalidate();
            renderPreview();
        });
        row2.addView(btnOutline, lp);
        row2.addView(flip, lp);
        row2.addView(front, lp);
        photoPanel.addView(hscroll(row2));

        TextView op = new TextView(this);
        op.setText("Opacity");
        op.setTextColor(DIM);
        op.setTextSize(12);
        op.setPadding(dp(24), dp(12), dp(24), 0);
        photoPanel.addView(op);
        opacitySeek = slider(100, 100);
        onSlide(opacitySeek, p -> {
            Item.Sticker s = selSticker();
            if (syncingText || s == null) return;
            s.opacity = Math.max(0.05f, p / 100f);
            overlay.invalidate();
        });
        photoPanel.addView(opacitySeek);
        return photoPanel;
    }

    void refreshPhotoControls() {
        if (btnCut == null) return;
        Item.Sticker s = selSticker();
        float on = s == null ? 0.4f : 1f;
        btnCut.setAlpha(cutting ? 0.6f : on);
        btnOutline.setAlpha(on);
        btnCut.setText(cutting ? "✂  Removing…" : (s != null && s.cutout ? "↺  Restore background" : "✂  Remove background"));
        btnOutline.setBackground(round(s != null && s.outline ? 0xFF3A3A40 : SURFACE, dp(100)));
        syncingText = true;
        opacitySeek.setProgress(s == null ? 100 : Math.round(s.opacity * 100));
        syncingText = false;
    }

    int stickerCat = 0;

    void openStickers() {
        android.app.Dialog dlg = new android.app.Dialog(this, android.R.style.Theme_Material_NoActionBar);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(SURFACE);
        float r = dp(26);
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        root.setBackground(bg);
        root.setPadding(0, dp(10), 0, dp(10));

        View grab = new View(this);
        grab.setBackground(round(0x55FFFFFF, dp(100)));
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(dp(40), dp(4));
        gp.gravity = Gravity.CENTER_HORIZONTAL;
        gp.bottomMargin = dp(10);
        root.addView(grab, gp);

        GridView grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(dp(56));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setVerticalSpacing(dp(4));
        grid.setPadding(dp(10), dp(6), dp(10), dp(6));
        grid.setClipToPadding(false);
        grid.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));

        final String[][] items = {Stickers.pack(stickerCat)};
        BaseAdapter adapter = new BaseAdapter() {
            public int getCount() { return items[0].length; }
            public Object getItem(int i) { return items[0][i]; }
            public long getItemId(int i) { return i; }
            public View getView(int i, View cv, ViewGroup parent) {
                TextView t = cv instanceof TextView ? (TextView) cv : new TextView(MainActivity.this);
                t.setText(items[0][i]);
                t.setTextSize(32);
                t.setGravity(Gravity.CENTER);
                t.setLayoutParams(new AbsListView.LayoutParams(-1, dp(58)));
                return t;
            }
        };
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((parent, v, i, id) -> {
            addEmojiSticker(items[0][i]);
            dlg.dismiss();
        });

        LinearLayout cats = new LinearLayout(this);
        cats.setPadding(dp(12), 0, dp(12), dp(6));
        List<TextView> chipsL = new ArrayList<>();
        for (int i = 0; i < Stickers.CATS.length; i++) {
            final int idx = i;
            TextView c = new TextView(this);
            c.setText(Stickers.CATS[i]);
            c.setTextSize(13);
            c.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            c.setPadding(dp(14), dp(6), dp(14), dp(6));
            c.setOnClickListener(v -> {
                stickerCat = idx;
                items[0] = Stickers.pack(idx);
                adapter.notifyDataSetChanged();
                grid.setSelection(0);
                for (int j = 0; j < chipsL.size(); j++) {
                    chipsL.get(j).setBackground(j == idx ? round(Color.WHITE, dp(100)) : null);
                    chipsL.get(j).setTextColor(j == idx ? Color.BLACK : DIM);
                }
            });
            c.setBackground(i == stickerCat ? round(Color.WHITE, dp(100)) : null);
            c.setTextColor(i == stickerCat ? Color.BLACK : DIM);
            chipsL.add(c);
            cats.addView(c);
        }
        root.addView(hscroll(cats));
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1f));

        dlg.setContentView(root);
        dlg.setCanceledOnTouchOutside(true);
        Window w = dlg.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, Math.round(getResources().getDisplayMetrics().heightPixels * 0.62f));
            w.setGravity(Gravity.BOTTOM);
            w.setDimAmount(0.4f);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            w.setWindowAnimations(android.R.style.Animation_InputMethod);
        }
        dlg.show();
    }

    void addEmojiSticker(String e) {
        Bitmap b = Stickers.render(e, 640);
        Item.Sticker s = new Item.Sticker(b);
        float photoRatio = preview == null ? 1 : (float) preview.getWidth() / preview.getHeight();
        s.size = Math.max(0.15f, Math.min(0.4f, 0.32f / Math.max(1f, 1f / photoRatio) * (float) b.getWidth() / b.getHeight()));
        s.x = 0.5f + (overlay.items.size() % 3 - 1) * 0.08f;
        s.y = 0.45f + (overlay.items.size() % 4) * 0.05f;
        overlay.items.add(s);
        overlay.selected = s;
        if (mode != M_PHOTO) setMode(M_PHOTO);
        refreshControls();
        overlay.invalidate();
        renderPreview();
    }

    void loadSticker(Uri u) {
        exec.execute(() -> {
            try {
                Bitmap b = decode(u, 2048, false);
                ui.post(() -> {
                    Item.Sticker s = new Item.Sticker(b);
                    float photoRatio = preview == null ? 1 : (float) preview.getWidth() / preview.getHeight();
                    float stickerRatio = (float) b.getWidth() / b.getHeight();
                    s.size = Math.min(0.6f, 0.6f * stickerRatio / photoRatio + 0.0001f);
                    s.size = Math.max(0.2f, s.size);
                    overlay.items.add(s);
                    overlay.selected = s;
                    if (mode != M_PHOTO) setMode(M_PHOTO);
                    refreshControls();
                    overlay.invalidate();
                    renderPreview();
                });
            } catch (Throwable t) {
                ui.post(() -> toast("Couldn't open that photo"));
            }
        });
    }

    void toggleCutout() {
        Item.Sticker s = selSticker();
        if (s == null) { toast("Add a photo first"); return; }
        if (cutting) return;
        if (s.cutout) {                       // restore
            s.cutout = false;
            s.setBitmap(s.original);
            refreshControls();
            overlay.invalidate();
            return;
        }
        if (segmenter == null) {
            segmenter = SubjectSegmentation.getClient(new SubjectSegmenterOptions.Builder()
                    .enableForegroundBitmap()
                    .build());
        }
        cutting = true;
        refreshControls();
        segmenter.process(InputImage.fromBitmap(s.original, 0))
                .addOnSuccessListener(result -> {
                    cutting = false;
                    Bitmap fg = result.getForegroundBitmap();
                    if (fg == null) {
                        toast("Couldn't find a subject in this photo");
                    } else {
                        s.cutout = true;
                        s.setBitmap(fg);
                        btnCut.performHapticFeedback(Build.VERSION.SDK_INT >= 30
                                ? HapticFeedbackConstants.CONFIRM : HapticFeedbackConstants.LONG_PRESS);
                    }
                    refreshControls();
                    overlay.invalidate();
                })
                .addOnFailureListener(e -> {
                    cutting = false;
                    refreshControls();
                    String m = String.valueOf(e.getMessage()).toLowerCase(Locale.US);
                    toast(m.contains("download") || m.contains("waiting")
                            ? "Getting the background tool ready (needs internet once). Try again in a minute."
                            : "Couldn't remove the background");
                });
    }

    void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
        input.clearFocus();
    }

    void buildFontRow() {
        for (Map.Entry<String, TextView> e : fontCatChips.entrySet()) {
            boolean sel = e.getKey().equals(fontCat);
            e.getValue().setBackground(sel ? round(Color.WHITE, dp(100)) : null);
            e.getValue().setTextColor(sel ? Color.BLACK : DIM);
        }
        fontRow.removeAllViews();
        fontChips.clear();
        List<Fonts.Font> list = Fonts.available(fontCat);
        if (fontCat.equals("All")) fontRow.addView(fontChip(null, "Style font"));
        for (Fonts.Font f : list) fontRow.addView(fontChip(f.key, f.arabic() ? "نص  " + f.name : f.name));
        if (list.isEmpty() && !fontCat.equals("All")) {
            TextView none = new TextView(this);
            none.setText("No fonts in this build");
            none.setTextColor(DIM);
            fontRow.addView(none);
        }
        if (sizeSeek != null) refreshControls();
    }

    TextView fontChip(String key, String label) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(16);
        t.setTextColor(TEXT);
        t.setSingleLine(true);
        Typeface tf = key == null ? null : Fonts.get(key);
        t.setTypeface(tf != null ? tf : Typeface.create("sans-serif-medium", Typeface.ITALIC));
        t.setPadding(dp(16), dp(8), dp(16), dp(8));
        t.setOnClickListener(v -> {
            if (selText() == null) addLayer(false);
            selText().font = key;
            v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            refreshControls();
            overlay.invalidate();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(3), 0, dp(3), 0);
        t.setLayoutParams(lp);
        fontChips.put(String.valueOf(key), t);
        return t;
    }

    // ------------------------------------------------------------------ crop

    void openCrop() {
        Item.Sticker st = selSticker();
        if (st == null) { toast("Add a photo first"); return; }
        openCropFor(st.bmp, (r, c) -> applyCrop(st, r, c));
    }

    interface CropDone { void done(Rect r, boolean circle); }

    void openCropFor(Bitmap src, CropDone cb) {
        android.app.Dialog dlg = new android.app.Dialog(this, android.R.style.Theme_Material_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(i.left, i.top, i.right, i.bottom + dp(10));
            } else {
                v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom() + dp(10));
            }
            return ins;
        });

        Views.CropView cv = new Views.CropView(this, src);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(10), dp(14), dp(10));
        TextView cancel = pill("Cancel", false);
        cancel.setOnClickListener(v -> dlg.dismiss());
        TextView title = new TextView(this);
        title.setText("Crop");
        title.setTextColor(TEXT);
        title.setTextSize(16);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        TextView ok = pill("Done", true);
        ok.setOnClickListener(v -> {
            cb.done(cv.result(), cv.circle);
            dlg.dismiss();
        });
        bar.addView(cancel);
        bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        bar.addView(ok);
        root.addView(bar);
        root.addView(cv, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout ratios = new LinearLayout(this);
        ratios.setPadding(dp(14), dp(12), dp(14), dp(4));
        String[] names = {"Free", "1:1", "4:5", "3:4", "9:16", "16:9", "3:2", "Circle"};
        float[] vals = {0, 1, 0.8f, 0.75f, 9f / 16, 16f / 9, 1.5f, 1};
        List<TextView> rs = new ArrayList<>();
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView r = new TextView(this);
            r.setText(names[i]);
            r.setTextSize(13);
            r.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            r.setPadding(dp(15), dp(7), dp(15), dp(7));
            r.setOnClickListener(v -> {
                cv.setAspect(vals[idx], idx == names.length - 1);
                for (int j = 0; j < rs.size(); j++) {
                    rs.get(j).setBackground(j == idx ? round(Color.WHITE, dp(100)) : null);
                    rs.get(j).setTextColor(j == idx ? Color.BLACK : DIM);
                }
            });
            r.setBackground(i == 0 ? round(Color.WHITE, dp(100)) : null);
            r.setTextColor(i == 0 ? Color.BLACK : DIM);
            rs.add(r);
            ratios.addView(r);
        }
        root.addView(hscroll(ratios));

        dlg.setContentView(root);
        Window w = dlg.getWindow();
        if (w != null) {
            w.setStatusBarColor(Color.TRANSPARENT);
            w.setNavigationBarColor(Color.TRANSPARENT);
            if (Build.VERSION.SDK_INT >= 30) w.setDecorFitsSystemWindows(false);
        }
        dlg.show();
    }

    static Bitmap cropBitmap(Bitmap src, Rect r, boolean circle) {
        Bitmap out = Bitmap.createBitmap(r.width(), r.height(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        if (circle) {
            c.drawOval(new RectF(0, 0, r.width(), r.height()), p);
            p.setBlendMode(BlendMode.SRC_IN);
        }
        c.drawBitmap(src, r, new Rect(0, 0, r.width(), r.height()), p);
        return out;
    }

    void applyCrop(Item.Sticker st, Rect r, boolean circle) {
        float frac = (float) r.width() / st.bmp.getWidth();
        Bitmap orig = cropBitmap(st.original, r, circle);
        Bitmap shown = st.bmp == st.original ? orig : cropBitmap(st.bmp, r, circle);
        st.original = orig;
        st.setBitmap(shown);
        st.size = Math.max(st.minSize(), st.size * frac);
        refreshControls();
        overlay.invalidate();
    }

    // ------------------------------------------------------------------ start screen

    android.graphics.drawable.Drawable checkerDrawable() {
        int t = dp(10);
        Bitmap b = Bitmap.createBitmap(t * 2, t * 2, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(0xFF3A3A3F);
        Paint p = new Paint();
        p.setColor(0xFF26262A);
        c.drawRect(0, 0, t, t, p);
        c.drawRect(t, t, 2 * t, 2 * t, p);
        android.graphics.drawable.BitmapDrawable d = new android.graphics.drawable.BitmapDrawable(getResources(), b);
        d.setTileModeXY(Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
        return d;
    }

    static final int[] CANVAS_COLORS = {0xFFFFFFFF, 0xFF0A0A0A, 0xFFF6F0E6, 0xFFE9DCC9, 0xFFFFD6E0, 0xFFFFC9A8,
            0xFFD9C9FF, 0xFFBFE3FF, 0xFFC5F2DA, 0xFFA9C2A3, 0xFF1E2A4A, 0xFF6E1E2E, 0xFFE8B63A, 0xFFFF6F61, 0xFF2B2B30};

    Bitmap makeBlank(int longSide) {
        int w, h;
        if (canvasRatio >= 1) { w = longSide; h = Math.round(longSide / canvasRatio); }
        else { h = longSide; w = Math.round(longSide * canvasRatio); }
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        if (canvasTransparent) {
            b.eraseColor(Color.TRANSPARENT);
        } else {
            b.eraseColor(canvasColor);
            b.setHasAlpha(false);
        }
        return b;
    }

    void showStart(boolean show) {
        startScreen.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            hideKeyboard();
            refreshRecent();
            saveProject(this::refreshRecent);
        }
    }

    // ------------------------------------------------------------------ projects (history)

    void refreshRecent() {
        if (recentRow == null) return;
        recentRow.removeAllViews();
        List<java.io.File> list = Projects.list(this);
        recentBlock.setVisibility(list.isEmpty() ? View.GONE : View.VISIBLE);
        int n = 0;
        for (java.io.File d : list) {
            if (n++ >= 40) break;
            java.io.File tf = new java.io.File(d, "thumb.jpg");
            Bitmap t = tf.exists() ? BitmapFactory.decodeFile(tf.getPath()) : null;
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(round(SURFACE2, dp(16)));
            iv.setClipToOutline(true);
            iv.setImageBitmap(t);
            int h = dp(132);
            int w = t == null ? dp(105) : Math.max(dp(74), Math.min(dp(200), Math.round(h * (float) t.getWidth() / t.getHeight())));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
            lp.setMargins(0, 0, dp(10), 0);
            iv.setOnClickListener(v -> openProject(d));
            iv.setOnLongClickListener(v -> {
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                new android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                        .setTitle("Delete this project?")
                        .setMessage("It's removed from Tint only. Photos you saved to your gallery stay.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete", (dlg, which) -> {
                            if (d.getName().equals(projectId)) projectId = null;
                            Projects.delete(d);
                            refreshRecent();
                        })
                        .show();
                return true;
            });
            recentRow.addView(iv, lp);
        }
    }

    /** Remembers everything about the current edit so it can be reopened later. */
    void saveProject(Runnable after) {
        if (projectId == null || preview == null || (photoUri == null && !blank)) {
            if (after != null) after.run();
            return;
        }
        final String id = projectId;
        final java.io.File dir = Projects.dir(this, id);
        final List<Item> items = new ArrayList<>();
        final List<Item.Sticker> toWrite = new ArrayList<>();
        for (Item it : overlay.items) {
            if (it instanceof TextArt.Layer && ((TextArt.Layer) it).text.trim().isEmpty()) continue;
            if (it instanceof Item.Sticker) {
                Item.Sticker st = (Item.Sticker) it;
                if (st.key == null) st.key = Long.toString(System.nanoTime(), 36);
                toWrite.add(st);
            }
            items.add(it.copy());
        }
        final String json;
        try {
            org.json.JSONObject o = new org.json.JSONObject();
            o.put("blank", blank).put("ratio", canvasRatio).put("color", canvasColor)
                    .put("transparent", canvasTransparent).put("filter", current.name)
                    .put("intensity", intensity).put("bgRemoved", edit.mask != null)
                    .put("rot", edit.rot).put("flip", edit.flip).put("cropCircle", edit.cropCircle)
                    .put("soft", edit.soft).put("grow", edit.grow).put("bg", edit.bg)
                    .put("c1", edit.c1).put("c2", edit.c2).put("blur", edit.blur)
                    .put("items", Projects.itemsToJson(items));
            if (edit.crop != null) o.put("crop", new org.json.JSONArray()
                    .put(edit.crop.left).put(edit.crop.top).put(edit.crop.right).put(edit.crop.bottom));
            json = o.toString();
        } catch (Exception e) {
            if (after != null) after.run();
            return;
        }
        final Bitmap base = preview;
        final Filter f = current;
        final float k = intensity / 100f;
        final boolean transparent = base.hasAlpha();
        final Bitmap pm = edit.mask;
        final String pmKey = Integer.toHexString(System.identityHashCode(edit.mask)) + "_" + edit.maskVer;
        final Bitmap pbg = edit.bg == BaseEdit.BG_PHOTO ? edit.bgPhoto : null;
        final String pbgKey = Integer.toHexString(System.identityHashCode(edit.bgPhoto)) + "_" + edit.bgVer;
        exec.execute(() -> {
            try {
                for (Item.Sticker st : toWrite) {
                    Projects.writePng(st.original, new java.io.File(dir, "s_" + st.key + "_o.png"));
                    if (st.bmp != st.original) Projects.writePng(st.bmp, new java.io.File(dir, "s_" + st.key + "_b.png"));
                }
                Projects.writeText(new java.io.File(dir, "project.json"), json);
                Projects.cleanup(dir, items);
                java.io.File mf = new java.io.File(dir, "mask.png");
                java.io.File mk = new java.io.File(dir, "mask.key");
                if (pm == null) { mf.delete(); mk.delete(); }
                else if (!mk.exists() || !Projects.readText(mk).equals(pmKey)) {
                    mf.delete();
                    Projects.writePng(pm, mf);
                    Projects.writeText(mk, pmKey);
                }
                java.io.File bf = new java.io.File(dir, "bg.jpg");
                java.io.File bk = new java.io.File(dir, "bg.key");
                if (pbg == null) { bf.delete(); bk.delete(); }
                else if (!bk.exists() || !Projects.readText(bk).equals(pbgKey)) {
                    try (OutputStream os = new java.io.FileOutputStream(bf)) { pbg.compress(Bitmap.CompressFormat.JPEG, 95, os); }
                    Projects.writeText(bk, pbgKey);
                }
                writeThumb(dir, base, f, k, items, transparent);
            } catch (Throwable ignored) { }
            if (after != null) ui.post(after);
        });
    }

    void writeThumb(java.io.File dir, Bitmap base, Filter f, float k, List<Item> items, boolean transparent) throws IOException {
        float sc = 420f / Math.max(base.getWidth(), base.getHeight());
        int w = Math.max(1, Math.round(base.getWidth() * sc)), h = Math.max(1, Math.round(base.getHeight() * sc));
        Bitmap small = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(small);
        c.drawBitmap(base, null, new Rect(0, 0, w, h), new Paint(Paint.FILTER_BITMAP_FLAG));
        for (Item it : items) if (it instanceof Item.Sticker) it.draw(c, w, h);
        if (!f.isOriginal() && k > 0) {
            Bitmap fx = Renderer.render(small, f);
            Paint p = new Paint();
            p.setAlpha(Math.round(255 * k));
            c.drawBitmap(fx, 0, 0, p);
            fx.recycle();
        }
        for (Item it : items) if (!(it instanceof Item.Sticker)) it.draw(c, w, h);
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas oc = new Canvas(out);
        if (transparent) {
            Paint cp = new Paint();
            int t = Math.max(6, w / 24);
            for (int y = 0; y < h; y += t)
                for (int x = 0; x < w; x += t) {
                    cp.setColor(((x / t + y / t) % 2 == 0) ? 0xFF3A3A3F : 0xFF26262A);
                    oc.drawRect(x, y, x + t, y + t, cp);
                }
        } else {
            oc.drawColor(0xFF17171A);
        }
        oc.drawBitmap(small, 0, 0, null);
        small.recycle();
        java.io.File tmp = new java.io.File(dir, "thumb.tmp");
        try (OutputStream os = new java.io.FileOutputStream(tmp)) { out.compress(Bitmap.CompressFormat.JPEG, 88, os); }
        tmp.renameTo(new java.io.File(dir, "thumb.jpg"));
        out.recycle();
    }

    void openProject(java.io.File dir) {
        saveProject(null);
        exec.execute(() -> {
            try {
                org.json.JSONObject o = new org.json.JSONObject(Projects.readText(new java.io.File(dir, "project.json")));
                boolean isBlank = o.optBoolean("blank");
                float ratio = (float) o.optDouble("ratio", 0.8);
                int color = o.optInt("color", Color.WHITE);
                boolean transp = o.optBoolean("transparent");
                Uri src = null;
                Bitmap b;
                if (isBlank) {
                    canvasRatio = ratio; canvasColor = color; canvasTransparent = transp;
                    b = makeBlank(PREVIEW_MAX);
                } else {
                    src = Uri.fromFile(new java.io.File(dir, "source"));
                    b = decode(src, PREVIEW_MAX, false);
                }
                List<Item> items = Projects.itemsFromJson(dir, o.optJSONArray("items") == null
                        ? new org.json.JSONArray() : o.optJSONArray("items"));
                String fname = o.optString("filter");
                int inten = o.optInt("intensity", 100);
                BaseEdit pe = new BaseEdit();
                pe.rot = o.optInt("rot");
                pe.flip = o.optBoolean("flip");
                pe.cropCircle = o.optBoolean("cropCircle");
                pe.soft = (float) o.optDouble("soft", 0.55);
                pe.grow = (float) o.optDouble("grow", 0.5);
                pe.bg = o.optInt("bg");
                pe.c1 = o.optInt("c1", Color.WHITE);
                pe.c2 = o.optInt("c2", 0xFF7C4DFF);
                pe.blur = (float) o.optDouble("blur", 0.5);
                org.json.JSONArray ca = o.optJSONArray("crop");
                if (ca != null && ca.length() == 4)
                    pe.crop = new RectF((float) ca.optDouble(0), (float) ca.optDouble(1), (float) ca.optDouble(2), (float) ca.optDouble(3));
                if (o.optBoolean("bgRemoved")) {
                    java.io.File mf = new java.io.File(dir, "mask.png");
                    if (mf.exists()) {
                        Bitmap mm = BitmapFactory.decodeFile(mf.getPath());
                        if (mm != null) pe.mask = mm.copy(Bitmap.Config.ARGB_8888, false);
                    }
                }
                if (pe.bg == BaseEdit.BG_PHOTO) {
                    java.io.File bf = new java.io.File(dir, "bg.jpg");
                    pe.bgPhoto = bf.exists() ? BitmapFactory.decodeFile(bf.getPath()) : null;
                    if (pe.bgPhoto == null) pe.bg = BaseEdit.BG_NONE;
                }
                if (pe.mask == null) pe.bg = BaseEdit.BG_NONE;
                final BaseEdit fedit = pe;
                final Uri fsrc = src;
                ui.post(() -> {
                    projectId = dir.getName();
                    blank = isBlank;
                    overlay.items.clear();
                    overlay.items.addAll(items);
                    overlay.selected = null;
                    Filter target = all.get(0);
                    for (Filter f : all) if (f.name.equals(fname)) target = f;
                    if (target != current) {
                        category = "All";
                        refreshChips();
                        buildStrip();
                        select(target);
                    }
                    seek.setProgress(inten);
                    setSource(b, fsrc, fedit);
                    setMode(M_FILTERS);
                    showStart(false);
                });
            } catch (Throwable t) {
                ui.post(() -> toast("Couldn't open that project"));
            }
        });
    }

    View buildStartScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        scroll.setClickable(true);                   // don't let taps fall through to the editor
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(22), dp(28), dp(22), dp(28));
        scroll.addView(col);
        scroll.setOnApplyWindowInsetsListener((v, ins) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(i.left, i.top, i.right, i.bottom);
            } else {
                v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom());
            }
            return ins;
        });

        TextView logo = new TextView(this);
        logo.setText("TINT");
        logo.setTextColor(TEXT);
        logo.setTextSize(38);
        logo.setLetterSpacing(0.3f);
        logo.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        col.addView(logo);
        TextView sub = new TextView(this);
        sub.setText("What do you want to make?");
        sub.setTextColor(DIM);
        sub.setTextSize(14);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
        sp.setMargins(0, dp(4), 0, dp(26));
        col.addView(sub, sp);

        // recent projects
        LinearLayout rb = new LinearLayout(this);
        rb.setOrientation(LinearLayout.VERTICAL);
        TextView rl = new TextView(this);
        rl.setText("Recent");
        rl.setTextColor(TEXT);
        rl.setTextSize(15);
        rl.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        rl.setPadding(dp(4), 0, 0, dp(10));
        rb.addView(rl);
        recentRow = new LinearLayout(this);
        HorizontalScrollView rs = hscroll(recentRow);
        rs.setClipToPadding(false);
        rb.addView(rs, new LinearLayout.LayoutParams(-1, -2));
        TextView rh = new TextView(this);
        rh.setText("Tap to continue editing · hold to delete");
        rh.setTextColor(DIM);
        rh.setTextSize(11);
        rh.setPadding(dp(4), dp(8), 0, 0);
        rb.addView(rh);
        LinearLayout.LayoutParams rbp = new LinearLayout.LayoutParams(-1, -2);
        rbp.bottomMargin = dp(22);
        col.addView(rb, rbp);
        recentBlock = rb;

        // open from gallery
        LinearLayout openCard = new LinearLayout(this);
        openCard.setOrientation(LinearLayout.VERTICAL);
        openCard.setGravity(Gravity.CENTER);
        openCard.setBackground(round(ACCENT, dp(26)));
        openCard.setPadding(dp(20), dp(26), dp(20), dp(26));
        TextView oi = new TextView(this);
        oi.setText("＋");
        oi.setTextColor(Color.WHITE);
        oi.setTextSize(30);
        oi.setGravity(Gravity.CENTER);
        TextView ot = new TextView(this);
        ot.setText("Open a photo");
        ot.setTextColor(Color.WHITE);
        ot.setTextSize(18);
        ot.setGravity(Gravity.CENTER);
        ot.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        TextView os = new TextView(this);
        os.setText("from your gallery");
        os.setTextColor(0xCCFFFFFF);
        os.setTextSize(13);
        os.setGravity(Gravity.CENTER);
        openCard.addView(oi);
        openCard.addView(ot);
        openCard.addView(os);
        openCard.setOnClickListener(v -> pick());
        col.addView(openCard, new LinearLayout.LayoutParams(-1, -2));

        // blank canvas card
        LinearLayout blankCard = new LinearLayout(this);
        blankCard.setOrientation(LinearLayout.VERTICAL);
        blankCard.setGravity(Gravity.CENTER_HORIZONTAL);
        blankCard.setBackground(round(SURFACE, dp(26)));
        blankCard.setPadding(dp(18), dp(20), dp(18), dp(20));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(16);
        col.addView(blankCard, bp);

        TextView bt = new TextView(this);
        bt.setText("Blank canvas");
        bt.setTextColor(TEXT);
        bt.setTextSize(18);
        bt.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        blankCard.addView(bt);

        // preview of the chosen shape + colour
        FrameLayout pv = new FrameLayout(this);
        startPreview = new Views.AspectFrame(this);
        startPreview.setBackground(round(SURFACE2, dp(14)));
        startPreview.setClipToOutline(true);
        View chk = new View(this);
        chk.setBackground(checkerDrawable());
        startPreview.addView(chk, new FrameLayout.LayoutParams(-1, -1));
        startPreviewFill = new View(this);
        startPreview.addView(startPreviewFill, new FrameLayout.LayoutParams(-1, -1));
        pv.addView(startPreview, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        LinearLayout.LayoutParams pvp = new LinearLayout.LayoutParams(-1, dp(150));
        pvp.setMargins(0, dp(16), 0, dp(16));
        blankCard.addView(pv, pvp);

        // shape
        LinearLayout ratios = new LinearLayout(this);
        ratios.setGravity(Gravity.CENTER);
        String[] rn = {"1:1", "4:5", "3:4", "9:16", "16:9"};
        float[] rv = {1f, 0.8f, 0.75f, 9f / 16, 16f / 9};
        for (int i = 0; i < rn.length; i++) {
            final float r = rv[i];
            TextView t = new TextView(this);
            t.setText(rn[i]);
            t.setTextSize(13);
            t.setTag(r);
            t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            t.setPadding(dp(13), dp(6), dp(13), dp(6));
            t.setOnClickListener(v -> { blankRatio = r; refreshStart(); });
            ratios.addView(t);
            startRatios.add(t);
        }
        blankCard.addView(hscroll(ratios));

        // background colours (first one = transparent), in rows of 6 so they always fit
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout rowL = null;
        for (int i = -1; i < CANVAS_COLORS.length; i++) {
            final int idx = i;
            if ((i + 1) % 6 == 0) {
                rowL = new LinearLayout(this);
                rowL.setGravity(Gravity.CENTER);
                grid.addView(rowL);
            }
            View d = new View(this);
            d.setTag(i);
            d.setOnClickListener(v -> {
                blankTransparent = idx < 0;
                if (idx >= 0) blankColor = CANVAS_COLORS[idx];
                refreshStart();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
            lp.setMargins(dp(5), dp(5), dp(5), dp(5));
            rowL.addView(d, lp);
            startSwatches.add(d);
        }
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-2, -2);
        gp.topMargin = dp(10);
        blankCard.addView(grid, gp);

        TextView create = pill("Create canvas", false);
        create.setBackground(round(Color.WHITE, dp(100)));
        create.setTextColor(Color.BLACK);
        create.setPadding(dp(28), dp(12), dp(28), dp(12));
        create.setOnClickListener(v -> {
            saveProject(null);
            overlay.items.clear();
            overlay.selected = null;
            projectId = Projects.newId();
            blank = true;
            canvasRatio = blankRatio;
            canvasColor = blankColor;
            canvasTransparent = blankTransparent;
            setSource(makeBlank(PREVIEW_MAX), null);
            showStart(false);
        });
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
        cp.topMargin = dp(16);
        blankCard.addView(create, cp);

        refreshStart();
        return scroll;
    }

    void refreshStart() {
        startPreview.setRatio(blankRatio);
        startPreviewFill.setBackgroundColor(blankTransparent ? Color.TRANSPARENT : blankColor);
        for (TextView t : startRatios) {
            boolean sel = Math.abs((Float) t.getTag() - blankRatio) < 0.001f;
            t.setBackground(sel ? round(Color.WHITE, dp(100)) : null);
            t.setTextColor(sel ? Color.BLACK : DIM);
        }
        for (View d : startSwatches) {
            int i = (Integer) d.getTag();
            boolean sel = i < 0 ? blankTransparent : (!blankTransparent && CANVAS_COLORS[i] == blankColor);
            if (i < 0) {
                android.graphics.drawable.LayerDrawable ld = new android.graphics.drawable.LayerDrawable(
                        new android.graphics.drawable.Drawable[]{checkerDrawable(), ring(sel)});
                d.setBackground(ld);
                d.setClipToOutline(true);
                d.setOutlineProvider(new ViewOutlineProvider() {
                    @Override public void getOutline(View view, Outline o) { o.setOval(0, 0, view.getWidth(), view.getHeight()); }
                });
            } else {
                GradientDrawable g = new GradientDrawable();
                g.setShape(GradientDrawable.OVAL);
                g.setColor(CANVAS_COLORS[i]);
                g.setStroke(dp(sel ? 3 : 1), sel ? ACCENT : LINE);
                d.setBackground(g);
            }
        }
    }

    GradientDrawable ring(boolean sel) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(Color.TRANSPARENT);
        g.setStroke(dp(sel ? 3 : 1), sel ? ACCENT : LINE);
        return g;
    }

    void refreshChips() {
        for (Map.Entry<String, TextView> e : chips.entrySet()) {
            boolean sel = e.getKey().equals(category);
            e.getValue().setBackground(sel ? round(Color.WHITE, dp(100)) : null);
            e.getValue().setTextColor(sel ? Color.BLACK : DIM);
        }
    }

    List<Filter> visible() {
        List<Filter> l = new ArrayList<>();
        for (Filter f : all)
            if (f.isOriginal() || category.equals("All") || f.cat.equals(category)) l.add(f);
        return l;
    }

    void buildStrip() {
        strip.removeAllViews();
        itemViews.clear();
        for (Filter f : visible()) strip.addView(makeItem(f));
        stripScroll.scrollTo(0, 0);
    }

    View makeItem(Filter f) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(5), 0, dp(5), 0);

        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackground(round(SURFACE, dp(18)));
        iv.setClipToOutline(true);
        Bitmap t = thumbs.get(f);
        iv.setImageBitmap(t != null ? t : thumbSrc);
        col.addView(iv, new LinearLayout.LayoutParams(dp(68), dp(68)));

        TextView name = new TextView(this);
        name.setText(f.name);
        name.setTextSize(10);
        name.setLetterSpacing(0.08f);
        name.setSingleLine(true);
        name.setMaxWidth(dp(76));
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-2, -2);
        nlp.topMargin = dp(7);
        col.addView(name, nlp);

        col.setOnClickListener(v -> select(f));
        itemViews.put(f, col);
        styleItem(col, f == current);
        return col;
    }

    void styleItem(View col, boolean sel) {
        ViewGroup g = (ViewGroup) col;
        ImageView iv = (ImageView) g.getChildAt(0);
        TextView tv = (TextView) g.getChildAt(1);
        if (sel) {
            GradientDrawable ring = new GradientDrawable();
            ring.setCornerRadius(dp(18));
            ring.setStroke(dp(2), ACCENT);
            iv.setForeground(ring);
        } else {
            iv.setForeground(null);
        }
        tv.setTextColor(sel ? TEXT : DIM);
    }

    void select(Filter f) {
        if (f == current) return;
        View old = itemViews.get(current);
        current = f;
        if (old != null) styleItem(old, false);
        View nv = itemViews.get(f);
        if (nv != null) {
            styleItem(nv, true);
            nv.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        }
        tvName.setText(f.name);
        renderPreview();
    }

    // ------------------------------------------------------------------ rendering

    void setSource(Bitmap bmp, Uri uri) { setSource(bmp, uri, null); }

    void setSource(Bitmap bmp, Uri uri, BaseEdit e) {
        previewOrig = bmp;
        edit = e == null ? new BaseEdit() : e;
        photoUri = uri;
        boolean has = uri != null || blank;
        openPill.setVisibility(has ? View.GONE : View.VISIBLE);
        btnSave.setAlpha(has ? 1f : 0.45f);
        showBase(true);
    }

    void showBase() { showBase(false); }

    /** Rebuilds the main photo from the original + edits (in the background), then re-applies the filter. */
    void showBase(boolean thumbsNow) {
        refreshCutControls();
        final int g = ++baseGen;
        final Bitmap src = previewOrig;
        final BaseEdit e = edit.copy();
        exec.execute(() -> {
            if (g != baseGen) return;
            Bitmap b;
            try {
                b = e.isEmpty() ? src : e.compose(src, false);
            } catch (Throwable t) {
                b = src;
            }
            final Bitmap fb = b;
            ui.post(() -> {
                if (g != baseGen) return;
                boolean sameShape = preview != null && preview.getWidth() == fb.getWidth() && preview.getHeight() == fb.getHeight();
                preview = fb;
                stage.setRatio((float) fb.getWidth() / fb.getHeight());
                ivOrig.setImageBitmap(fb);
                if (!sameShape) ivFx.setImageBitmap(null);
                checker.setVisibility(fb.hasAlpha() ? View.VISIBLE : View.GONE);
                thumbSrc = Renderer.thumb(blank && sampleBmp != null ? sampleBmp : fb, dp(68));
                ui.removeCallbacks(regenLater);
                if (thumbsNow) regenThumbs(); else ui.postDelayed(regenLater, 700);
                renderPreview();
            });
        });
    }

    static void cutInPlace(Bitmap b, Bitmap m) {
        b.setHasAlpha(true);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
        p.setBlendMode(BlendMode.DST_IN);
        c.drawBitmap(m, null, new Rect(0, 0, b.getWidth(), b.getHeight()), p);
    }

    // ------------------------------------------------------------------ Cut tab

    View labeled(String label, View v) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(22), 0, 0, 0);
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(DIM);
        t.setTextSize(12);
        row.addView(t, new LinearLayout.LayoutParams(dp(92), -2));
        v.setPadding(dp(8), dp(10), dp(24), dp(10));
        row.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
        return row;
    }

    View buildCutPanel() {
        cutPanel = new LinearLayout(this);
        cutPanel.setOrientation(LinearLayout.VERTICAL);

        LinearLayout row = new LinearLayout(this);
        row.setPadding(dp(14), dp(2), dp(14), dp(4));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(3), 0, dp(3), 0);
        btnBg = action("✂  Remove background");
        btnBg.setBackground(round(ACCENT, dp(100)));
        btnBg.setTextColor(Color.WHITE);
        btnBg.setOnClickListener(v -> toggleMainBackground());
        btnBrush = action("🖌  Erase / Restore");
        btnBrush.setOnClickListener(v -> openRefine());
        TextView crop = action("⌗  Crop");
        crop.setOnClickListener(v -> openMainCrop());
        TextView rotate = action("⟳  Rotate");
        rotate.setOnClickListener(v -> {
            edit.rot = (edit.rot + 1) % 4;
            edit.crop = null;
            edit.cropCircle = false;
            showBase();
        });
        TextView flip = action("⇋  Flip");
        flip.setOnClickListener(v -> {
            edit.flip = !edit.flip;
            if (edit.crop != null) edit.crop = new RectF(1 - edit.crop.right, edit.crop.top, 1 - edit.crop.left, edit.crop.bottom);
            showBase();
        });
        TextView reset = action("↺  Reset");
        reset.setOnClickListener(v -> {
            edit = new BaseEdit();
            showBase();
        });
        row.addView(btnBg, lp);
        row.addView(btnBrush, lp);
        row.addView(crop, lp);
        row.addView(rotate, lp);
        row.addView(flip, lp);
        row.addView(reset, lp);
        cutPanel.addView(hscroll(row));

        // edge controls (after a cut-out)
        maskTools = new LinearLayout(this);
        maskTools.setOrientation(LinearLayout.VERTICAL);
        softSeek = slider(100, 55);
        onSlide(softSeek, p -> { if (!syncingCut) { edit.soft = p / 100f; showBase(); } });
        growSeek = slider(100, 50);
        onSlide(growSeek, p -> { if (!syncingCut) { edit.grow = p / 100f; showBase(); } });
        maskTools.addView(labeled("Edge softness", softSeek));
        maskTools.addView(labeled("Shrink ↔ Grow", growSeek));
        cutPanel.addView(maskTools);

        // new background
        bgTools = new LinearLayout(this);
        bgTools.setOrientation(LinearLayout.VERTICAL);
        LinearLayout sw = new LinearLayout(this);
        sw.setGravity(Gravity.CENTER_VERTICAL);
        sw.setPadding(dp(16), dp(4), dp(16), dp(4));
        addBgSwatch(sw, "none", BaseEdit.BG_NONE, 0, 0);
        addBgSwatch(sw, "Blur", BaseEdit.BG_BLUR, 0, 0);
        addBgSwatch(sw, "Photo", BaseEdit.BG_PHOTO, 0, 0);
        for (int[] g : BaseEdit.GRADIENTS) addBgSwatch(sw, null, BaseEdit.BG_GRADIENT, g[0], g[1]);
        for (int c : CANVAS_COLORS) addBgSwatch(sw, null, BaseEdit.BG_COLOR, c, c);
        TextView bl = new TextView(this);
        bl.setText("New background");
        bl.setTextColor(DIM);
        bl.setTextSize(12);
        bl.setPadding(dp(22), dp(4), 0, 0);
        bgTools.addView(bl);
        bgTools.addView(hscroll(sw));
        blurSeek = slider(100, 50);
        onSlide(blurSeek, p -> { if (!syncingCut) { edit.blur = p / 100f; showBase(); } });
        blurRow = (LinearLayout) labeled("Blur amount", blurSeek);
        bgTools.addView(blurRow);
        cutPanel.addView(bgTools);
        return cutPanel;
    }

    void addBgSwatch(LinearLayout parent, String label, int type, int c1, int c2) {
        TextView d = new TextView(this);
        d.setGravity(Gravity.CENTER);
        d.setTextSize(9);
        d.setTextColor(TEXT);
        if (label != null && !label.equals("none")) d.setText(label);
        d.setTag(new int[]{type, c1, c2});
        d.setOnClickListener(v -> {
            if (type == BaseEdit.BG_PHOTO) { pick(REQ_BGPHOTO); return; }
            edit.bg = type;
            if (type == BaseEdit.BG_COLOR || type == BaseEdit.BG_GRADIENT) { edit.c1 = c1; edit.c2 = c2; }
            v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            showBase();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(38), dp(38));
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        parent.addView(d, lp);
        bgSwatches.add(d);
    }

    void refreshCutControls() {
        if (cutPanel == null) return;
        boolean photo = photoUri != null;
        boolean cutout = edit.mask != null;
        btnBg.setVisibility(photo ? View.VISIBLE : View.GONE);
        btnBrush.setVisibility(photo ? View.VISIBLE : View.GONE);
        btnBg.setText(maskBusy ? "✂  Removing…" : cutout ? "↺  Restore background" : "✂  Remove background");
        btnBg.setAlpha(maskBusy ? 0.6f : 1f);
        maskTools.setVisibility(cutout ? View.VISIBLE : View.GONE);
        bgTools.setVisibility(cutout ? View.VISIBLE : View.GONE);
        blurRow.setVisibility(cutout && edit.bg == BaseEdit.BG_BLUR ? View.VISIBLE : View.GONE);
        syncingCut = true;
        softSeek.setProgress(Math.round(edit.soft * 100));
        growSeek.setProgress(Math.round(edit.grow * 100));
        blurSeek.setProgress(Math.round(edit.blur * 100));
        syncingCut = false;
        for (View v : bgSwatches) {
            int[] t = (int[]) v.getTag();
            boolean sel = edit.bg == t[0] && (t[0] == BaseEdit.BG_NONE || t[0] == BaseEdit.BG_BLUR || t[0] == BaseEdit.BG_PHOTO
                    || (edit.c1 == t[1] && edit.c2 == t[2]));
            int stroke = dp(sel ? 3 : 1), sc = sel ? ACCENT : LINE;
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setStroke(stroke, sc);
            if (t[0] == BaseEdit.BG_NONE) {
                v.setBackground(new android.graphics.drawable.LayerDrawable(
                        new android.graphics.drawable.Drawable[]{checkerDrawable(), g}));
                v.setClipToOutline(true);
                v.setOutlineProvider(new ViewOutlineProvider() {
                    @Override public void getOutline(View view, Outline o) { o.setOval(0, 0, view.getWidth(), view.getHeight()); }
                });
                continue;
            }
            if (t[0] == BaseEdit.BG_GRADIENT) {
                g.setColors(new int[]{t[1], t[2]});
                g.setOrientation(GradientDrawable.Orientation.TL_BR);
            } else if (t[0] == BaseEdit.BG_COLOR) {
                g.setColor(t[1]);
            } else {
                g.setColor(SURFACE2);
            }
            v.setBackground(g);
        }
    }

    void loadBgPhoto(Uri u) {
        exec.execute(() -> {
            try {
                Bitmap b = decode(u, 3072, false);
                ui.post(() -> {
                    edit.bgPhoto = b;
                    edit.bgVer++;
                    edit.bg = BaseEdit.BG_PHOTO;
                    showBase();
                });
            } catch (Throwable t) {
                ui.post(() -> toast("Couldn't open that photo"));
            }
        });
    }

    void openMainCrop() {
        BaseEdit e = edit.copy();
        e.crop = null;
        e.cropCircle = false;
        final Bitmap full = e.isEmpty() ? previewOrig : e.compose(previewOrig, false);
        openCropFor(full, (r, circle) -> {
            RectF oc = edit.crop != null ? edit.crop : new RectF(0, 0, 1, 1);
            RectF nc = new RectF((float) r.left / full.getWidth(), (float) r.top / full.getHeight(),
                    (float) r.right / full.getWidth(), (float) r.bottom / full.getHeight());
            for (Item it : overlay.items) {               // keep text and pictures where they were
                float px = oc.left + it.x * oc.width(), py = oc.top + it.y * oc.height();
                it.x = (px - nc.left) / nc.width();
                it.y = (py - nc.top) / nc.height();
                it.size *= oc.width() / nc.width();
            }
            boolean whole = nc.left < 0.002f && nc.top < 0.002f && nc.right > 0.998f && nc.bottom > 0.998f;
            edit.crop = whole && !circle ? null : nc;
            edit.cropCircle = circle;
            overlay.invalidate();
            showBase();
        });
    }

    void openRefine() {
        if (photoUri == null) return;
        Bitmap working;
        if (edit.mask != null) {
            working = edit.mask.copy(Bitmap.Config.ARGB_8888, true);
        } else {
            working = Bitmap.createBitmap(previewOrig.getWidth(), previewOrig.getHeight(), Bitmap.Config.ARGB_8888);
            working.eraseColor(0xFF000000);
        }
        android.app.Dialog dlg = new android.app.Dialog(this, android.R.style.Theme_Material_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(i.left, i.top, i.right, i.bottom + dp(10));
            } else {
                v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom() + dp(10));
            }
            return ins;
        });

        Views.MaskBrushView bv = new Views.MaskBrushView(this, previewOrig, working, edit, checkerDrawable());

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(10), dp(14), dp(10));
        TextView cancel = pill("Cancel", false);
        cancel.setOnClickListener(v -> dlg.dismiss());
        TextView title = new TextView(this);
        title.setText("Erase / Restore");
        title.setTextColor(TEXT);
        title.setTextSize(16);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        TextView ok = pill("Done", true);
        ok.setOnClickListener(v -> {
            edit.mask = working;
            edit.maskVer++;
            dlg.dismiss();
            showBase();
        });
        bar.addView(cancel);
        bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        bar.addView(ok);
        root.addView(bar);
        root.addView(bv, new LinearLayout.LayoutParams(-1, 0, 1f));

        TextView tip = new TextView(this);
        tip.setText("One finger paints · two fingers zoom and move");
        tip.setTextColor(DIM);
        tip.setTextSize(12);
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(0, dp(8), 0, dp(4));
        root.addView(tip);

        LinearLayout tools = new LinearLayout(this);
        tools.setGravity(Gravity.CENTER);
        tools.setPadding(dp(14), dp(4), dp(14), dp(4));
        TextView erase = action("Erase");
        TextView restore = action("Restore");
        TextView undo = action("↶  Undo");
        Runnable sync = () -> {
            erase.setBackground(round(bv.restore ? SURFACE : Color.WHITE, dp(100)));
            erase.setTextColor(bv.restore ? TEXT : Color.BLACK);
            restore.setBackground(round(bv.restore ? Color.WHITE : SURFACE, dp(100)));
            restore.setTextColor(bv.restore ? Color.BLACK : TEXT);
            undo.setAlpha(bv.undo.isEmpty() ? 0.4f : 1f);
        };
        bv.onUndoChanged = sync;
        erase.setOnClickListener(v -> { bv.restore = false; sync.run(); });
        restore.setOnClickListener(v -> { bv.restore = true; sync.run(); });
        undo.setOnClickListener(v -> bv.undo());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(4), 0, dp(4), 0);
        tools.addView(erase, lp);
        tools.addView(restore, lp);
        tools.addView(undo, lp);
        root.addView(tools);
        SeekBar size = slider(100, 30);
        onSlide(size, p -> bv.brushDp = 10 + p * 0.9f);
        root.addView(labeled("Brush size", size));
        sync.run();

        dlg.setContentView(root);
        Window w = dlg.getWindow();
        if (w != null) {
            w.setStatusBarColor(Color.TRANSPARENT);
            w.setNavigationBarColor(Color.TRANSPARENT);
            if (Build.VERSION.SDK_INT >= 30) w.setDecorFitsSystemWindows(false);
        }
        dlg.show();
    }

    void toggleMainBackground() {
        if (photoUri == null || maskBusy) return;
        if (edit.mask != null) {
            edit.mask = null;
            edit.maskVer++;
            edit.bg = BaseEdit.BG_NONE;
            showBase();
            return;
        }
        if (maskSegmenter == null) {
            maskSegmenter = SubjectSegmentation.getClient(new SubjectSegmenterOptions.Builder()
                    .enableForegroundConfidenceMask()
                    .build());
        }
        maskBusy = true;
        refreshCutControls();
        final Bitmap src = previewOrig;
        maskSegmenter.process(InputImage.fromBitmap(src, 0))
                .addOnSuccessListener(result -> {
                    java.nio.FloatBuffer fb = result.getForegroundConfidenceMask();
                    if (fb == null) {
                        maskBusy = false;
                        refreshCutControls();
                        toast("Couldn't find a subject in this photo");
                        return;
                    }
                    int w = src.getWidth(), h = src.getHeight();
                    exec.execute(() -> {
                        int[] px = new int[w * h];
                        fb.rewind();
                        boolean any = false;
                        for (int i = 0; i < px.length && fb.hasRemaining(); i++) {
                            int a = Math.round(Math.max(0f, Math.min(1f, fb.get())) * 255);
                            if (a > 40) any = true;
                            px[i] = a << 24;
                        }
                        Bitmap m = null;
                        if (any) {
                            m = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                            m.setPixels(px, 0, w, 0, 0, w, h);
                        }
                        final Bitmap fm = m;
                        ui.post(() -> {
                            maskBusy = false;
                            if (fm == null) toast("Couldn't find a subject in this photo");
                            else if (src == previewOrig) {
                                edit.mask = fm;
                                edit.maskVer++;
                                btnBg.performHapticFeedback(Build.VERSION.SDK_INT >= 30
                                        ? HapticFeedbackConstants.CONFIRM : HapticFeedbackConstants.LONG_PRESS);
                            }
                            showBase();
                        });
                    });
                })
                .addOnFailureListener(e -> {
                    maskBusy = false;
                    refreshCutControls();
                    String msg = String.valueOf(e.getMessage()).toLowerCase(Locale.US);
                    toast(msg.contains("download") || msg.contains("waiting")
                            ? "Getting the background tool ready (needs internet once). Try again in a minute."
                            : "Couldn't remove the background");
                });
    }

    /**
     * Pictures added on top are painted into the photo first, so the filter applies to them too.
     * The picture being edited in the Photo tab stays "live" on the overlay (with a quick filter preview)
     * so moving it is smooth; it is baked in as soon as it is deselected.
     */
    void renderPreview() {
        if (preview == null) return;
        final int g = ++gen;
        final Bitmap src = preview;
        final Filter f = current;
        final List<Item> bakeOriginals = new ArrayList<>();
        final List<Item> bakeCopies = new ArrayList<>();
        for (Item it : overlay.items) {
            if (!(it instanceof Item.Sticker)) continue;
            boolean live = mode == M_PHOTO && it == overlay.selected;
            if (!live) { bakeOriginals.add(it); bakeCopies.add(it.copy()); }
        }
        overlay.liveFilter = f.isOriginal() ? null : new ColorMatrixColorFilter(Renderer.matrix(f));
        overlay.liveK = intensity / 100f;
        exec.execute(() -> {
            if (g != gen) return;
            Bitmap base = src;
            if (!bakeCopies.isEmpty()) {
                base = src.copy(Bitmap.Config.ARGB_8888, true);
                Canvas c = new Canvas(base);
                for (Item it : bakeCopies) it.draw(c, base.getWidth(), base.getHeight());
            }
            Bitmap out = f.isOriginal() ? null : Renderer.render(base, f);
            final Bitmap b = base;
            ui.post(() -> {
                if (g != gen) return;
                ivOrig.setImageBitmap(b);
                ivFx.setImageBitmap(out);
                for (Item it : overlay.items) it.baked = bakeOriginals.contains(it);
                overlay.invalidate();
            });
        });
    }

    void regenThumbs() {
        final int tg = ++thumbGen;
        final Bitmap ts = thumbSrc;
        thumbs.clear();
        for (View v : itemViews.values())
            ((ImageView) ((ViewGroup) v).getChildAt(0)).setImageBitmap(ts);
        final List<Filter> order = new ArrayList<>(visible());
        for (Filter f : all) if (!order.contains(f)) order.add(f);
        thumbExec.execute(() -> {
            for (Filter f : order) {
                if (tg != thumbGen) return;
                Bitmap t = f.isOriginal() ? ts : Renderer.render(ts, f);
                ui.post(() -> {
                    if (tg != thumbGen) return;
                    thumbs.put(f, t);
                    View v = itemViews.get(f);
                    if (v != null) ((ImageView) ((ViewGroup) v).getChildAt(0)).setImageBitmap(t);
                });
            }
        });
    }

    // ------------------------------------------------------------------ open / save

    void pick() { pick(REQ_PICK); }

    void pick(int req) {
        Intent i;
        if (Build.VERSION.SDK_INT >= 33) {
            i = new Intent(MediaStore.ACTION_PICK_IMAGES);
            i.setType("image/*");
        } else {
            i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
        }
        try {
            startActivityForResult(i, req);
        } catch (Exception e) {
            Intent g = new Intent(Intent.ACTION_GET_CONTENT);
            g.setType("image/*");
            startActivityForResult(g, req);
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        if (req == REQ_PICK) loadUri(data.getData());
        else if (req == REQ_STICKER) loadSticker(data.getData());
        else if (req == REQ_BGPHOTO) loadBgPhoto(data.getData());
    }

    boolean handleIncoming(Intent in) {
        if (in == null) return false;
        String act = in.getAction();
        Uri u = null;
        if (Intent.ACTION_SEND.equals(act)) u = in.getParcelableExtra(Intent.EXTRA_STREAM);
        else if (Intent.ACTION_EDIT.equals(act) || Intent.ACTION_VIEW.equals(act)) u = in.getData();
        if (u != null) loadUri(u);
        return u != null;
    }

    /** maxSide <= 0 means full original resolution. */
    Bitmap decode(Uri u, int maxSide, boolean mutable) throws IOException {
        ImageDecoder.Source s = ImageDecoder.createSource(getContentResolver(), u);
        return ImageDecoder.decodeBitmap(s, (dec, info, src) -> {
            dec.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            dec.setMutableRequired(mutable);
            if (maxSide > 0) {
                int w = info.getSize().getWidth(), h = info.getSize().getHeight();
                float sc = Math.min(1f, (float) maxSide / Math.max(w, h));
                if (sc < 1f) dec.setTargetSize(Math.max(1, Math.round(w * sc)), Math.max(1, Math.round(h * sc)));
            }
        });
    }

    void loadUri(Uri u) {
        saveProject(null);
        exec.execute(() -> {
            String id = Projects.newId();
            Uri src = u;
            try {                                   // keep an exact copy so the project can be reopened later
                java.io.File f = new java.io.File(Projects.dir(this, id), "source");
                Projects.copy(getContentResolver().openInputStream(u), f);
                src = Uri.fromFile(f);
            } catch (Throwable ignored) { }
            final Uri fsrc = src;
            try {
                Bitmap b = decode(fsrc, PREVIEW_MAX, false);
                ui.post(() -> {
                    projectId = id;
                    blank = false;
                    overlay.items.clear();
                    overlay.selected = null;
                    setSource(b, fsrc);
                    setMode(M_FILTERS);
                    showStart(false);
                });
            } catch (Throwable t) {
                Projects.delete(Projects.dir(this, id));
                ui.post(() -> toast("Couldn't open that photo"));
            }
        });
    }

    void save() {
        if (photoUri == null && !blank) { showStart(true); return; }
        if (saving) return;
        saveProject(null);
        saving = true;
        btnSave.setText("Saving…");
        final Uri u = photoUri;
        final Filter f = current;
        final float k = intensity / 100f;
        final BaseEdit be = edit.copy();
        final List<Item> texts = new ArrayList<>();
        for (Item it : overlay.items)
            if (!(it instanceof TextArt.Layer) || !((TextArt.Layer) it).text.trim().isEmpty()) texts.add(it.copy());

        exec.execute(() -> {
            String msg = "Saved to Pictures/Tint";
            Bitmap src = null;
            try {
                if (u == null) {
                    src = makeBlank(3840);                         // blank canvas at high resolution
                } else try {
                    src = decode(u, 0, true);                     // full original resolution
                } catch (OutOfMemoryError oom) {
                    System.gc();
                    src = decode(u, 6000, true);
                    msg = "Saved (reduced size — photo was very large)";
                }
                if (Build.VERSION.SDK_INT >= 34 && src.hasGainmap() && (!f.isOriginal() || !texts.isEmpty() || !be.isEmpty()))
                    src.setGainmap(null);
                if (!be.isEmpty()) {                                // cut-out, new background, rotate, crop
                    src = be.compose(src, true);
                    if (!src.isMutable()) src = src.copy(Bitmap.Config.ARGB_8888, true);
                }
                Canvas c = new Canvas(src);
                for (Item it : texts)                         // pictures first: they get the filter too
                    if (it instanceof Item.Sticker) it.draw(c, src.getWidth(), src.getHeight());
                if (!f.isOriginal() && k > 0) Renderer.applyFull(src, f, k);
                for (Item it : texts)                         // text stays crisp on top
                    if (!(it instanceof Item.Sticker)) it.draw(c, src.getWidth(), src.getHeight());
                writeToGallery(src, u);
            } catch (OutOfMemoryError e) {
                msg = "Photo too large to save";
            } catch (Throwable t) {
                msg = "Couldn't save";
            }
            if (src != null) src.recycle();
            final String m = msg;
            ui.post(() -> {
                saving = false;
                btnSave.setText("Save");
                toast(m);
                if (m.startsWith("Saved")) btnSave.performHapticFeedback(Build.VERSION.SDK_INT >= 30
                        ? HapticFeedbackConstants.CONFIRM : HapticFeedbackConstants.LONG_PRESS);
            });
        });
    }

    static final String[] EXIF_TAGS = {
            ExifInterface.TAG_MAKE, ExifInterface.TAG_MODEL, ExifInterface.TAG_F_NUMBER,
            ExifInterface.TAG_EXPOSURE_TIME, ExifInterface.TAG_ISO_SPEED_RATINGS, ExifInterface.TAG_FOCAL_LENGTH,
            ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, ExifInterface.TAG_WHITE_BALANCE, ExifInterface.TAG_FLASH,
            ExifInterface.TAG_EXPOSURE_BIAS_VALUE};

    void writeToGallery(Bitmap b, Uri source) throws IOException {
        ContentResolver cr = getContentResolver();
        ContentValues cv = new ContentValues();
        boolean png = b.hasAlpha();                      // keep transparency
        String name = "TINT_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + (png ? ".png" : ".jpg");
        cv.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        cv.put(MediaStore.Images.Media.MIME_TYPE, png ? "image/png" : "image/jpeg");
        cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Tint");
        cv.put(MediaStore.Images.Media.IS_PENDING, 1);
        Uri out = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
        if (out == null) throw new IOException("insert failed");
        try (OutputStream os = cr.openOutputStream(out)) {
            if (os == null || !b.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, png ? 100 : 98, os)) throw new IOException("write failed");
        } catch (IOException e) {
            cr.delete(out, null, null);
            throw e;
        }
        if (source != null && !png) copyExif(source, out);
        cv.clear();
        cv.put(MediaStore.Images.Media.IS_PENDING, 0);
        cr.update(out, cv, null, null);
    }

    /** Keeps the camera details (phone model, lens, exposure…) of the original photo. */
    void copyExif(Uri from, Uri to) {
        try (InputStream in = getContentResolver().openInputStream(from)) {
            if (in == null) return;
            ExifInterface src = new ExifInterface(in);
            try (ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(to, "rw")) {
                if (pfd == null) return;
                ExifInterface dst = new ExifInterface(pfd.getFileDescriptor());
                for (String tag : EXIF_TAGS) {
                    String v = src.getAttribute(tag);
                    if (v != null) dst.setAttribute(tag, v);
                }
                dst.setAttribute(ExifInterface.TAG_SOFTWARE, "Tint");
                dst.setAttribute(ExifInterface.TAG_ORIENTATION, String.valueOf(ExifInterface.ORIENTATION_NORMAL));
                dst.saveAttributes();
            }
        } catch (Throwable ignored) {
            // metadata is a bonus; the photo is already saved
        }
    }
}
