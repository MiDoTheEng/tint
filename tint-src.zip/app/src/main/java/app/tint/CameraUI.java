package app.tint;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.*;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Size;
import android.view.*;
import android.widget.*;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * In-app camera with the filter shown live on the preview (Android's own Camera2, no libraries).
 * Swipe the preview to change filter; the shutter saves the filtered photo and opens it in the editor.
 */
final class CameraUI {
    static final int REQ_CAMERA = 77;

    final MainActivity a;
    FrameLayout root;
    android.opengl.GLSurfaceView gl;
    CameraGL glr;
    SurfaceTexture st;
    Views.AspectFrame frame;
    TextView nameFlash, torchBtn, hdrBtn, procView;
    LinearLayout lensRow;
    boolean hdr = true, night;
    TextView modePhoto, modeNight;
    LinearLayout filterRow, catRow;
    HorizontalScrollView filterScroll;
    View flashCover;

    CameraDevice dev;
    CameraCaptureSession ses;
    ImageReader reader;
    HandlerThread thread;
    Handler bg;
    Size pSize, jSize;
    int sensorOrient;
    boolean front, torch, shown, capturing;
    int deviceDeg;
    OrientationEventListener orient;

    Filter filter;
    String cat = "All";
    final List<TextView> chips = new ArrayList<>();
    final List<TextView> catChips = new ArrayList<>();

    CameraUI(MainActivity a) { this.a = a; }

    int dp(float v) { return a.dp(v); }

    // ------------------------------------------------------------------ layout

    View build() {
        root = new FrameLayout(a);
        root.setBackgroundColor(Color.BLACK);
        root.setClickable(true);
        root.setVisibility(View.GONE);

        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
        col.setOnApplyWindowInsetsListener((v, ins) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(i.left, i.top, i.right, i.bottom + dp(8));
            } else {
                v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom() + dp(8));
            }
            return ins;
        });

        // top bar
        LinearLayout top = new LinearLayout(a);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(4), dp(12), dp(8));
        GradientDrawable tg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x66000000, 0x00000000});
        top.setBackground(null);                 // clean edge-to-edge picture
        TextView close = roundBtn("✕");
        close.setOnClickListener(v -> close());
        top.addView(close);
        top.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
        hdrBtn = new TextView(a);
        hdrBtn.setText("HDR+");
        hdrBtn.setTextSize(12);
        hdrBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        hdrBtn.setGravity(Gravity.CENTER);
        hdrBtn.setPadding(dp(14), dp(8), dp(14), dp(8));
        hdrBtn.setOnClickListener(v -> {
            hdr = !hdr;
            try { a.getSharedPreferences("tint", Context.MODE_PRIVATE).edit().putBoolean("hdr", hdr).apply(); } catch (Throwable ignored) { }
            refreshHdr();
        setNightSilently();
            a.toast(hdr ? "HDR+ on: clearer, more detailed photos" : "HDR+ off: faster single shots");
        });
        LinearLayout.LayoutParams hbp = new LinearLayout.LayoutParams(-2, -2);
        hbp.setMargins(0, 0, dp(10), 0);
        top.addView(hdrBtn, hbp);

        torchBtn = roundBtn("⚡");
        torchBtn.setLayoutParams(new LinearLayout.LayoutParams(-2, dp(40)));
        torchBtn.setTextSize(12.5f);
        torchBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        torchBtn.setPadding(dp(14), 0, dp(14), 0);
        torchBtn.setOnClickListener(v -> {
            if (video) torch = !torch;                       // video: steady light
            else flashMode = (flashMode + 1) % 3;           // photos: off → auto → on
            frame.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            refreshTorch();
            restartPreview();
        });
        top.addView(torchBtn);
        col.addView(top);

        // preview
        FrameLayout holder = new FrameLayout(a);
        frame = new Views.AspectFrame(a);
        frame.setRatio(9f / 16f);
        frame.fill = true;
        frame.setBackgroundColor(0xFF111114);
        gl = new android.opengl.GLSurfaceView(a);
        gl.setEGLContextClientVersion(3);
        gl.setPreserveEGLContextOnPause(true);
        glr = new CameraGL(gl, s -> {
            boolean changed = st != null && st != s;
            st = s;
            if (!shown) return;
            if (changed && dev != null) restartCamera();      // GPU surface was recreated: reconnect the camera
            else if (dev == null && thread != null) openCamera();
        });
        gl.setEGLConfigChooser((egl, display) -> {        // a "recordable" config so video can be encoded from it
            int[][] tries = {
                    {0x3024, 8, 0x3023, 8, 0x3022, 8, 0x3021, 8, 0x3040, 0x40, 0x3142, 1, 0x3038},
                    {0x3024, 8, 0x3023, 8, 0x3022, 8, 0x3040, 0x4, 0x3142, 1, 0x3038},
                    {0x3024, 8, 0x3023, 8, 0x3022, 8, 0x3040, 0x4, 0x3038}};
            for (int[] at : tries) {
                javax.microedition.khronos.egl.EGLConfig[] c = new javax.microedition.khronos.egl.EGLConfig[1];
                int[] n = new int[1];
                if (egl.eglChooseConfig(display, at, c, 1, n) && n[0] > 0) return c[0];
            }
            return null;
        });
        gl.setRenderer(glr);
        gl.setRenderMode(android.opengl.GLSurfaceView.RENDERMODE_WHEN_DIRTY);
        frame.addView(gl, new FrameLayout.LayoutParams(-1, -1));
        blurView = new ImageView(a);
        blurView.setScaleType(ImageView.ScaleType.FIT_XY);
        blurView.setVisibility(View.GONE);
        if (Build.VERSION.SDK_INT >= 31)
            blurView.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(dp(14), dp(14), Shader.TileMode.CLAMP));
        frame.addView(blurView, new FrameLayout.LayoutParams(-1, -1));
        nameFlash = new TextView(a);
        nameFlash.setTextColor(Color.WHITE);
        nameFlash.setTextSize(22);
        nameFlash.setLetterSpacing(0.12f);
        nameFlash.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        nameFlash.setShadowLayer(dp(8), 0, 0, 0xAA000000);
        nameFlash.setAlpha(0);
        frame.addView(nameFlash, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        flashCover = new View(a);
        flashCover.setBackgroundColor(Color.WHITE);
        flashCover.setAlpha(0);
        frame.addView(flashCover, new FrameLayout.LayoutParams(-1, -1));
        lensRow = new LinearLayout(a);
        lensRow.setGravity(Gravity.CENTER);
        lensRow.setPadding(dp(6), dp(4), dp(6), dp(4));
        lensRow.setBackground(a.round(0x40000000, dp(100)));
        FrameLayout.LayoutParams lrp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        lrp.bottomMargin = dp(14);
        // (lens buttons float above the bottom controls, added below)
        procView = new TextView(a);
        procView.setText("HDR+ · hold still…");
        procView.setTextColor(Color.WHITE);
        procView.setTextSize(13);
        procView.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        procView.setPadding(dp(16), dp(8), dp(16), dp(8));
        procView.setBackground(a.round(0xB3000000, dp(100)));
        procView.setVisibility(View.GONE);
        FrameLayout.LayoutParams pvp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        pvp.topMargin = dp(104);
        frame.addView(procView, pvp);
        focusBox = new LinearLayout(a);
        focusBox.setOrientation(LinearLayout.VERTICAL);
        focusBox.setGravity(Gravity.CENTER_HORIZONTAL);
        View ringV = new View(a);
        GradientDrawable rg = new GradientDrawable();          // square focus box
        rg.setShape(GradientDrawable.RECTANGLE);
        rg.setCornerRadius(dp(3));
        rg.setStroke(dp(2), 0xFFFFC93B);
        ringV.setBackground(rg);
        focusBox.addView(ringV, new LinearLayout.LayoutParams(dp(70), dp(70)));
        TextView fl = new TextView(a);
        fl.setText("AE/AF LOCK");
        fl.setTextSize(10);
        fl.setLetterSpacing(0.1f);
        fl.setTextColor(0xFFFFC93B);
        fl.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        fl.setShadowLayer(dp(3), 0, 0, 0xAA000000);
        fl.setPadding(0, dp(4), 0, 0);
        focusBox.addView(fl);
        focusBox.setVisibility(View.GONE);
        frame.addView(focusBox, new FrameLayout.LayoutParams(dp(120), -2));
        recTime = new TextView(a);
        recTime.setTextColor(Color.WHITE);
        recTime.setTextSize(14);
        recTime.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        recTime.setPadding(dp(14), dp(6), dp(14), dp(6));
        recTime.setBackground(a.round(0xCCE53935, dp(100)));
        recTime.setVisibility(View.GONE);
        FrameLayout.LayoutParams rtp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        rtp.topMargin = dp(104);
        frame.addView(recTime, rtp);
        countView = new TextView(a);
        countView.setTextColor(Color.WHITE);
        countView.setTextSize(110);
        countView.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        countView.setShadowLayer(dp(12), 0, 0, 0xAA000000);
        countView.setVisibility(View.GONE);
        frame.addView(countView, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        holder.addView(frame, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, 0, 1f);
        hp.setMargins(dp(6), 0, dp(6), dp(8));
        root.addView(holder, 0, new FrameLayout.LayoutParams(-1, -1));   // preview fills the whole screen
        col.addView(new View(a), hp);                                    // empty: touches reach the preview
        lrp = new FrameLayout.LayoutParams(-2, -2);
        LinearLayout.LayoutParams lensLp = new LinearLayout.LayoutParams(-2, -2);
        lensLp.gravity = Gravity.CENTER_HORIZONTAL;
        lensLp.bottomMargin = dp(10);
        FrameLayout zoomBox = new FrameLayout(a);
        dial = new ZoomDial();
        dial.setVisibility(View.GONE);
        zoomBox.addView(dial, new FrameLayout.LayoutParams(-1, dp(170), Gravity.BOTTOM));
        FrameLayout.LayoutParams lbp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        lbp.bottomMargin = dp(10);
        zoomBox.addView(lensRow, lbp);
        col.addView(zoomBox, new LinearLayout.LayoutParams(-1, -2));

        GestureDetector swipe = new GestureDetector(a, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public void onLongPress(MotionEvent e) { focusAt(e.getX(), e.getY()); }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                if (counting) { cancelCountdown(); return true; }
                if (focusRect != null) clearFocus();
                return true;
            }
            @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (Math.abs(vx) > Math.abs(vy) && Math.abs(vx) > 400) { step(vx < 0 ? 1 : -1); return true; }
                return false;
            }
        });
        ScaleGestureDetector zoomer = new ScaleGestureDetector(a, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) { pinch(d.getScaleFactor()); return true; }
            @Override public void onScaleEnd(ScaleGestureDetector d) { pinchEnd(); }
        });
        frame.setOnTouchListener((v, e) -> {
            zoomer.onTouchEvent(e);
            if (!zoomer.isInProgress() && e.getPointerCount() == 1) swipe.onTouchEvent(e);
            return true;
        });

        // categories
        catRow = new LinearLayout(a);
        catRow.setPadding(dp(12), 0, dp(12), dp(4));
        for (String c : Filters.CATEGORIES) {
            TextView t = new TextView(a);
            t.setText(c);
            t.setTextSize(12);
            t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            t.setPadding(dp(12), dp(5), dp(12), dp(5));
            t.setTag(c);
            t.setOnClickListener(v -> { cat = c; buildFilterRow(); });
            catRow.addView(t);
            catChips.add(t);
        }
        // (the camera shows Pro Filters only, so no category chips)

        // filters
        filterRow = new LinearLayout(a);
        filterRow.setPadding(dp(12), dp(4), dp(12), dp(4));
        filterScroll = a.hscroll(filterRow);
        LinearLayout bottomBar = new LinearLayout(a);
        bottomBar.setOrientation(LinearLayout.VERTICAL);
        bottomBar.setBackground(null);
        bottomBar.setPadding(0, dp(10), 0, 0);
        col.addView(bottomBar);
        bottomBar.addView(filterScroll);

        // shutter row
        LinearLayout shut = new LinearLayout(a);
        shut.setGravity(Gravity.CENTER_VERTICAL);
        shut.setPadding(dp(30), dp(10), dp(30), dp(6));
        lastShot = new ImageView(a);
        lastShot.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable lsb = new GradientDrawable();
        lsb.setShape(GradientDrawable.OVAL);
        lsb.setColor(0x22FFFFFF);
        lsb.setStroke(dp(2), Color.WHITE);
        lastShot.setBackground(lsb);
        lastShot.setClipToOutline(true);
        lastShot.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View view, Outline o) { o.setOval(0, 0, view.getWidth(), view.getHeight()); }
        });
        lastShot.setForeground(lsb);
        lastShot.setVisibility(View.INVISIBLE);
        lastShot.setOnClickListener(v -> {
            if (recording) return;
            if (lastVideo != null) {
                if (!openInGallery(lastVideo, "video/mp4")) a.toast("Saved in Movies/Tint");
            } else if (lastPhoto != null) {
                if (!openInGallery(lastPhoto, "image/jpeg") && lastDir != null) a.openFromCamera(lastDir);
            } else if (savingShot) {
                openWhenSaved = true;                   // still being saved: open it the moment it's ready
            } else if (lastDir != null) a.openFromCamera(lastDir);
        });
        lastShot.setOnLongClickListener(v -> {         // hold the thumbnail: edit it in Tint instead
            if (recording || lastDir == null) return false;
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            a.openFromCamera(lastDir);
            return true;
        });
        shut.addView(lastShot, new LinearLayout.LayoutParams(dp(50), dp(50)));
        shut.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
        FrameLayout shutter = new FrameLayout(a);
        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setStroke(dp(4), Color.WHITE);
        shutter.setBackground(ring);
        View inner = new View(a);
        shutterInner = inner;
        GradientDrawable in = new GradientDrawable();
        in.setShape(GradientDrawable.OVAL);
        in.setColor(Color.WHITE);
        inner.setBackground(in);
        shutter.addView(inner, new FrameLayout.LayoutParams(dp(60), dp(60), Gravity.CENTER));
        shutter.setOnClickListener(v -> {
            inner.animate().scaleX(.85f).scaleY(.85f).setDuration(80).withEndAction(() ->
                    inner.animate().scaleX(1).scaleY(1).setDuration(120).start()).start();
            if (video) toggleRecord(); else capture();
        });
        shut.addView(shutter, new LinearLayout.LayoutParams(dp(76), dp(76)));
        shut.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
        TextView flip = roundBtn("⟲");
        flip.setTextSize(22);
        flip.setOnClickListener(v -> {
            if (recording) { a.toast("Stop recording first"); return; }
            front = !front;
            lensOverride = null;
            physOverride = null;
            zoom = 1;
            zTotal = 1;
            zWant = 1;
            lenses.clear();
            v.animate().rotationBy(180).setDuration(250).start();
            restartCamera();
        });
        shut.addView(flip, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout modes = new LinearLayout(a);
        modes.setGravity(Gravity.CENTER);
        modes.setPadding(0, dp(6), 0, 0);
        modePhoto = modeChip("PHOTO");
        modeNight = modeChip("NIGHT");
        modeVideo = modeChip("VIDEO");
        modePhoto.setOnClickListener(v -> setCamMode(0));
        modeNight.setOnClickListener(v -> setCamMode(1));
        modeVideo.setOnClickListener(v -> setCamMode(2));
        modes.addView(modePhoto);
        modes.addView(modeNight);
        modes.addView(modeVideo);
        bottomBar.addView(modes);
        bottomBar.addView(shut);

        orient = new OrientationEventListener(a) {
            @Override public void onOrientationChanged(int o) {
                if (o != ORIENTATION_UNKNOWN) deviceDeg = ((o + 45) / 90 * 90) % 360;
            }
        };
        return root;
    }

    ImageView lastShot;
    java.io.File lastDir;
    android.net.Uri lastPhoto;
    boolean savingShot, openWhenSaved;

    /**
     * Opens a saved photo/video straight in the phone's gallery, without the "open with" question:
     * the phone's default viewer if one is set, otherwise Google Photos or the phone's own gallery.
     */
    boolean openInGallery(android.net.Uri uri, String mime) {
        android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_VIEW);
        i.setDataAndType(uri, mime);
        i.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            String pkg = galleryPackage(i);
            if (pkg != null) i.setPackage(pkg);
            a.startActivity(i);
            return true;
        } catch (Throwable t) {
            try { i.setPackage(null); a.startActivity(i); return true; } catch (Throwable t2) { return false; }
        }
    }

    /**
     * The phone's own Gallery app (the one that ships with the phone and calls itself the gallery),
     * so photos open there every time — never a "which app?" question, never Google Photos instead.
     */
    String galleryPackage(android.content.Intent view) {
        android.content.pm.PackageManager pm = a.getPackageManager();
        String me = a.getPackageName();
        List<android.content.pm.ResolveInfo> viewers = pm.queryIntentActivities(view, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY);
        java.util.Set<String> canView = new java.util.HashSet<>();
        for (android.content.pm.ResolveInfo r : viewers) if (!me.equals(r.activityInfo.packageName)) canView.add(r.activityInfo.packageName);
        // 1. apps that register as the phone's gallery
        List<String> galleries = new ArrayList<>();
        try {
            android.content.Intent g = android.content.Intent.makeMainSelectorActivity(android.content.Intent.ACTION_MAIN, android.content.Intent.CATEGORY_APP_GALLERY);
            for (android.content.pm.ResolveInfo r : pm.queryIntentActivities(g, 0)) galleries.add(r.activityInfo.packageName);
        } catch (Throwable ignored) { }
        // known gallery apps by name, the phone maker's first
        String[] known = {"com.nothing.gallery", "com.nothing.photos", "com.android.gallery3d", "com.sec.android.gallery3d",
                "com.miui.gallery", "com.coloros.gallery3d", "com.oneplus.gallery", "com.google.android.apps.photosgo",
                "com.google.android.apps.photos"};
        for (String k : known) if (!galleries.contains(k)) galleries.add(k);
        // the maker's gallery (anything that isn't Google Photos) wins over Google Photos
        for (String g : galleries) if (canView.contains(g) && !g.startsWith("com.google.android.apps.photos")) return g;
        for (android.content.pm.ResolveInfo r : viewers) {          // any built-in app with "gallery" in its name
            String p = r.activityInfo.packageName;
            if (!me.equals(p) && p.toLowerCase(java.util.Locale.US).contains("gallery")) return p;
        }
        for (String g : galleries) if (canView.contains(g)) return g;
        return canView.isEmpty() ? null : canView.iterator().next();
    }

    /** The moment the shutter fires: show what you just shot (the live picture) next to the shutter. */
    void showShotNow(Bitmap snap) {
        if (snap == null) return;
        savingShot = true;
        openWhenSaved = false;
        lastPhoto = null;
        lastDir = null;
        lastVideo = null;
        lastShot.setImageBitmap(snap);
        lastShot.setVisibility(View.VISIBLE);
        lastShot.setScaleX(0.6f);
        lastShot.setScaleY(0.6f);
        lastShot.animate().scaleX(1).scaleY(1).setDuration(220).start();
    }

    /** Shows the newest photo next to the shutter; tap it to see it in the gallery, hold it to edit. */
    void showLast(Bitmap thumb, java.io.File dir, android.net.Uri saved) {
        lastDir = dir;
        lastPhoto = saved;
        lastVideo = null;
        boolean already = savingShot;
        savingShot = false;
        if (openWhenSaved) { openWhenSaved = false; if (saved != null) openInGallery(saved, "image/jpeg"); }
        if (already) { if (thumb != null) lastShot.setImageBitmap(thumb); return; }   // the quick picture is already showing
        lastShot.setImageBitmap(thumb);
        lastShot.setVisibility(View.VISIBLE);
        lastShot.setScaleX(0.6f);
        lastShot.setScaleY(0.6f);
        lastShot.animate().scaleX(1).scaleY(1).setDuration(220).start();
    }

    TextView modeChip(String s) {
        TextView t = new TextView(a);
        t.setShadowLayer(dp(4), 0, 0, 0xCC000000);
        t.setText(s);
        t.setTextSize(12);
        t.setLetterSpacing(0.14f);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        t.setPadding(dp(16), dp(6), dp(16), dp(6));
        return t;
    }

    void setNightSilently() { paintModes(); }

    void paintModes() {
        TextView[] m = {modePhoto, modeNight, modeVideo};
        int cur = video ? 2 : night ? 1 : 0;
        for (int k = 0; k < 3; k++) m[k].setTextColor(k == cur ? (k == 2 ? 0xFFFF5A4D : 0xFFFFC93B) : 0x99FFFFFF);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(video ? 0xFFE53935 : Color.WHITE);
        if (shutterInner != null) shutterInner.setBackground(g);
    }

    void setCamMode(int m) {
        if (recording) { a.toast("Stop recording first"); return; }
        boolean wasVideo = video;
        night = m == 1;
        video = m == 2;
        if (!video) torch = false;
        refreshTorch();
        frame.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        paintModes();
        hdrBtn.setVisibility(night || video || !yuvOk ? View.GONE : View.VISIBLE);
        if (night && yuv == null) a.toast("Night mode needs burst capture, which this lens doesn't support");
        if (video && a.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            a.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        nameFlash.setText(video ? "VIDEO ●" : night ? "NIGHT ☾" : "PHOTO");
        nameFlash.animate().cancel();
        nameFlash.setAlpha(1);
        nameFlash.animate().alpha(0).setStartDelay(650).setDuration(350).start();
        restartPreview();                               // same 9:16 frame for photo and video, no restart needed
    }

    void setNight(boolean on) { setCamMode(on ? 1 : 0); }

    // ------------------------------------------------------------------ focus

    LinearLayout focusBox;

    /** Long press: focus and expose for that spot, and keep it locked. */
    void focusAt(float x, float y) {
        if (ses == null || dev == null || activeArr == null) return;
        if (maxAf == 0 && maxAe == 0) { a.toast("This lens can't focus on a chosen spot"); return; }
        float nx = x / frame.getWidth(), ny = y / frame.getHeight();
        float va = (float) frame.getWidth() / frame.getHeight(), ca = glr.contentAspect;
        if (ca > 0) { if (va < ca) nx = 0.5f + (nx - 0.5f) * va / ca; else ny = 0.5f + (ny - 0.5f) * ca / va; }
        if (front) nx = 1 - nx;
        int disp = displayRotation() * 90;
        int rel = front ? (sensorOrient + disp) % 360 : (sensorOrient - disp + 360) % 360;
        float sx, sy;
        switch (rel) {
            case 90: sx = ny; sy = 1 - nx; break;
            case 180: sx = 1 - nx; sy = 1 - ny; break;
            case 270: sx = 1 - ny; sy = nx; break;
            default: sx = nx; sy = ny;
        }
        if (ratioApi && physOverride == null && zoom > 1) { sx = 0.5f + (sx - 0.5f) / zoom; sy = 0.5f + (sy - 0.5f) / zoom; }
        int half = Math.max(16, activeArr.width() / 16);
        int cx = activeArr.left + Math.round(sx * activeArr.width()), cy = activeArr.top + Math.round(sy * activeArr.height());
        int l = Math.max(activeArr.left, cx - half), t = Math.max(activeArr.top, cy - half);
        int r = Math.min(activeArr.right - 1, cx + half), b = Math.min(activeArr.bottom - 1, cy + half);
        focusRect = new android.hardware.camera2.params.MeteringRectangle(l, t, Math.max(1, r - l), Math.max(1, b - t),
                android.hardware.camera2.params.MeteringRectangle.METERING_WEIGHT_MAX);
        restartPreview();
        try {
            CaptureRequest.Builder bb = dev.createCaptureRequest(video ? CameraDevice.TEMPLATE_RECORD : CameraDevice.TEMPLATE_PREVIEW);
            bb.addTarget(previewTarget);
            bb.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO);
            bb.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            common(bb);
            bb.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START);
            ses.capture(bb.build(), previewCb, bg);
        } catch (Throwable ignored) { }
        frame.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        focusBox.setTranslationX(x - dp(60));
        focusBox.setTranslationY(y - dp(35));
        focusBox.setVisibility(View.VISIBLE);
        focusBox.setAlpha(1);
        focusBox.setScaleX(1.4f);
        focusBox.setScaleY(1.4f);
        focusBox.animate().scaleX(1).scaleY(1).setDuration(220).start();
    }

    void clearFocus() {
        focusRect = null;
        focusBox.animate().alpha(0).setDuration(200).withEndAction(() -> focusBox.setVisibility(View.GONE)).start();
        try {
            CaptureRequest.Builder bb = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            bb.addTarget(previewTarget);
            bb.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_CANCEL);
            ses.capture(bb.build(), null, bg);
        } catch (Throwable ignored) { }
        restartPreview();
    }

    // ------------------------------------------------------------------ palm shutter (like Samsung)

    TextView countView;
    boolean palmOn = true, counting;
    int palmHits;
    long palmCooldownUntil;
    volatile com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizer recognizer;
    final ExecutorService palmExec = Executors.newSingleThreadExecutor();
    volatile boolean palmBusy;
    boolean palmErrorShown;
    final boolean[] palmWin = new boolean[4];   // the last few looks: was there an open palm?
    int palmWinI, palmLook;
    long palmTs;

    void refreshPalm() {
        if (palmOn && shown) {
            glr.analysis = this::onAnalysisFrame;
            if (recognizer == null) palmExec.execute(this::createRecognizer);
        } else {
            glr.analysis = null;
            palmHits = 0;
        }
    }

    void createRecognizer() {
        if (recognizer != null) return;
        try {
            com.google.mediapipe.tasks.core.BaseOptions base = com.google.mediapipe.tasks.core.BaseOptions.builder()
                    .setModelAssetPath("gesture_recognizer.task").build();
            com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizer.GestureRecognizerOptions opt =
                    com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizer.GestureRecognizerOptions.builder()
                            .setBaseOptions(base)
                            .setRunningMode(com.google.mediapipe.tasks.vision.core.RunningMode.IMAGE)
                            .setNumHands(2)
                            .setMinHandDetectionConfidence(0.35f)
                            .setMinHandPresenceConfidence(0.35f)
                            .build();
            recognizer = com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizer.createFromOptions(a, opt);
        } catch (Throwable t) {
            Throwable c = t;
            while (c.getCause() != null && c.getCause() != c) c = c.getCause();
            String why = c.getClass().getSimpleName() + ": " + c.getMessage();
            try {
                java.io.StringWriter sw = new java.io.StringWriter();
                t.printStackTrace(new java.io.PrintWriter(sw));
                java.io.FileOutputStream fo = new java.io.FileOutputStream(new java.io.File(a.getFilesDir(), "palm_error.txt"));
                fo.write(sw.toString().getBytes());
                fo.close();
            } catch (Throwable ignored) { }
            a.ui.post(() -> {
                palmOn = false;
                refreshPalm();
                if (palmErrorShown) return;
                palmErrorShown = true;
                new android.app.AlertDialog.Builder(a)
                        .setTitle("Palm shutter couldn't start")
                        .setMessage(why)
                        .setPositiveButton("Copy report", (d, w) -> {
                            String txt = why;
                            try { txt = new String(java.nio.file.Files.readAllBytes(new java.io.File(a.getFilesDir(), "palm_error.txt").toPath())); } catch (Throwable ignored) { }
                            ((android.content.ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE))
                                    .setPrimaryClip(android.content.ClipData.newPlainText("Tint palm", txt));
                            a.toast("Copied, paste it to Claude");
                        })
                        .setNegativeButton("OK", null)
                        .show();
            });
        }
    }

    /** A small frame from the preview (GL thread): hand it to the gesture model on its own thread. */
    void onAnalysisFrame(Bitmap b) {
        if (b == null) return;
        if (palmBusy || recognizer == null || counting || capturing || !palmOn
                || System.currentTimeMillis() < palmCooldownUntil) { b.recycle(); return; }
        palmBusy = true;
        palmExec.execute(() -> {
            Bitmap use = b;
            try {
                // every other look zooms into the middle, so a hand further away is still big enough to read
                if ((palmLook++ & 1) == 1) {
                    int cw = b.getWidth() * 3 / 5, ch = b.getHeight() * 3 / 5;
                    use = Bitmap.createBitmap(b, (b.getWidth() - cw) / 2, (b.getHeight() - ch) / 2, cw, ch);
                }
                com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizerResult res =
                        recognizer.recognize(new com.google.mediapipe.framework.image.BitmapImageBuilder(use).build());
                onGesture(res);
            } catch (Throwable ignored) {
            } finally {
                palmBusy = false;
                if (use != b) use.recycle();
                b.recycle();
            }
        });
    }

    void onGesture(com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizerResult res) {
        boolean palm = false;
        try {
            for (int i = 0; i < res.gestures().size(); i++) {
                List<com.google.mediapipe.tasks.components.containers.Category> g = res.gestures().get(i);
                String top = g.isEmpty() ? "" : g.get(0).categoryName();
                float sc = g.isEmpty() ? 0 : g.get(0).score();
                if ("Open_Palm".equals(top) && sc > 0.45f) palm = true;
                // the model's own label can miss a palm at an angle; check the finger shape too
                else if (i < res.landmarks().size() && !"Closed_Fist".equals(top) && !"Pointing_Up".equals(top)
                        && !"Victory".equals(top) && openHand(res.landmarks().get(i))) palm = true;
            }
        } catch (Throwable ignored) { }
        palmWin[palmWinI++ % palmWin.length] = palm;
        int n = 0;
        for (boolean w : palmWin) if (w) n++;
        if (palm && n >= 2) {                        // seen in 2 of the last 4 looks (about 0.3 s): it's deliberate
            java.util.Arrays.fill(palmWin, false);
            a.ui.post(this::palmTriggered);
        }
    }

    /** All five fingers stretched out and spread: an open hand. */
    static boolean openHand(List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark> p) {
        if (p == null || p.size() < 21) return false;
        float palm = dist(p, 0, 9);                  // wrist to middle-finger knuckle: the hand's size
        if (palm < 0.03f) return false;
        int[][] f = {{8, 6, 5}, {12, 10, 9}, {16, 14, 13}, {20, 18, 17}};
        for (int[] q : f) {
            if (dist(p, 0, q[0]) < dist(p, 0, q[1]) * 1.12f) return false;   // fingertip beyond the middle joint
            if (dist(p, q[2], q[0]) < palm * 0.55f) return false;            // and properly long, not curled
        }
        if (dist(p, 4, 5) < palm * 0.35f) return false;                      // thumb out, away from the index
        if (dist(p, 8, 20) < palm * 0.6f) return false;                      // fingers spread across
        return true;
    }

    static float dist(List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark> p, int i, int j) {
        float dx = p.get(i).x() - p.get(j).x(), dy = p.get(i).y() - p.get(j).y();
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    void palmTriggered() {
        if (!shown || counting || capturing || System.currentTimeMillis() < palmCooldownUntil) return;
        frame.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        if (video && recording) {                    // palm while recording: stop
            palmCooldownUntil = System.currentTimeMillis() + 2500;
            stopRec();
            return;
        }
        counting = true;
        countdown(3);
    }

    final Runnable[] countStep = new Runnable[1];

    void countdown(int n) {
        if (!counting) return;
        if (n == 0) {
            countView.setVisibility(View.GONE);
            counting = false;
            palmCooldownUntil = System.currentTimeMillis() + 3000;
            if (video) { if (!recording) startRec(); } else capture();
            return;
        }
        countView.setText(String.valueOf(n));
        countView.setVisibility(View.VISIBLE);
        countView.setAlpha(1f);
        countView.setScaleX(1.6f);
        countView.setScaleY(1.6f);
        countView.animate().scaleX(1f).scaleY(1f).alpha(0.85f).setDuration(600).start();
        frame.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        countStep[0] = () -> countdown(n - 1);
        a.ui.postDelayed(countStep[0], 1000);
    }

    void cancelCountdown() {
        if (!counting) return;
        counting = false;
        if (countStep[0] != null) a.ui.removeCallbacks(countStep[0]);
        countView.setVisibility(View.GONE);
        palmCooldownUntil = System.currentTimeMillis() + 1500;
    }

    // ------------------------------------------------------------------ video

    static final int REQ_AUDIO = 78;
    TextView modeVideo, recTime;
    View shutterInner;
    android.media.MediaRecorder rec;
    java.io.File recFile;
    boolean recording;
    long recStart;
    android.net.Uri lastVideo;

    final Runnable recTick = new Runnable() {
        @Override public void run() {
            if (!recording) return;
            long sec = (android.os.SystemClock.elapsedRealtime() - recStart) / 1000;
            recTime.setText(String.format(java.util.Locale.US, "●  %02d:%02d", sec / 60, sec % 60));
            a.ui.postDelayed(this, 500);
        }
    };

    void toggleRecord() { if (recording) stopRec(); else startRec(); }

    void startRec() {
        if (ses == null || dev == null) return;
        boolean audio = a.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        boolean landscape = frame.ratio > 1;
        boolean wide169 = pSize != null && Math.abs((float) pSize.getWidth() / pSize.getHeight() - 16f / 9f) < 0.05f;
        int longSide = wide169 ? 1920 : 1440, shortSide = 1080;
        int vw = landscape ? longSide : shortSide, vh = landscape ? shortSide : longSide;
        try {
            rec = Build.VERSION.SDK_INT >= 31 ? new android.media.MediaRecorder(a) : new android.media.MediaRecorder();
            if (audio) rec.setAudioSource(android.media.MediaRecorder.AudioSource.CAMCORDER);
            rec.setVideoSource(android.media.MediaRecorder.VideoSource.SURFACE);
            rec.setOutputFormat(android.media.MediaRecorder.OutputFormat.MPEG_4);
            recFile = new java.io.File(a.getCacheDir(), "rec_" + System.currentTimeMillis() + ".mp4");
            rec.setOutputFile(recFile.getPath());
            rec.setVideoEncoder(android.media.MediaRecorder.VideoEncoder.H264);
            rec.setVideoEncodingBitRate(wide169 ? 20_000_000 : 16_000_000);
            rec.setVideoFrameRate(30);
            rec.setVideoSize(vw, vh);
            if (audio) {
                rec.setAudioEncoder(android.media.MediaRecorder.AudioEncoder.AAC);
                rec.setAudioEncodingBitRate(192_000);
                rec.setAudioSamplingRate(48_000);
                rec.setAudioChannels(2);
            }
            rec.prepare();
            Surface in = rec.getSurface();
            rec.start();
            glr.startRecording(in, vw, vh);
        } catch (Throwable t) {
            try { if (rec != null) rec.release(); } catch (Throwable ignored) { }
            rec = null;
            a.toast("Couldn't start recording");
            return;
        }
        recording = true;
        recStart = android.os.SystemClock.elapsedRealtime();
        frame.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        GradientDrawable sq = new GradientDrawable();
        sq.setColor(0xFFE53935);
        sq.setCornerRadius(dp(8));
        shutterInner.setBackground(sq);
        shutterInner.animate().scaleX(0.55f).scaleY(0.55f).setDuration(180).start();
        recTime.setVisibility(View.VISIBLE);
        lensRow.setAlpha(0.4f);
        a.ui.post(recTick);
        if (!audio) a.toast("Recording without sound (microphone not allowed)");
    }

    void stopRec() {
        if (!recording) return;
        recording = false;
        recTime.setVisibility(View.GONE);
        lensRow.setAlpha(1f);
        shutterInner.animate().scaleX(1).scaleY(1).setDuration(180).start();
        paintModes();
        final android.media.MediaRecorder r = rec;
        final java.io.File f = recFile;
        rec = null;
        final long len = android.os.SystemClock.elapsedRealtime() - recStart;
        final java.util.concurrent.atomic.AtomicBoolean once = new java.util.concurrent.atomic.AtomicBoolean();
        Runnable finish = () -> {
            if (!once.compareAndSet(false, true)) return;
            boolean ok = true;
            try { r.stop(); } catch (Throwable t) { ok = false; }
            try { r.release(); } catch (Throwable ignored) { }
            if (!ok || len < 800) { f.delete(); a.toast("Video too short"); return; }
            a.saveVideo(f);
        };
        glr.stopRecording(finish);
        a.ui.postDelayed(finish, 1200);            // in case the screen is going away and no frame arrives
    }

    void showLastVideo(Bitmap thumb, android.net.Uri uri) {
        lastVideo = uri;
        lastDir = null;
        lastPhoto = null;
        lastShot.setImageBitmap(thumb);
        lastShot.setVisibility(View.VISIBLE);
        lastShot.setScaleX(0.6f);
        lastShot.setScaleY(0.6f);
        lastShot.animate().scaleX(1).scaleY(1).setDuration(220).start();
    }

    void refreshHdr() {
        boolean avail = yuv != null || ySize == null;
        hdrBtn.setVisibility(yuvOk && !night && !video ? View.VISIBLE : View.GONE);
        if (modePhoto != null && modeVideo != null) paintModes();
        hdrBtn.setBackground(a.round(hdr ? 0xFFFFC93B : 0x33FFFFFF, dp(100)));
        hdrBtn.setTextColor(hdr ? Color.BLACK : Color.WHITE);
        hdrBtn.setAlpha(avail ? 1f : 0.5f);
    }

    void showProcessing(boolean on) {
        procView.animate().cancel();
        if (on) {
            procView.setText(night ? "Night ☾ · hold still ~2 s…" : "HDR+ · hold still…");
            procView.setVisibility(View.VISIBLE);
            procView.setAlpha(1);
            procView.animate().alpha(0.55f).setDuration(600).withEndAction(() -> {
                if (procView.getVisibility() == View.VISIBLE) procView.animate().alpha(1).setDuration(600).start();
            }).start();
        } else {
            procView.setVisibility(View.GONE);
        }
    }

    TextView roundBtn(String s) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(17);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0x33FFFFFF);
        t.setBackground(g);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        return t;
    }

    int flashMode = 1;       // photos: 0 off, 1 auto, 2 on (fires only when the photo is taken); starts on Auto
    boolean hasFlash = true;
    volatile boolean flashNeeded;

    void refreshTorch() {
        boolean on = video ? torch : flashMode == 2;
        torchBtn.setVisibility(hasFlash && !night ? View.VISIBLE : View.GONE);
        torchBtn.setText(video ? (torch ? "💡 ON" : "💡 OFF") : flashMode == 0 ? "⚡ OFF" : flashMode == 1 ? "⚡ AUTO" : "⚡ ON");
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(100));
        g.setColor(on ? 0xFFFFC93B : 0x33FFFFFF);
        if (!video && flashMode == 1) g.setStroke(dp(1), 0xFFFFC93B);
        torchBtn.setBackground(g);
        torchBtn.setTextColor(on ? Color.BLACK : Color.WHITE);
    }

    volatile boolean fireFlash;   // true only from pressing the shutter until the photo is taken

    /**
     * The flash setting is used only while a photo is being taken. The live preview, focusing and
     * long-press never use a flash mode, so the light can't come on at any other time.
     */
    int aeMode() {
        return fireFlash ? CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH : CaptureRequest.CONTROL_AE_MODE_ON;
    }

    /** Auto flash: is the scene dark enough to need it? (judged from the camera's own exposure) */
    boolean dark() { return (lastIso >= 1200 && lastExp >= 30_000_000L) || lastIso >= 2400; }

    /** The camera only offers the Pro Filters (plus Original). */
    List<Filter> list() {
        List<Filter> l = new ArrayList<>();
        for (Filter f : a.all) if (f.isOriginal() || f.cat.equals(Filters.PRO)) l.add(f);
        return l;
    }

    void buildFilterRow() {
        for (TextView t : catChips) {
            boolean sel = t.getTag().equals(cat);
            t.setBackground(sel ? a.round(Color.WHITE, dp(100)) : null);
            t.setTextColor(sel ? Color.BLACK : 0xFF8B8B92);
        }
        filterRow.removeAllViews();
        chips.clear();
        for (Filter f : list()) {
            TextView t = new TextView(a);
            t.setText(f.name);
            t.setTextSize(12);
            t.setLetterSpacing(0.06f);
            t.setShadowLayer(dp(3), 0, 0, 0x99000000);
            t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            t.setPadding(dp(14), dp(8), dp(14), dp(8));
            t.setTag(f);
            t.setOnClickListener(v -> setFilter(f, false));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.setMargins(dp(3), 0, dp(3), 0);
            filterRow.addView(t, lp);
            chips.add(t);
        }
        refreshChips();
        filterScroll.scrollTo(0, 0);
    }

    void refreshChips() {
        for (TextView t : chips) {
            boolean sel = t.getTag() == filter;
            t.setBackground(a.round(sel ? 0xFFFF4D2E : 0x26FFFFFF, dp(100)));
            t.setTextColor(Color.WHITE);
            if (sel) t.post(() -> filterScroll.smoothScrollTo(Math.max(0, t.getLeft() - dp(120)), 0));
        }
    }

    void step(int dir) {
        List<Filter> l = list();
        int i = Math.max(0, l.indexOf(filter));
        setFilter(l.get((i + dir + l.size()) % l.size()), true);
    }

    void setFilter(Filter f, boolean announce) {
        filter = f;
        refreshChips();
        glr.setFilter(f);
        frame.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        nameFlash.setText(f.name);
        nameFlash.animate().cancel();
        nameFlash.setAlpha(1);
        nameFlash.animate().alpha(0).setStartDelay(650).setDuration(350).start();
    }

    // ------------------------------------------------------------------ show / hide

    Integer pendingMode;

    /** Opened from the home-screen widget or a shortcut: go straight to photo (0) or video (2). */
    void openIn(int mode) {
        pendingMode = mode;
        if (shown) { applyPending(); return; }
        open();
    }

    void applyPending() {
        if (pendingMode == null) return;
        int m = pendingMode;
        pendingMode = null;
        int cur = video ? 2 : night ? 1 : 0;
        if (cur != m) setCamMode(m);
    }

    void open() {
        if (a.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            a.requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            return;
        }
        // every time the camera opens, photos and videos start with no filter (Original)
        filter = null;
        for (Filter f : a.all) if (f.isOriginal()) { filter = f; break; }
        if (filter == null) for (Filter f : a.all) if (f.cat.equals(Filters.PRO)) { filter = f; break; }
        try { hdr = a.getSharedPreferences("tint", Context.MODE_PRIVATE).getBoolean("hdr", true); } catch (Throwable ignored) { }
        shown = true;
        root.setVisibility(View.VISIBLE);
        root.setAlpha(0);
        root.animate().alpha(1).setDuration(180).start();
        buildFilterRow();
        refreshTorch();
        refreshHdr();
        if (orient.canDetectOrientation()) orient.enable();
        palmOn = true;
        refreshPalm();
        flashMode = 1;           // every time the camera opens, flash starts on Auto
        refreshTorch();
        glr.setFilter(filter);
        gl.onResume();
        start();
        applyPending();
    }

    void close() {
        cancelCountdown();
        glr.analysis = null;
        if (recording) stopRec();
        shown = false;
        stop();
        orient.disable();
        gl.onPause();
        root.setVisibility(View.GONE);
        a.refreshRecent();
    }

    void start() {
        if (thread == null) {
            thread = new HandlerThread("tint-camera");
            thread.start();
            bg = new Handler(thread.getLooper());
        }
        if (st != null) openCamera();
    }

    void stop() {
        try { if (ses != null) ses.close(); } catch (Throwable ignored) { }
        try { if (dev != null) dev.close(); } catch (Throwable ignored) { }
        try { if (reader != null) reader.close(); } catch (Throwable ignored) { }
        try { if (yuv != null) yuv.close(); } catch (Throwable ignored) { }
        ses = null; dev = null; reader = null; yuv = null; merge = null; capturing = false; awaitingLock = false; fireFlash = false;
        if (thread != null) { thread.quitSafely(); thread = null; bg = null; }
    }

    void pause() { cancelCountdown(); glr.analysis = null; if (recording) stopRec(); stop(); gl.onPause(); }

    void resume() { gl.onResume(); start(); refreshPalm(); }

    /** Switch cameras quickly: only the device and session are replaced; thread and buffers stay. */
    void restartCamera() {
        if (!shown) return;
        final CameraDevice old = dev;
        ses = null; dev = null; merge = null; capturing = false; awaitingLock = false; fireFlash = false;
        switchStart = android.os.SystemClock.uptimeMillis();
        if (thread == null) start();
        Handler h = bg;
        if (h == null) { start(); return; }
        h.post(() -> {
            // closing the device also ends its session, and is quicker than closing them one by one
            try { if (old != null) old.close(); } catch (Throwable ignored) { }
            if (shown && st != null) openCamera();
        });
    }

    volatile int openGen;
    long switchStart;
    long switchMs = 650;          // how long this phone takes to bring up another lens (learned as you use it)

    // ------------------------------------------------------------------ camera

    private static Size pick(Size[] sizes, int maxW) { return pick(sizes, maxW, 4f / 3f); }

    private static Size pick(Size[] sizes, int maxW, float aspect) {
        Size best = null;
        for (Size s : sizes) {
            float r = (float) s.getWidth() / s.getHeight();
            if (Math.abs(r - aspect) > 0.02f) continue;
            if (maxW > 0 && s.getWidth() > maxW) continue;
            if (best == null || (long) s.getWidth() * s.getHeight() > (long) best.getWidth() * best.getHeight()) best = s;
        }
        if (best == null) best = Math.abs(aspect - 4f / 3f) > 0.02f ? pick(sizes, maxW, 4f / 3f) : sizes[0];
        return best;
    }

    // ------------------------------------------------------------------ lenses

    static final class Lens {
        final String id;       // separate camera id (null: the main camera)
        final String phys;     // a lens inside the main camera, reached as a "physical" stream
        final float mul;
        final boolean ok;      // false: the phone doesn't let apps use it
        float maxZ = 1;        // how far this camera can zoom on its own
        Lens(String id, String phys, float mul, boolean ok) { this.id = id; this.phys = phys; this.mul = mul; this.ok = ok; }
        boolean ratio() { return id == null && phys == null; }
    }

    final List<Lens> lenses = new ArrayList<>();
    String camId, lensOverride, physOverride;
    float zoom = 1, zMin = 1, zMax = 1;
    boolean ratioApi, manualOk, yuvOk = true;
    final java.util.Set<String> badLens = new java.util.HashSet<>();

    /** Camera details never change while the app runs: ask the system once per camera, not on every switch. */
    static final java.util.Map<String, CameraCharacteristics> CHARS = new java.util.concurrent.ConcurrentHashMap<>();

    static CameraCharacteristics chars(CameraManager cm, String id) throws CameraAccessException {
        CameraCharacteristics c = CHARS.get(id);
        if (c == null) { c = cm.getCameraCharacteristics(id); CHARS.put(id, c); }
        return c;
    }

    private static float fovOf(CameraCharacteristics c) {
        float[] f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
        android.util.SizeF sz = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
        if (f == null || f.length == 0 || sz == null) return 0;
        return sz.getWidth() / f[0];
    }

    private void addLens(List<Lens> out, Lens l) {
        for (Lens o : out) if (Math.abs(o.mul - l.mul) < 0.15f) return;
        out.add(l);
    }

    /**
     * Looks for every back lens the phone allows apps to use: zoom ratios below 1× on the main camera,
     * separate camera ids (listed or hidden), and lenses inside the main "logical" camera.
     */
    void findLenses(CameraManager cm, String mainId) {
        lenses.clear();
        if (front) return;
        List<Lens> out = new ArrayList<>();
        try {
            CameraCharacteristics main = chars(cm, mainId);
            float mainFov = fovOf(main);
            mainMaxZ = ratioApi ? zMax : camMax(main);
            out.add(new Lens(null, null, 1f, true));
            if (ratioApi && zMin < 0.95f) addLens(out, new Lens(null, null, Math.round(zMin * 10) / 10f, true));
            // lenses built into the main camera that its zoom reaches: the camera itself hops between them
            // with no pause at all (exactly how the phone's own app does it), so prefer this over reopening
            if (ratioApi && Build.VERSION.SDK_INT >= 28) {
                for (String ph : main.getPhysicalCameraIds()) {
                    try {
                        float fov = fovOf(chars(cm, ph));
                        if (fov <= 0 || mainFov <= 0) continue;
                        float mul = Math.round(mainFov / fov * 10) / 10f;
                        if (Math.abs(mul - 1) < 0.15f || mul < zMin - 0.05f || mul > zMax + 0.01f) continue;
                        addLens(out, new Lens(null, null, mul, true));
                    } catch (Throwable ignored) { }
                }
            }
            // separate cameras, including ids the phone doesn't list
            java.util.Set<String> ids = new java.util.LinkedHashSet<>(Arrays.asList(cm.getCameraIdList()));
            for (int k = 0; k < 10; k++) ids.add(String.valueOf(k));
            for (String c : ids) {
                if (c.equals(mainId) || badLens.contains(c)) continue;
                try {
                    CameraCharacteristics ch = chars(cm, c);
                    Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                    if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;
                    float fov = fovOf(ch);
                    if (fov <= 0 || mainFov <= 0) continue;
                    float mul = Math.round(mainFov / fov * 10) / 10f;
                    if (Math.abs(mul - 1) < 0.15f) continue;
                    Lens L = new Lens(c, null, mul, true);
                    L.maxZ = camMax(ch);
                    addLens(out, L);
                } catch (Throwable ignored) { }
            }
            // lenses inside the main camera
            if (Build.VERSION.SDK_INT >= 28) {
                for (String ph : main.getPhysicalCameraIds()) {
                    if (badLens.contains("p" + ph)) continue;
                    try {
                        float fov = fovOf(chars(cm, ph));
                        if (fov <= 0 || mainFov <= 0) continue;
                        float mul = Math.round(mainFov / fov * 10) / 10f;
                        if (Math.abs(mul - 1) < 0.15f) continue;
                        addLens(out, new Lens(null, ph, mul, true));
                    } catch (Throwable ignored) { }
                }
            }
            boolean wide = false, tele = false;
            for (Lens l : out) { if (l.mul < 0.9f) wide = true; if (l.mul >= 1.8f) tele = true; }
            if (!tele && ratioApi && zMax >= 2f) out.add(new Lens(null, null, 2f, true));
            if (!wide) out.add(new Lens(null, null, 0.6f, false));          // shown, but explains it's blocked
        } catch (Throwable ignored) {
            if (out.isEmpty()) out.add(new Lens(null, null, 1f, true));
        }
        out.sort((x, y) -> Float.compare(x.mul, y.mul));
        lenses.addAll(out);
    }

    float mainMaxZ = 1;

    static float camMax(CameraCharacteristics ch) {
        if (Build.VERSION.SDK_INT >= 30) {
            android.util.Range<Float> r = ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);
            if (r != null) return r.getUpper();
        }
        Float dz = ch.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
        return dz == null ? 1 : dz;
    }

    static String label(float m) {
        if (m < 1) return String.format(java.util.Locale.US, "%.1f", m).replace("0.", ".") + "×";
        return (m == Math.floor(m) ? String.valueOf((int) m) : String.format(java.util.Locale.US, "%.1f", m)) + "×";
    }

    // ------------------------------------------------------------------ iPhone-style zoom
    // zTotal is the zoom the user sees (0.6×, 1×, 2.4×…). It is turned into "which camera + how much
    // digital zoom on it". Lenses inside one camera change seamlessly; switching cameras blurs across.

    float zTotal = 1;          // zoom actually applied right now
    float zWant = 1;           // zoom the user is asking for (may cross to another camera when the finger lifts)
    ZoomDial dial;
    android.animation.ValueAnimator zoomAnim;
    ImageView blurView;
    final Runnable hideDial = () -> {
        if (dial == null || dial.getVisibility() != View.VISIBLE) return;
        dial.animate().alpha(0).translationY(dp(40)).setDuration(180).withEndAction(() -> {
            dial.setVisibility(View.GONE);
            lensRow.setVisibility(lenses.size() > 1 ? View.VISIBLE : View.GONE);
        }).start();
    };

    List<Lens> okLenses() {
        List<Lens> l = new ArrayList<>();
        for (Lens x : lenses) if (x.ok) l.add(x);
        return l;
    }

    float zLo() {
        float lo = 1;
        for (Lens l : okLenses()) lo = Math.min(lo, l.mul);
        return lo;
    }

    float zHi() {
        float hi = Math.max(1, mainMaxZ);
        for (Lens l : okLenses()) if (!l.ratio()) hi = Math.max(hi, l.mul * l.maxZ);
        return Math.max(hi, zLo());
    }

    /** The camera a zoom level should use: the longest lens that still covers it. */
    Lens target(float z) {
        Lens best = null;
        for (Lens l : okLenses()) if (l.mul <= z + 0.001f && (best == null || l.mul >= best.mul)) best = l;
        if (best == null) { for (Lens l : okLenses()) if (best == null || l.mul < best.mul) best = l; }
        return best == null ? new Lens(null, null, 1f, true) : best;
    }

    /** Lenses that are just zoom ratios all live on the main camera. */
    static String camKey(Lens l) { return l.id != null ? "i" + l.id : l.phys != null ? "p" + l.phys : "main"; }

    String currentKey() { return lensOverride != null ? "i" + lensOverride : physOverride != null ? "p" + physOverride : "main"; }

    /** Digital zoom to apply on the target camera for a total zoom z. */
    static float digital(Lens t, float z) { return t.ratio() ? z : z / t.mul; }

    void applyZoom(float z, boolean allowSwitch) {
        if (front) {
            zoom = Math.max(zMin, Math.min(zMax, z));
            zTotal = zoom;
            zWant = zoom;
            restartPreview();
            return;
        }
        z = Math.max(zLo(), Math.min(zHi(), z));
        zWant = z;
        Lens t = target(z);
        if (camKey(t).equals(currentKey())) {
            zTotal = z;
            zoom = Math.max(zMin, Math.min(zMax, digital(t, z)));
            restartPreview();
        } else if (allowSwitch && !recording) {
            zTotal = z;
            switchCamera(t, digital(t, z));
        } else {
            // mid-gesture: keep zooming on this camera, switch when the finger lifts
            Lens cur = null;
            for (Lens l : okLenses()) if (camKey(l).equals(currentKey()) && (cur == null || l.mul < cur.mul)) cur = l;
            float base = cur == null || cur.ratio() ? 1 : cur.mul;
            zoom = Math.max(zMin, Math.min(zMax, z / base));
            zTotal = zoom * base;
            restartPreview();
        }
        updateLensRow();
        if (dial != null && dial.getVisibility() == View.VISIBLE) { dial.set(zWant, zLo(), zHi()); }
    }

    /** Switching to another camera: freeze + blur the last picture, then fade into the new lens. */
    /**
     * Switching to another camera, iPhone-style: the last frame is frozen and zoomed to exactly the
     * framing the new lens will have, then the live picture from the new lens crossfades in on top.
     */
    void switchCamera(Lens t, float dig) {
        final float fromZ = zTotal, toZ = zWant;
        final java.util.concurrent.atomic.AtomicBoolean done = new java.util.concurrent.atomic.AtomicBoolean();
        Runnable go = () -> {
            if (!done.compareAndSet(false, true)) return;
            lensOverride = t.id;
            physOverride = t.phys;
            zoom = dig;
            zTotal = toZ;
            focusRect = null;
            if (focusBox != null) focusBox.setVisibility(View.GONE);
            glr.onNextFrames(2, this::revealLive);
            restartCamera();
            updateLensRow();
            a.ui.postDelayed(this::revealLive, 1800);      // never leave the frozen frame up
        };
        glr.snapshot(bmp -> {
            if (bmp != null) {
                float scale = Math.max(0.8f, Math.min(4f, toZ / Math.max(0.1f, fromZ)));
                blurView.setImageBitmap(bmp);
                blurView.animate().cancel();
                blurView.setScaleX(1f);
                blurView.setScaleY(1f);
                blurView.setAlpha(1f);
                if (Build.VERSION.SDK_INT >= 31) {
                    float r = scale < 1 ? dp(12) : dp(3);       // zooming out shows less detail: soften more
                    blurView.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP));
                }
                blurView.setVisibility(View.VISIBLE);
                blurView.animate().scaleX(scale).scaleY(scale).setDuration(Math.max(300, Math.min(1500, switchMs + 80)))
                        .setInterpolator(new android.view.animation.DecelerateInterpolator(1.2f)).start();
            }
            go.run();
        });
        a.ui.postDelayed(go, 60);        // if no frame comes, switch anyway
    }

    /** The new lens is streaming: dissolve the frozen frame into the live picture. */
    void revealLive() {
        if (switchStart > 0) {
            long ms = android.os.SystemClock.uptimeMillis() - switchStart;
            if (ms > 100 && ms < 3000) switchMs = (switchMs * 2 + ms) / 3;
            switchStart = 0;
        }
        if (blurView.getVisibility() != View.VISIBLE) return;
        blurView.animate().cancel();
        blurView.animate().alpha(0).setDuration(220).withEndAction(() -> {
            blurView.setVisibility(View.GONE);
            blurView.setScaleX(1f);
            blurView.setScaleY(1f);
        }).start();
    }


    void animateZoomTo(float target) {
        if (zoomAnim != null) zoomAnim.cancel();
        Lens t = target(target);
        if (!camKey(t).equals(currentKey())) { applyZoom(target, true); return; }
        driveTo(target, true);
    }

    void showDial() {
        if (dial == null) return;
        a.ui.removeCallbacks(hideDial);
        dial.set(zWant, zLo(), zHi());
        if (dial.getVisibility() != View.VISIBLE) {
            dial.setVisibility(View.VISIBLE);
            dial.setAlpha(0);
            dial.setTranslationY(dp(40));
            dial.animate().alpha(1).translationY(0).setDuration(200)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
            lensRow.setVisibility(View.INVISIBLE);
            frame.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        }
    }

    void hideDialSoon() { a.ui.removeCallbacks(hideDial); a.ui.postDelayed(hideDial, 2500); }

    final List<TextView> lensBtns = new ArrayList<>();

    /** Creates the lens buttons (only when the list of lenses changes). */
    void buildLensRow() {
        if (lensTouching) { a.ui.post(this::buildLensRow); return; }
        lensRow.removeAllViews();
        lensBtns.clear();
        for (Lens l : lenses) {
            TextView t = new TextView(a);
            t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            t.setGravity(Gravity.CENTER);
            t.setTag(l);
            final float[] start = new float[2];
            final boolean[] dragging = {false};
            t.setOnTouchListener((v, e) -> {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        lensTouching = true;
                        start[0] = e.getRawX();
                        start[1] = zWant;
                        if (vt != null) vt.recycle();
                        vt = android.view.VelocityTracker.obtain();
                        vt.addMovement(rawEvent(e));
                        dragging[0] = false;
                        v.getParent().requestDisallowInterceptTouchEvent(true);
                        a.ui.postDelayed(holdToDial, 350);          // hold = show the wheel, like the iPhone
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - start[0];
                        if (vt != null) vt.addMovement(rawEvent(e));
                        if (!dragging[0] && Math.abs(dx) > dp(8) && !front) { dragging[0] = true; showDial(); }
                        if (dragging[0]) driveTo((float) (start[1] * Math.pow(2, -dx / dial.pxStop())), false);
                        return true;
                    }
                    case MotionEvent.ACTION_UP: {
                        lensTouching = false;
                        a.ui.removeCallbacks(holdToDial);
                        boolean wasDial = dragging[0] || dial.getVisibility() == View.VISIBLE;
                        float vx = 0;
                        if (vt != null) { vt.addMovement(rawEvent(e)); vt.computeCurrentVelocity(1000); vx = vt.getXVelocity(); }
                        if (wasDial) { if (dragging[0]) releaseWithMomentum(vx); else { driveTo(zWant, true); hideDialSoon(); } }
                        else { Lens lens = (Lens) v.getTag(); a.ui.post(() -> pickLens(lens)); }
                        return true;
                    }
                    default:
                        lensTouching = false;
                        a.ui.removeCallbacks(holdToDial);
                        if (dragging[0]) { driveTo(zGoal, true); hideDialSoon(); }
                        return true;
                }
            });
            lensRow.addView(t);
            lensBtns.add(t);
        }
        updateLensRow();
    }

    boolean lensTouching;

    // Smooth zoom: gestures set a goal; every screen frame the zoom eases toward it (no jumps),
    // and a flick keeps it gliding like the iPhone wheel. Light clicks when passing 1×, 2×…
    float zGoal = 1, zSmooth = 1;
    boolean zRunning, zSettle;
    android.view.VelocityTracker vt;

    final android.view.Choreographer.FrameCallback zFrame = new android.view.Choreographer.FrameCallback() {
        @Override public void doFrame(long t) {
            if (!shown) { zRunning = false; return; }
            double d = Math.log(zGoal) - Math.log(zSmooth);
            if (Math.abs(d) < 0.003) {
                zSmooth = zGoal;
                applyZoom(zSmooth, false);
                zRunning = false;
                if (zSettle) { zSettle = false; applyZoom(zGoal, true); }
                return;
            }
            float before = zWant;
            zSmooth = (float) Math.exp(Math.log(zSmooth) + d * 0.28);
            applyZoom(zSmooth, false);
            clickIfCrossed(before, zWant);
            android.view.Choreographer.getInstance().postFrameCallback(this);
        }
    };

    void driveTo(float goal, boolean settle) {
        if (zoomAnim != null) zoomAnim.cancel();
        zGoal = Math.max(zLo(), Math.min(zHi(), goal));
        if (settle) zSettle = true;
        if (!zRunning) {
            zRunning = true;
            zSmooth = zWant;
            android.view.Choreographer.getInstance().postFrameCallback(zFrame);
        }
    }

    void clickIfCrossed(float a0, float a1) {
        for (Lens l : okLenses()) {
            if ((a0 - l.mul) * (a1 - l.mul) < 0) { frame.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); return; }
        }
        float[] marks = {5, 10, 20};
        for (float m : marks) if ((a0 - m) * (a1 - m) < 0) { frame.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); return; }
    }

    /** After a drag ends: keep gliding in the flick direction, then settle on the right lens. */
    void releaseWithMomentum(float vxPerSec) {
        double stopsPerSec = -vxPerSec / dial.pxStop();
        stopsPerSec = Math.max(-6, Math.min(6, stopsPerSec));
        driveTo((float) (zGoal * Math.pow(2, stopsPerSec * 0.22)), true);
        hideDialSoon();
    }
    final Runnable holdToDial = () -> { if (lensTouching && !front) showDial(); };

    /** Updates labels and sizes in place (safe while a finger is on a button). */
    void updateLensRow() {
        if (dial == null || dial.getVisibility() != View.VISIBLE) lensRow.setVisibility(lenses.size() > 1 ? View.VISIBLE : View.GONE);
        Lens active = front ? null : target(zWant);
        for (TextView t : lensBtns) {
            Lens l = (Lens) t.getTag();
            boolean sel = active != null && camKey(l).equals(camKey(active)) && Math.abs(l.mul - active.mul) < 0.01f;
            t.setText(sel ? label(Math.round(zWant * 10) / 10f) : label(l.mul));
            t.setTextSize(sel ? 12.5f : 11);
            t.setTextColor(sel ? 0xFFFFC93B : l.ok ? Color.WHITE : 0x77FFFFFF);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(sel ? 0xCC000000 : 0x66000000);
            t.setBackground(g);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(sel ? 42 : 34), dp(sel ? 42 : 34));
            lp.setMargins(dp(4), 0, dp(4), 0);
            lp.gravity = Gravity.CENTER_VERTICAL;
            t.setLayoutParams(lp);
        }
    }

    void pickLens(Lens l) {
        frame.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        if (!l.ok) {
            a.toast("Your phone doesn't let other apps use the " + label(l.mul) + " lens (only its own camera app)");
            return;
        }
        if (recording && !camKey(l).equals(currentKey())) { a.toast("Lenses can't change while recording, pinch to zoom instead"); return; }
        animateZoomTo(l.mul);
    }

    /** A lens failed to open: mark it blocked and go back to the main camera. */
    void lensFailed() {
        String key = lensOverride != null ? lensOverride : physOverride != null ? "p" + physOverride : null;
        if (key == null) return;
        badLens.add(key);
        float mul = 1;
        for (Lens l : lenses) if ((l.id != null && l.id.equals(lensOverride)) || (l.phys != null && l.phys.equals(physOverride))) mul = l.mul;
        lensOverride = null; physOverride = null; zoom = 1; zTotal = 1; zWant = 1;
        lenses.clear();
        if (blurView != null) blurView.setVisibility(View.GONE);
        a.toast("Your phone doesn't let other apps use the " + label(mul) + " lens (only its own camera app)");
        restartCamera();
    }

    boolean pinching;

    void pinch(float factor) {
        if (!pinching) { pinching = true; zGoal = zWant; }
        if (front) { applyZoom(zWant * factor, false); return; }
        driveTo(zGoal * factor, false);
        showDial();
    }

    void pinchEnd() {
        pinching = false;
        driveTo(zGoal, true);
        hideDialSoon();
    }

    /** Movement in screen coordinates (the button itself doesn't move, but this keeps velocity honest). */
    static MotionEvent rawEvent(MotionEvent e) {
        MotionEvent m = MotionEvent.obtain(e);
        m.setLocation(e.getRawX(), e.getRawY());
        return m;
    }

    /**
     * iPhone-style zoom wheel: a semicircle that rises from the bottom, with ticks around its edge.
     * Drag sideways to turn it; the yellow marker at the top shows the zoom.
     */
    final class ZoomDial extends View {
        float z = 1, lo = 1, hi = 10;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float downX, downZ;
        static final float DEG_PER_STOP = 34f;      // how far the wheel turns for each doubling of zoom

        ZoomDial() {
            super(CameraUI.this.a);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        }

        /** Finger travel (px) for one doubling of zoom, matching the wheel's turn. */
        float pxStop() {
            float R = getWidth() > 0 ? getWidth() * 0.62f : dp(260);
            return (float) (R * Math.toRadians(DEG_PER_STOP));
        }

        void set(float z, float lo, float hi) { this.z = z; this.lo = lo; this.hi = hi; invalidate(); }

        private double log2(double v) { return Math.log(v) / Math.log(2); }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            float R = w * 0.62f;
            float cx = w / 2f, top = h * 0.30f, cy = top + R;          // circle centre is below the view
            // dark glass disc
            p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(cx, cy, R, new int[]{0xCC000000, 0xB0000000, 0x8A000000},
                    new float[]{0, 0.85f, 1}, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, R, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1));
            p.setColor(0x33FFFFFF);
            c.drawCircle(cx, cy, R, p);

            double lz = log2(z), a0 = log2(lo), a1 = log2(hi);
            // small ticks every 0.1 stop
            p.setStrokeCap(Paint.Cap.ROUND);
            for (double st = Math.ceil(a0 * 10) / 10; st <= a1 + 1e-6; st += 0.1) {
                double ang = Math.toRadians((st - lz) * DEG_PER_STOP);
                if (Math.abs(ang) > Math.toRadians(62)) continue;
                float fade = (float) Math.max(0, 1 - Math.abs(ang) / Math.toRadians(62));
                float sn = (float) Math.sin(ang), cs = (float) Math.cos(ang);
                p.setColor(Color.WHITE);
                p.setAlpha((int) (170 * fade));
                p.setStrokeWidth(dp(1.2f));
                c.drawLine(cx + sn * (R - dp(6)), cy - cs * (R - dp(6)), cx + sn * (R - dp(16)), cy - cs * (R - dp(16)), p);
            }
            // labelled marks
            float[] nice = {0.5f, 0.6f, 1, 1.5f, 2, 3, 5, 8, 10, 15, 20, 30, 50, 100};
            p.setTextSize(dp(11.5f));
            for (float v : nice) {
                if (v < lo - 0.01f || v > hi + 0.01f) continue;
                double ang = Math.toRadians((log2(v) - lz) * DEG_PER_STOP);
                if (Math.abs(ang) > Math.toRadians(62)) continue;
                float fade = (float) Math.max(0, 1 - Math.abs(ang) / Math.toRadians(62));
                float sn = (float) Math.sin(ang), cs = (float) Math.cos(ang);
                p.setStyle(Paint.Style.STROKE);
                p.setColor(Color.WHITE);
                p.setAlpha((int) (255 * fade));
                p.setStrokeWidth(dp(1.8f));
                c.drawLine(cx + sn * (R - dp(6)), cy - cs * (R - dp(6)), cx + sn * (R - dp(22)), cy - cs * (R - dp(22)), p);
                p.setStyle(Paint.Style.FILL);
                float lx = cx + sn * (R - dp(38)), ly = cy - cs * (R - dp(38));
                c.save();
                c.rotate((float) Math.toDegrees(ang), lx, ly);
                c.drawText(label(v), lx, ly + dp(4), p);
                c.restore();
            }
            // yellow marker + current zoom at the top of the wheel
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFFC93B);
            Path tri = new Path();
            tri.moveTo(cx - dp(6), top - dp(2));
            tri.lineTo(cx + dp(6), top - dp(2));
            tri.lineTo(cx, top + dp(8));
            tri.close();
            c.drawPath(tri, p);
            p.setTextSize(dp(15));
            p.setShadowLayer(dp(5), 0, 0, 0xCC000000);
            c.drawText(label(Math.round(z * 10) / 10f), cx, top - dp(10), p);
            p.clearShadowLayer();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getX();
                    downZ = zWant;
                    a.ui.removeCallbacks(hideDial);
                    getParent().requestDisallowInterceptTouchEvent(true);
                    if (vt != null) vt.recycle();
                    vt = android.view.VelocityTracker.obtain();
                    vt.addMovement(e);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (vt != null) vt.addMovement(e);
                    driveTo((float) (downZ * Math.pow(2, -(e.getX() - downX) / pxStop())), false);
                    return true;
                case MotionEvent.ACTION_UP: {
                    float vx = 0;
                    if (vt != null) { vt.addMovement(e); vt.computeCurrentVelocity(1000); vx = vt.getXVelocity(); }
                    releaseWithMomentum(vx);
                    return true;
                }
                default:
                    driveTo(zGoal, true);
                    hideDialSoon();
                    return true;
            }
        }
    }

    // ------------------------------------------------------------------ camera

    ImageReader yuv;
    Size ySize;

    void openCamera() {
        try {
            CameraManager cm = (CameraManager) a.getSystemService(Context.CAMERA_SERVICE);
            String id = null;
            for (String c : cm.getCameraIdList()) {
                Integer facing = chars(cm, c).get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == (front ? CameraCharacteristics.LENS_FACING_FRONT : CameraCharacteristics.LENS_FACING_BACK)) { id = c; break; }
            }
            if (id == null) id = cm.getCameraIdList()[0];
            String mainId = id;
            if (!front && lensOverride != null) id = lensOverride;
            camId = id;
            CameraCharacteristics ch = chars(cm, id);
            CameraCharacteristics sizeCh = (!front && physOverride != null) ? chars(cm, physOverride) : ch;
            StreamConfigurationMap map = sizeCh.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map == null) map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Integer so = sizeCh.get(CameraCharacteristics.SENSOR_ORIENTATION);
            sensorOrient = so == null ? 90 : so;
            ratioApi = false; zMin = 1; zMax = 1;
            if (Build.VERSION.SDK_INT >= 30) {
                android.util.Range<Float> r = ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);
                if (r != null) { ratioApi = true; zMin = r.getLower(); zMax = r.getUpper(); }
            }
            if (!ratioApi) {
                Float dz = ch.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
                zMax = dz == null ? 1 : dz;
            }
            zoom = Math.max(zMin, Math.min(zMax, zoom));
            Boolean fl = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            hasFlash = fl != null && fl;
            a.ui.post(this::refreshTorch);
            manualOk = false;
            int[] caps = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
            if (caps != null) for (int c : caps) if (c == CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) manualOk = true;
            if (lenses.isEmpty() || front) {
                boolean r0 = ratioApi; float a0 = zMin, b0 = zMax;
                if (!mainId.equals(id)) {                         // lens list is always built from the main camera
                    CameraCharacteristics mc = chars(cm, mainId);
                    if (Build.VERSION.SDK_INT >= 30) {
                        android.util.Range<Float> r = mc.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);
                        if (r != null) { ratioApi = true; zMin = r.getLower(); zMax = r.getUpper(); }
                    }
                }
                findLenses(cm, mainId);
                ratioApi = r0; zMin = a0; zMax = b0;
            }
            if (physOverride != null) zoom = 1;
            if (front) { zTotal = zoom; zWant = zoom; }
            pSize = pick(map.getOutputSizes(SurfaceTexture.class), 1920, 16f / 9f);
            Rect arr = sizeCh.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            activeArr = arr != null ? arr : ch.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            Integer mAf = ch.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF), mAe = ch.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE);
            maxAf = mAf == null ? 0 : mAf;
            maxAe = mAe == null ? 0 : mAe;
            focusRect = null;
            stabOk = false;
            int[] stab = ch.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES);
            if (stab != null) for (int m : stab) if (m == CameraCharacteristics.CONTROL_VIDEO_STABILIZATION_MODE_ON) stabOk = true;
            fps30 = null;
            android.util.Range<Integer>[] fr = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
            if (fr != null) for (android.util.Range<Integer> r : fr) if (r.getUpper() == 30 && (fps30 == null || r.getLower() > fps30.getLower())) fps30 = r;
            jSize = pick(map.getOutputSizes(ImageFormat.JPEG), 0, 16f / 9f);     // photo framed exactly like the 9:16 preview
            Size[] ys = map.getOutputSizes(ImageFormat.YUV_420_888);
            ySize = ys == null || ys.length == 0 ? null : pick(ys, 0, 16f / 9f);
            if (ySize != null && (ySize.getWidth() % 2 != 0 || ySize.getHeight() % 2 != 0)) ySize = null;
            if (reader == null || reader.getWidth() != jSize.getWidth() || reader.getHeight() != jSize.getHeight()) {
                try { if (reader != null) reader.close(); } catch (Throwable ignored) { }
                reader = ImageReader.newInstance(jSize.getWidth(), jSize.getHeight(), ImageFormat.JPEG, 2);
            }
            reader.setOnImageAvailableListener(this::onJpeg, bg);
            boolean keepYuv = yuv != null && ySize != null && yuvOk && yuv.getWidth() == ySize.getWidth() && yuv.getHeight() == ySize.getHeight();
            if (!keepYuv) { try { if (yuv != null) yuv.close(); } catch (Throwable ignored) { } yuv = null; }
            if (keepYuv) yuv.setOnImageAvailableListener(this::onYuv, bg);
            else if (ySize != null && yuvOk) {
                yuv = ImageReader.newInstance(ySize.getWidth(), ySize.getHeight(), ImageFormat.YUV_420_888, 10);
                yuv.setOnImageAvailableListener(this::onYuv, bg);
            }
            a.ui.post(() -> { layoutPreview(); buildLensRow(); refreshHdr(); });
            final int myGen = ++openGen;
            cm.openCamera(id, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice c) {
                    if (myGen != openGen || !shown) { c.close(); return; }   // a newer lens was asked for meanwhile
                    CameraDevice prev = dev;
                    if (prev != null && prev != c) try { prev.close(); } catch (Throwable ignored) { }
                    dev = c;
                    createSession();
                }
                @Override public void onDisconnected(CameraDevice c) { c.close(); dev = null; }
                @Override public void onError(CameraDevice c, int e) {
                    c.close();
                    dev = null;
                    a.ui.post(() -> {
                        if (lensOverride != null) lensFailed();
                        else a.toast("Camera is busy or unavailable");
                    });
                }
            }, bg);
        } catch (SecurityException e) {
            if (lensOverride != null || physOverride != null) a.ui.post(this::lensFailed);
            else a.toast("Camera permission is needed");
        } catch (Throwable t) {
            if (lensOverride != null || physOverride != null) a.ui.post(this::lensFailed);
            else a.toast("Couldn't open the camera");
        }
    }

    int displayRotation() {
        Display d = Build.VERSION.SDK_INT >= 30 ? a.getDisplay() : a.getWindowManager().getDefaultDisplay();
        return d == null ? Surface.ROTATION_0 : d.getRotation();
    }

    /** Fits the preview to the frame (handles tablets in landscape too). */
    void layoutPreview() {
        if (pSize == null) return;
        int rot = displayRotation();
        boolean landscape = rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270;
        frame.setRatio(landscape ? (float) pSize.getWidth() / pSize.getHeight() : (float) pSize.getHeight() / pSize.getWidth());
        glr.flipX = front;
        glr.contentAspect = landscape ? (float) pSize.getWidth() / pSize.getHeight() : (float) pSize.getHeight() / pSize.getWidth();
        glr.rot = (float) Math.toRadians(rot == Surface.ROTATION_90 ? -90 : rot == Surface.ROTATION_270 ? 90 : rot == Surface.ROTATION_180 ? 180 : 0);
        gl.requestRender();
    }

    void createSession() {
        try {
            if (st == null || dev == null) return;
            st.setDefaultBufferSize(pSize.getWidth(), pSize.getHeight());
            Surface s = new Surface(st);
            CameraDevice d = dev;
            List<Surface> outs = new ArrayList<>(Arrays.asList(s, reader.getSurface()));
            final boolean withYuv = yuv != null;
            if (withYuv) outs.add(yuv.getSurface());
            CameraCaptureSession.StateCallback cb = new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession c) {
                    if (dev == null) return;
                    ses = c;
                    previewTarget = s;
                    restartPreview();
                }
                @Override public void onConfigureFailed(CameraCaptureSession c) {
                    if (physOverride != null) {           // this lens can't be streamed: back to main
                        a.ui.post(() -> lensFailed());
                    } else if (withYuv) {                 // this phone can't do the burst stream: use single shots
                        yuvOk = false;
                        a.ui.post(() -> restartCamera());
                    } else {
                        a.ui.post(() -> a.toast("Couldn't start the camera"));
                    }
                }
            };
            if (physOverride != null && Build.VERSION.SDK_INT >= 28) {
                List<android.hardware.camera2.params.OutputConfiguration> confs = new ArrayList<>();
                for (Surface o : outs) {
                    android.hardware.camera2.params.OutputConfiguration oc = new android.hardware.camera2.params.OutputConfiguration(o);
                    oc.setPhysicalCameraId(physOverride);
                    confs.add(oc);
                }
                d.createCaptureSessionByOutputConfigurations(confs, cb, bg);
            } else {
                d.createCaptureSession(outs, cb, bg);
            }
        } catch (Throwable t) {
            a.ui.post(() -> a.toast("Couldn't start the camera"));
        }
    }

    Surface previewTarget;
    volatile int lastIso = 100;
    volatile long lastExp = 16_000_000L;
    volatile boolean awaitingLock;
    volatile long lockDeadline;
    volatile Runnable afterLock;

    android.hardware.camera2.params.MeteringRectangle focusRect;
    Rect activeArr;
    int maxAf, maxAe;
    boolean stabOk, video;
    android.util.Range<Integer> fps30;

    int afMode() {
        if (focusRect != null) return CaptureRequest.CONTROL_AF_MODE_AUTO;
        return video ? CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO : CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE;
    }

    private void common(CaptureRequest.Builder b) {
        if (focusRect != null) {
            android.hardware.camera2.params.MeteringRectangle[] r = {focusRect};
            if (maxAf > 0) b.set(CaptureRequest.CONTROL_AF_REGIONS, r);
            if (maxAe > 0) b.set(CaptureRequest.CONTROL_AE_REGIONS, r);
        }
        if (ratioApi && physOverride == null && Build.VERSION.SDK_INT >= 30) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom);
        else if (!ratioApi && physOverride == null && zoom > 1.001f && activeArr != null) {
            int cw = Math.round(activeArr.width() / zoom), ch = Math.round(activeArr.height() / zoom);
            int l = activeArr.left + (activeArr.width() - cw) / 2, t = activeArr.top + (activeArr.height() - ch) / 2;
            b.set(CaptureRequest.SCALER_CROP_REGION, new Rect(l, t, l + cw, t + ch));
        }
        b.set(CaptureRequest.FLASH_MODE, video && torch ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
    }

    final CameraCaptureSession.CaptureCallback previewCb = new CameraCaptureSession.CaptureCallback() {
        @Override public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest r, TotalCaptureResult res) {
            Integer iso = res.get(CaptureResult.SENSOR_SENSITIVITY);
            Long exp = res.get(CaptureResult.SENSOR_EXPOSURE_TIME);
            if (iso != null) lastIso = iso;
            if (exp != null) lastExp = exp;
            if (!awaitingLock) return;
            Integer af = res.get(CaptureResult.CONTROL_AF_STATE), ae = res.get(CaptureResult.CONTROL_AE_STATE);
            boolean afOk = af == null || af == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED
                    || af == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED || af == CaptureResult.CONTROL_AF_STATE_INACTIVE;
            boolean aeOk = ae == null || ae == CaptureResult.CONTROL_AE_STATE_CONVERGED || ae == CaptureResult.CONTROL_AE_STATE_LOCKED
                    || ae == CaptureResult.CONTROL_AE_STATE_FLASH_REQUIRED;
            if ((afOk && aeOk) || System.currentTimeMillis() > lockDeadline) {
                awaitingLock = false;
                Runnable go = afterLock;
                afterLock = null;
                if (go != null) go.run();
            }
        }
    };

    void restartPreview() {
        if (ses == null || dev == null || previewTarget == null) return;
        try {
            CaptureRequest.Builder b = dev.createCaptureRequest(video ? CameraDevice.TEMPLATE_RECORD : CameraDevice.TEMPLATE_PREVIEW);
            b.addTarget(previewTarget);
            b.set(CaptureRequest.CONTROL_AF_MODE, afMode());
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            if (video) {
                if (stabOk) b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON);
                if (fps30 != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, fps30);
            }
            common(b);
            ses.setRepeatingRequest(b.build(), previewCb, bg);
        } catch (Throwable ignored) { }
    }

    /** Focus and exposure settle first (like a real camera's half-press), then `then` runs. */
    void lockThen(Runnable then) {
        try {
            CaptureRequest.Builder b = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            b.addTarget(previewTarget);
            b.set(CaptureRequest.CONTROL_AF_MODE, afMode());
            b.set(CaptureRequest.CONTROL_AE_MODE, aeMode());
            common(b);
            if (focusRect == null) b.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START);
            b.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER_START);
            afterLock = then;
            lockDeadline = System.currentTimeMillis() + (aeMode() != CaptureRequest.CONTROL_AE_MODE_ON ? 1600 : 900);
            awaitingLock = true;
            ses.capture(b.build(), previewCb, bg);
        } catch (Throwable t) {
            awaitingLock = false;
            then.run();
        }
    }

    void unlock() {
        fireFlash = false;
        try {
            if (ses == null || dev == null) return;
            CaptureRequest.Builder b = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            b.addTarget(previewTarget);
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_CANCEL);
            b.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER_CANCEL);
            common(b);
            ses.capture(b.build(), null, bg);
        } catch (Throwable ignored) { }
        restartPreview();
    }

    /** Called when the camera has finished exposing a flash photo: put the light out right away. */
    final CameraCaptureSession.CaptureCallback stillCb = new CameraCaptureSession.CaptureCallback() {
        @Override public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest r, TotalCaptureResult res) { flashOff(); }
        @Override public void onCaptureFailed(CameraCaptureSession s, CaptureRequest r, CaptureFailure f) { flashOff(); }
    };

    void flashOff() {
        if (!fireFlash) return;
        unlock();
    }

    int captureDeg() {
        int turn = front ? -deviceDeg : deviceDeg;
        return (sensorOrient + turn + 360) % 360;
    }

    void capture() {
        if (ses == null || dev == null || capturing) return;
        capturing = true;
        glr.snapshot(this::showShotNow);              // thumbnail appears instantly, not after saving
        flashCover.setAlpha(0.85f);
        flashCover.animate().alpha(0).setDuration(260).start();
        frame.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        // a flash photo is a single frame (the flash can't fire for every burst frame)
        boolean flashFires = hasFlash && !night && !video && (flashMode == 2 || (flashMode == 1 && dark()));
        fireFlash = flashFires;
        final boolean useHdr = (hdr || night) && yuv != null && !flashFires;
        if (useHdr) showProcessing(true);
        lockThen(() -> { if (useHdr) burst(); else single(); });
    }

    private void hq(CaptureRequest.Builder b) {
        b.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY);
        b.set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY);
        b.set(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE, CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY);
        b.set(CaptureRequest.HOT_PIXEL_MODE, CaptureRequest.HOT_PIXEL_MODE_HIGH_QUALITY);
        b.set(CaptureRequest.TONEMAP_MODE, CaptureRequest.TONEMAP_MODE_HIGH_QUALITY);
        b.set(CaptureRequest.SHADING_MODE, CaptureRequest.SHADING_MODE_HIGH_QUALITY);
    }

    void single() {
        try {
            CaptureRequest.Builder b = dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            b.addTarget(reader.getSurface());
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            b.set(CaptureRequest.CONTROL_AE_MODE, aeMode());
            common(b);
            hq(b);
            b.set(CaptureRequest.JPEG_QUALITY, (byte) 98);
            b.set(CaptureRequest.JPEG_ORIENTATION, captureDeg());
            ses.capture(b.build(), stillCb, bg);
            if (fireFlash && bg != null) bg.postDelayed(this::flashOff, 2500);   // safety net
        } catch (Throwable t) {
            a.ui.post(() -> { capturing = false; fireFlash = false; savingShot = false; showProcessing(false); a.toast("Couldn't take the photo"); });
        }
    }

    // ------------------------------------------------------------------ HDR+ burst

    final ExecutorService work = Executors.newSingleThreadExecutor();
    HdrMerge merge;
    int burstLeft, burstDeg;
    boolean finishing;
    Filter burstFilter;

    void burst() {
        try {
            int iso = lastIso;
            long exp = lastExp;
            boolean nightShot = night;
            int frames = nightShot ? (iso >= 3200 ? 12 : 10) : iso >= 1600 ? 8 : iso >= 640 ? 7 : 6;
            float under = 1f, boost = 1f;
            boolean manual = manualOk;
            if (manual) {
                if (nightShot) {
                    // night: longer exposures at lower ISO (much less noise), merged across many frames
                    int isoN = Math.max(50, iso / 3);
                    long expN = Math.min(125_000_000L, exp * iso / isoN);
                    iso = Math.max(50, (int) (exp * (long) iso / expN));
                    exp = expN;
                    boost = 1.3f;                                     // night photos are brightened beyond the meter
                } else {
                    under = 0.72f;                                    // a bit darker → highlights are kept
                    if (iso > 800 && exp < 50_000_000L) { exp = Math.min(exp * 2, 90_000_000L); iso = Math.max(50, iso / 2); }
                    exp = Math.max(100_000L, (long) (exp * under));
                }
            } else if (nightShot) {
                boost = 1.3f;
            }
            merge = new HdrMerge(ySize.getWidth(), ySize.getHeight(), boost / under, nightShot);
            burstLeft = frames;
            finishing = false;
            burstDeg = captureDeg();
            burstFilter = filter;
            List<CaptureRequest> reqs = new ArrayList<>();
            for (int i = 0; i < frames; i++) {
                CaptureRequest.Builder b = dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                b.addTarget(yuv.getSurface());
                b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO);
                b.set(CaptureRequest.CONTROL_AWB_LOCK, true);
                if (manual) {
                    b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF);
                    b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exp);
                    b.set(CaptureRequest.SENSOR_SENSITIVITY, iso);
                } else {
                    b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                    b.set(CaptureRequest.CONTROL_AE_LOCK, true);
                }
                common(b);
                hq(b);
                reqs.add(b.build());
            }
            ses.captureBurst(reqs, null, bg);
            final HdrMerge m = merge;
            a.ui.postDelayed(() -> { if (merge == m && !finishing) work.execute(this::finishBurst); }, nightShot ? 9000 : 7000);   // safety net
        } catch (Throwable t) {
            merge = null;
            single();
        }
    }

    void onYuv(ImageReader r) {
        Image img;
        try { img = r.acquireNextImage(); } catch (Throwable t) { return; }
        if (img == null) return;
        final HdrMerge m = merge;
        if (m == null) { img.close(); return; }
        work.execute(() -> {
            try { if (!finishing && merge == m) m.add(img); }
            catch (Throwable ignored) { }
            finally { img.close(); }
            if (merge == m && --burstLeft <= 0) finishBurst();
        });
    }

    void finishBurst() {
        HdrMerge m = merge;
        if (m == null || finishing) return;
        finishing = true;
        byte[] bytes = null;
        try {
            if (m.n > 0) {
                Bitmap b = m.finish();
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream(8 << 20);
                b.compress(Bitmap.CompressFormat.JPEG, 96, bos);
                b.recycle();
                bytes = bos.toByteArray();
            }
        } catch (Throwable ignored) { }
        merge = null;
        final byte[] fb = bytes;
        final Filter f = burstFilter;
        final int deg = burstDeg;
        a.ui.post(() -> {
            showProcessing(false);
            capturing = false;
            if (bg != null) bg.post(this::unlock);
            if (fb == null) { savingShot = false; a.toast("Couldn't take the photo"); return; }
            a.cameraCaptured(fb, f, deg);
        });
    }

    void onJpeg(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) return;
            ByteBuffer buf = img.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buf.remaining()];
            buf.get(bytes);
            final Filter f = filter;
            a.ui.post(() -> {
                capturing = false;
                showProcessing(false);
                if (bg != null) bg.post(this::unlock);
                a.cameraCaptured(bytes, f, 0);
            });
        } catch (Throwable t) {
            a.ui.post(() -> { capturing = false; fireFlash = false; savingShot = false; showProcessing(false); a.toast("Couldn't take the photo"); });
        } finally {
            if (img != null) img.close();
        }
    }
}
