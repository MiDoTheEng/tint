package app.tint;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.*;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Size;
import android.view.*;
import android.widget.*;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * In-app camera with the filter shown live on the preview (Android's own Camera2, no libraries).
 * Swipe the preview to change filter; the shutter saves the filtered photo and opens it in the editor.
 */
final class CameraUI implements TextureView.SurfaceTextureListener {
    static final int REQ_CAMERA = 77;

    final MainActivity a;
    FrameLayout root;
    TextureView tv;
    ImageView fx;
    Views.AspectFrame frame;
    TextView nameFlash, torchBtn;
    LinearLayout filterRow, catRow;
    HorizontalScrollView filterScroll;
    View flashCover;

    CameraDevice dev;
    CameraCaptureSession ses;
    ImageReader reader;
    HandlerThread thread;
    Handler bg;
    Size pSize, jSize;
    int sensorOrient;
    boolean front, torch, shown, capturing;
    int deviceDeg;
    OrientationEventListener orient;

    Filter filter;
    String cat = "All";
    final List<TextView> chips = new ArrayList<>();
    final List<TextView> catChips = new ArrayList<>();
    final ExecutorService proc = Executors.newSingleThreadExecutor();
    volatile boolean busy;
    Bitmap lastOut;

    CameraUI(MainActivity a) { this.a = a; }

    int dp(float v) { return a.dp(v); }

    // ------------------------------------------------------------------ layout

    View build() {
        root = new FrameLayout(a);
        root.setBackgroundColor(Color.BLACK);
        root.setClickable(true);
        root.setVisibility(View.GONE);

        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
        col.setOnApplyWindowInsetsListener((v, ins) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(i.left, i.top, i.right, i.bottom + dp(8));
            } else {
                v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom() + dp(8));
            }
            return ins;
        });

        // top bar
        LinearLayout top = new LinearLayout(a);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(4), dp(12), dp(8));
        TextView close = roundBtn("✕");
        close.setOnClickListener(v -> close());
        top.addView(close);
        top.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
        torchBtn = roundBtn("⚡");
        torchBtn.setOnClickListener(v -> { torch = !torch; refreshTorch(); restartPreview(); });
        top.addView(torchBtn);
        col.addView(top);

        // preview
        FrameLayout holder = new FrameLayout(a);
        frame = new Views.AspectFrame(a);
        frame.setRatio(3f / 4f);
        frame.setBackground(a.round(0xFF111114, dp(22)));
        frame.setClipToOutline(true);
        tv = new TextureView(a);
        tv.setSurfaceTextureListener(this);
        frame.addView(tv, new FrameLayout.LayoutParams(-1, -1));
        fx = new ImageView(a);
        fx.setScaleType(ImageView.ScaleType.FIT_XY);
        frame.addView(fx, new FrameLayout.LayoutParams(-1, -1));
        nameFlash = new TextView(a);
        nameFlash.setTextColor(Color.WHITE);
        nameFlash.setTextSize(22);
        nameFlash.setLetterSpacing(0.12f);
        nameFlash.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        nameFlash.setShadowLayer(dp(8), 0, 0, 0xAA000000);
        nameFlash.setAlpha(0);
        frame.addView(nameFlash, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        flashCover = new View(a);
        flashCover.setBackgroundColor(Color.WHITE);
        flashCover.setAlpha(0);
        frame.addView(flashCover, new FrameLayout.LayoutParams(-1, -1));
        holder.addView(frame, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, 0, 1f);
        hp.setMargins(dp(6), 0, dp(6), dp(8));
        col.addView(holder, hp);

        GestureDetector swipe = new GestureDetector(a, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (Math.abs(vx) > Math.abs(vy) && Math.abs(vx) > 400) { step(vx < 0 ? 1 : -1); return true; }
                return false;
            }
        });
        frame.setOnTouchListener((v, e) -> swipe.onTouchEvent(e));

        // categories
        catRow = new LinearLayout(a);
        catRow.setPadding(dp(12), 0, dp(12), dp(4));
        for (String c : Filters.CATEGORIES) {
            TextView t = new TextView(a);
            t.setText(c);
            t.setTextSize(12);
            t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            t.setPadding(dp(12), dp(5), dp(12), dp(5));
            t.setTag(c);
            t.setOnClickListener(v -> { cat = c; buildFilterRow(); });
            catRow.addView(t);
            catChips.add(t);
        }
        col.addView(a.hscroll(catRow));

        // filters
        filterRow = new LinearLayout(a);
        filterRow.setPadding(dp(12), dp(4), dp(12), dp(4));
        filterScroll = a.hscroll(filterRow);
        col.addView(filterScroll);

        // shutter row
        LinearLayout shut = new LinearLayout(a);
        shut.setGravity(Gravity.CENTER_VERTICAL);
        shut.setPadding(dp(30), dp(10), dp(30), dp(6));
        View spacer = new View(a);
        shut.addView(spacer, new LinearLayout.LayoutParams(dp(48), dp(48)));
        shut.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
        FrameLayout shutter = new FrameLayout(a);
        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setStroke(dp(4), Color.WHITE);
        shutter.setBackground(ring);
        View inner = new View(a);
        GradientDrawable in = new GradientDrawable();
        in.setShape(GradientDrawable.OVAL);
        in.setColor(Color.WHITE);
        inner.setBackground(in);
        shutter.addView(inner, new FrameLayout.LayoutParams(dp(60), dp(60), Gravity.CENTER));
        shutter.setOnClickListener(v -> {
            inner.animate().scaleX(.85f).scaleY(.85f).setDuration(80).withEndAction(() ->
                    inner.animate().scaleX(1).scaleY(1).setDuration(120).start()).start();
            capture();
        });
        shut.addView(shutter, new LinearLayout.LayoutParams(dp(76), dp(76)));
        shut.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
        TextView flip = roundBtn("⟲");
        flip.setTextSize(22);
        flip.setOnClickListener(v -> {
            front = !front;
            v.animate().rotationBy(180).setDuration(250).start();
            restartCamera();
        });
        shut.addView(flip, new LinearLayout.LayoutParams(dp(48), dp(48)));
        col.addView(shut);

        orient = new OrientationEventListener(a) {
            @Override public void onOrientationChanged(int o) {
                if (o != ORIENTATION_UNKNOWN) deviceDeg = ((o + 45) / 90 * 90) % 360;
            }
        };
        return root;
    }

    TextView roundBtn(String s) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(17);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0x33FFFFFF);
        t.setBackground(g);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        return t;
    }

    void refreshTorch() {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(torch ? 0xFFFFC93B : 0x33FFFFFF);
        torchBtn.setBackground(g);
        torchBtn.setTextColor(torch ? Color.BLACK : Color.WHITE);
    }

    List<Filter> list() {
        List<Filter> l = new ArrayList<>();
        for (Filter f : a.all)
            if (f.isOriginal() || cat.equals("All") || f.cat.equals(cat)
                    || (cat.equals(Filters.FAV) && a.favs.contains(f.name))) l.add(f);
        return l;
    }

    void buildFilterRow() {
        for (TextView t : catChips) {
            boolean sel = t.getTag().equals(cat);
            t.setBackground(sel ? a.round(Color.WHITE, dp(100)) : null);
            t.setTextColor(sel ? Color.BLACK : 0xFF8B8B92);
        }
        filterRow.removeAllViews();
        chips.clear();
        for (Filter f : list()) {
            TextView t = new TextView(a);
            t.setText(f.name);
            t.setTextSize(12);
            t.setLetterSpacing(0.06f);
            t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            t.setPadding(dp(14), dp(8), dp(14), dp(8));
            t.setTag(f);
            t.setOnClickListener(v -> setFilter(f, false));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.setMargins(dp(3), 0, dp(3), 0);
            filterRow.addView(t, lp);
            chips.add(t);
        }
        refreshChips();
        filterScroll.scrollTo(0, 0);
    }

    void refreshChips() {
        for (TextView t : chips) {
            boolean sel = t.getTag() == filter;
            t.setBackground(a.round(sel ? 0xFFFF4D2E : 0x26FFFFFF, dp(100)));
            t.setTextColor(Color.WHITE);
            if (sel) t.post(() -> filterScroll.smoothScrollTo(Math.max(0, t.getLeft() - dp(120)), 0));
        }
    }

    void step(int dir) {
        List<Filter> l = list();
        int i = Math.max(0, l.indexOf(filter));
        setFilter(l.get((i + dir + l.size()) % l.size()), true);
    }

    void setFilter(Filter f, boolean announce) {
        filter = f;
        refreshChips();
        if (f.isOriginal()) { fx.setVisibility(View.INVISIBLE); }
        tv.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        nameFlash.setText(f.name);
        nameFlash.animate().cancel();
        nameFlash.setAlpha(1);
        nameFlash.animate().alpha(0).setStartDelay(650).setDuration(350).start();
    }

    // ------------------------------------------------------------------ show / hide

    void open() {
        if (a.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            a.requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            return;
        }
        if (filter == null) filter = a.current;
        shown = true;
        root.setVisibility(View.VISIBLE);
        root.setAlpha(0);
        root.animate().alpha(1).setDuration(180).start();
        buildFilterRow();
        refreshTorch();
        if (orient.canDetectOrientation()) orient.enable();
        start();
        a.ui.post(tick);
    }

    void close() {
        shown = false;
        stop();
        orient.disable();
        root.setVisibility(View.GONE);
        fx.setImageBitmap(null);
        if (lastOut != null) { lastOut.recycle(); lastOut = null; }
    }

    void start() {
        if (thread == null) {
            thread = new HandlerThread("tint-camera");
            thread.start();
            bg = new Handler(thread.getLooper());
        }
        if (tv.isAvailable()) openCamera();
    }

    void stop() {
        try { if (ses != null) ses.close(); } catch (Throwable ignored) { }
        try { if (dev != null) dev.close(); } catch (Throwable ignored) { }
        try { if (reader != null) reader.close(); } catch (Throwable ignored) { }
        ses = null; dev = null; reader = null;
        if (thread != null) { thread.quitSafely(); thread = null; bg = null; }
    }

    void restartCamera() { if (!shown) return; stop(); start(); }

    // ------------------------------------------------------------------ camera

    private static Size pick(Size[] sizes, int maxW) {
        Size best = null;
        for (Size s : sizes) {
            float r = (float) s.getWidth() / s.getHeight();
            if (Math.abs(r - 4f / 3f) > 0.02f) continue;
            if (maxW > 0 && s.getWidth() > maxW) continue;
            if (best == null || (long) s.getWidth() * s.getHeight() > (long) best.getWidth() * best.getHeight()) best = s;
        }
        if (best == null) best = sizes[0];
        return best;
    }

    void openCamera() {
        try {
            CameraManager cm = (CameraManager) a.getSystemService(Context.CAMERA_SERVICE);
            String id = null;
            for (String c : cm.getCameraIdList()) {
                Integer facing = cm.getCameraCharacteristics(c).get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == (front ? CameraCharacteristics.LENS_FACING_FRONT : CameraCharacteristics.LENS_FACING_BACK)) { id = c; break; }
            }
            if (id == null) id = cm.getCameraIdList()[0];
            CameraCharacteristics ch = cm.getCameraCharacteristics(id);
            StreamConfigurationMap map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Integer so = ch.get(CameraCharacteristics.SENSOR_ORIENTATION);
            sensorOrient = so == null ? 90 : so;
            pSize = pick(map.getOutputSizes(SurfaceTexture.class), 1920);
            jSize = pick(map.getOutputSizes(ImageFormat.JPEG), 0);
            reader = ImageReader.newInstance(jSize.getWidth(), jSize.getHeight(), ImageFormat.JPEG, 2);
            reader.setOnImageAvailableListener(this::onJpeg, bg);
            a.ui.post(this::layoutPreview);
            cm.openCamera(id, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice c) { dev = c; createSession(); }
                @Override public void onDisconnected(CameraDevice c) { c.close(); dev = null; }
                @Override public void onError(CameraDevice c, int e) {
                    c.close();
                    dev = null;
                    a.ui.post(() -> a.toast("Camera is busy or unavailable"));
                }
            }, bg);
        } catch (SecurityException e) {
            a.toast("Camera permission is needed");
        } catch (Throwable t) {
            a.toast("Couldn't open the camera");
        }
    }

    int displayRotation() {
        Display d = Build.VERSION.SDK_INT >= 30 ? a.getDisplay() : a.getWindowManager().getDefaultDisplay();
        return d == null ? Surface.ROTATION_0 : d.getRotation();
    }

    /** Fits the preview to the frame (handles tablets in landscape too). */
    void layoutPreview() {
        if (pSize == null) return;
        int rot = displayRotation();
        boolean landscape = rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270;
        frame.setRatio(landscape ? (float) pSize.getWidth() / pSize.getHeight() : (float) pSize.getHeight() / pSize.getWidth());
        tv.setScaleX(front ? -1 : 1);
        fx.setScaleX(front ? -1 : 1);
        tv.post(() -> {
            int vw = tv.getWidth(), vh = tv.getHeight();
            if (vw == 0 || vh == 0) return;
            Matrix m = new Matrix();
            RectF view = new RectF(0, 0, vw, vh);
            float cx = view.centerX(), cy = view.centerY();
            if (landscape) {
                RectF buf = new RectF(0, 0, pSize.getHeight(), pSize.getWidth());
                buf.offset(cx - buf.centerX(), cy - buf.centerY());
                m.setRectToRect(view, buf, Matrix.ScaleToFit.FILL);
                float s = Math.max((float) vh / pSize.getHeight(), (float) vw / pSize.getWidth());
                m.postScale(s, s, cx, cy);
                m.postRotate(90 * (rot - 2), cx, cy);
            } else if (rot == Surface.ROTATION_180) {
                m.postRotate(180, cx, cy);
            }
            tv.setTransform(m);
        });
    }

    void createSession() {
        try {
            SurfaceTexture st = tv.getSurfaceTexture();
            if (st == null || dev == null) return;
            st.setDefaultBufferSize(pSize.getWidth(), pSize.getHeight());
            Surface s = new Surface(st);
            CameraDevice d = dev;
            d.createCaptureSession(Arrays.asList(s, reader.getSurface()), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession c) {
                    if (dev == null) return;
                    ses = c;
                    previewTarget = s;
                    restartPreview();
                }
                @Override public void onConfigureFailed(CameraCaptureSession c) {
                    a.ui.post(() -> a.toast("Couldn't start the camera"));
                }
            }, bg);
        } catch (Throwable t) {
            a.ui.post(() -> a.toast("Couldn't start the camera"));
        }
    }

    Surface previewTarget;

    void restartPreview() {
        if (ses == null || dev == null || previewTarget == null) return;
        try {
            CaptureRequest.Builder b = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            b.addTarget(previewTarget);
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            b.set(CaptureRequest.FLASH_MODE, torch ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
            ses.setRepeatingRequest(b.build(), null, bg);
        } catch (Throwable ignored) { }
    }

    void capture() {
        if (ses == null || dev == null || capturing) return;
        capturing = true;
        flashCover.setAlpha(0.85f);
        flashCover.animate().alpha(0).setDuration(260).start();
        tv.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        try {
            CaptureRequest.Builder b = dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            b.addTarget(reader.getSurface());
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            b.set(CaptureRequest.FLASH_MODE, torch ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
            b.set(CaptureRequest.JPEG_QUALITY, (byte) 97);
            int turn = front ? -deviceDeg : deviceDeg;
            b.set(CaptureRequest.JPEG_ORIENTATION, (sensorOrient + turn + 360) % 360);
            ses.capture(b.build(), null, bg);
        } catch (Throwable t) {
            capturing = false;
            a.toast("Couldn't take the photo");
        }
    }

    void onJpeg(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) return;
            ByteBuffer buf = img.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buf.remaining()];
            buf.get(bytes);
            final Filter f = filter;
            a.ui.post(() -> {
                capturing = false;
                a.cameraCaptured(bytes, f);
            });
        } catch (Throwable t) {
            a.ui.post(() -> { capturing = false; a.toast("Couldn't take the photo"); });
        } finally {
            if (img != null) img.close();
        }
    }

    // ------------------------------------------------------------------ live filter

    final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!shown) return;
            Filter f = filter;
            if (f != null && !f.isOriginal() && !busy && tv.isAvailable() && ses != null && tv.getWidth() > 0) {
                busy = true;
                int gw = Math.min(tv.getWidth(), 540), gh = Math.max(1, Math.round((float) gw * tv.getHeight() / tv.getWidth()));
                Bitmap b;
                try { b = tv.getBitmap(gw, gh); } catch (Throwable t) { b = null; }
                if (b == null) {
                    busy = false;
                } else {
                    final Bitmap src = b;
                    proc.execute(() -> {
                        Bitmap out;
                        try { out = Renderer.render(src, f); } catch (Throwable t) { out = null; }
                        src.recycle();
                        final Bitmap o = out;
                        a.ui.post(() -> {
                            busy = false;
                            if (o == null) return;
                            if (!shown || filter != f) { o.recycle(); return; }
                            Bitmap old = lastOut;
                            fx.setImageBitmap(o);
                            fx.setVisibility(View.VISIBLE);
                            lastOut = o;
                            if (old != null) old.recycle();
                        });
                    });
                }
            }
            a.ui.postDelayed(this, 33);
        }
    };

    // ------------------------------------------------------------------ TextureView callbacks

    @Override public void onSurfaceTextureAvailable(SurfaceTexture s, int w, int h) { if (shown && dev == null) openCamera(); }
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture s, int w, int h) { layoutPreview(); }
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture s) { return true; }
    @Override public void onSurfaceTextureUpdated(SurfaceTexture s) { }
}
