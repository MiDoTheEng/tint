package app.tint;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.*;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Size;
import android.view.*;
import android.widget.*;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * In-app camera with the filter shown live on the preview (Android's own Camera2, no libraries).
 * Swipe the preview to change filter; the shutter saves the filtered photo and opens it in the editor.
 */
final class CameraUI {
    static final int REQ_CAMERA = 77;

    final MainActivity a;
    FrameLayout root;
    android.opengl.GLSurfaceView gl;
    CameraGL glr;
    SurfaceTexture st;
    Views.AspectFrame frame;
    TextView nameFlash, torchBtn, hdrBtn, procView;
    LinearLayout lensRow;
    boolean hdr = true;
    LinearLayout filterRow, catRow;
    HorizontalScrollView filterScroll;
    View flashCover;

    CameraDevice dev;
    CameraCaptureSession ses;
    ImageReader reader;
    HandlerThread thread;
    Handler bg;
    Size pSize, jSize;
    int sensorOrient;
    boolean front, torch, shown, capturing;
    int deviceDeg;
    OrientationEventListener orient;

    Filter filter;
    String cat = "All";
    final List<TextView> chips = new ArrayList<>();
    final List<TextView> catChips = new ArrayList<>();

    CameraUI(MainActivity a) { this.a = a; }

    int dp(float v) { return a.dp(v); }

    // ------------------------------------------------------------------ layout

    View build() {
        root = new FrameLayout(a);
        root.setBackgroundColor(Color.BLACK);
        root.setClickable(true);
        root.setVisibility(View.GONE);

        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
        col.setOnApplyWindowInsetsListener((v, ins) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(i.left, i.top, i.right, i.bottom + dp(8));
            } else {
                v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom() + dp(8));
            }
            return ins;
        });

        // top bar
        LinearLayout top = new LinearLayout(a);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(4), dp(12), dp(8));
        TextView close = roundBtn("✕");
        close.setOnClickListener(v -> close());
        top.addView(close);
        top.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
        hdrBtn = new TextView(a);
        hdrBtn.setText("HDR+");
        hdrBtn.setTextSize(12);
        hdrBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        hdrBtn.setGravity(Gravity.CENTER);
        hdrBtn.setPadding(dp(14), dp(8), dp(14), dp(8));
        hdrBtn.setOnClickListener(v -> {
            hdr = !hdr;
            try { a.getSharedPreferences("tint", Context.MODE_PRIVATE).edit().putBoolean("hdr", hdr).apply(); } catch (Throwable ignored) { }
            refreshHdr();
            a.toast(hdr ? "HDR+ on: clearer, more detailed photos" : "HDR+ off: faster single shots");
        });
        LinearLayout.LayoutParams hbp = new LinearLayout.LayoutParams(-2, -2);
        hbp.setMargins(0, 0, dp(10), 0);
        top.addView(hdrBtn, hbp);
        torchBtn = roundBtn("⚡");
        torchBtn.setOnClickListener(v -> { torch = !torch; refreshTorch(); restartPreview(); });
        top.addView(torchBtn);
        col.addView(top);

        // preview
        FrameLayout holder = new FrameLayout(a);
        frame = new Views.AspectFrame(a);
        frame.setRatio(3f / 4f);
        frame.setBackgroundColor(0xFF111114);
        gl = new android.opengl.GLSurfaceView(a);
        gl.setEGLContextClientVersion(3);
        gl.setPreserveEGLContextOnPause(true);
        glr = new CameraGL(gl, s -> {
            boolean changed = st != null && st != s;
            st = s;
            if (!shown) return;
            if (changed && dev != null) restartCamera();      // GPU surface was recreated: reconnect the camera
            else if (dev == null && thread != null) openCamera();
        });
        gl.setRenderer(glr);
        gl.setRenderMode(android.opengl.GLSurfaceView.RENDERMODE_WHEN_DIRTY);
        frame.addView(gl, new FrameLayout.LayoutParams(-1, -1));
        nameFlash = new TextView(a);
        nameFlash.setTextColor(Color.WHITE);
        nameFlash.setTextSize(22);
        nameFlash.setLetterSpacing(0.12f);
        nameFlash.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        nameFlash.setShadowLayer(dp(8), 0, 0, 0xAA000000);
        nameFlash.setAlpha(0);
        frame.addView(nameFlash, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        flashCover = new View(a);
        flashCover.setBackgroundColor(Color.WHITE);
        flashCover.setAlpha(0);
        frame.addView(flashCover, new FrameLayout.LayoutParams(-1, -1));
        lensRow = new LinearLayout(a);
        lensRow.setGravity(Gravity.CENTER);
        lensRow.setPadding(dp(6), dp(4), dp(6), dp(4));
        lensRow.setBackground(a.round(0x40000000, dp(100)));
        FrameLayout.LayoutParams lrp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        lrp.bottomMargin = dp(14);
        frame.addView(lensRow, lrp);
        procView = new TextView(a);
        procView.setText("HDR+ · hold still…");
        procView.setTextColor(Color.WHITE);
        procView.setTextSize(13);
        procView.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        procView.setPadding(dp(16), dp(8), dp(16), dp(8));
        procView.setBackground(a.round(0xB3000000, dp(100)));
        procView.setVisibility(View.GONE);
        FrameLayout.LayoutParams pvp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        pvp.topMargin = dp(14);
        frame.addView(procView, pvp);
        holder.addView(frame, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, 0, 1f);
        hp.setMargins(dp(6), 0, dp(6), dp(8));
        col.addView(holder, hp);

        GestureDetector swipe = new GestureDetector(a, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (Math.abs(vx) > Math.abs(vy) && Math.abs(vx) > 400) { step(vx < 0 ? 1 : -1); return true; }
                return false;
            }
        });
        ScaleGestureDetector zoomer = new ScaleGestureDetector(a, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) { pinch(d.getScaleFactor()); return true; }
        });
        frame.setOnTouchListener((v, e) -> {
            zoomer.onTouchEvent(e);
            if (!zoomer.isInProgress() && e.getPointerCount() == 1) swipe.onTouchEvent(e);
            return true;
        });

        // categories
        catRow = new LinearLayout(a);
        catRow.setPadding(dp(12), 0, dp(12), dp(4));
        for (String c : Filters.CATEGORIES) {
            TextView t = new TextView(a);
            t.setText(c);
            t.setTextSize(12);
            t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            t.setPadding(dp(12), dp(5), dp(12), dp(5));
            t.setTag(c);
            t.setOnClickListener(v -> { cat = c; buildFilterRow(); });
            catRow.addView(t);
            catChips.add(t);
        }
        col.addView(a.hscroll(catRow));

        // filters
        filterRow = new LinearLayout(a);
        filterRow.setPadding(dp(12), dp(4), dp(12), dp(4));
        filterScroll = a.hscroll(filterRow);
        col.addView(filterScroll);

        // shutter row
        LinearLayout shut = new LinearLayout(a);
        shut.setGravity(Gravity.CENTER_VERTICAL);
        shut.setPadding(dp(30), dp(10), dp(30), dp(6));
        View spacer = new View(a);
        shut.addView(spacer, new LinearLayout.LayoutParams(dp(48), dp(48)));
        shut.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
        FrameLayout shutter = new FrameLayout(a);
        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setStroke(dp(4), Color.WHITE);
        shutter.setBackground(ring);
        View inner = new View(a);
        GradientDrawable in = new GradientDrawable();
        in.setShape(GradientDrawable.OVAL);
        in.setColor(Color.WHITE);
        inner.setBackground(in);
        shutter.addView(inner, new FrameLayout.LayoutParams(dp(60), dp(60), Gravity.CENTER));
        shutter.setOnClickListener(v -> {
            inner.animate().scaleX(.85f).scaleY(.85f).setDuration(80).withEndAction(() ->
                    inner.animate().scaleX(1).scaleY(1).setDuration(120).start()).start();
            capture();
        });
        shut.addView(shutter, new LinearLayout.LayoutParams(dp(76), dp(76)));
        shut.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
        TextView flip = roundBtn("⟲");
        flip.setTextSize(22);
        flip.setOnClickListener(v -> {
            front = !front;
            lensOverride = null;
            zoom = 1;
            lenses.clear();
            v.animate().rotationBy(180).setDuration(250).start();
            restartCamera();
        });
        shut.addView(flip, new LinearLayout.LayoutParams(dp(48), dp(48)));
        col.addView(shut);

        orient = new OrientationEventListener(a) {
            @Override public void onOrientationChanged(int o) {
                if (o != ORIENTATION_UNKNOWN) deviceDeg = ((o + 45) / 90 * 90) % 360;
            }
        };
        return root;
    }

    void refreshHdr() {
        boolean avail = yuv != null || ySize == null;
        hdrBtn.setVisibility(yuvOk ? View.VISIBLE : View.GONE);
        hdrBtn.setBackground(a.round(hdr ? 0xFFFFC93B : 0x33FFFFFF, dp(100)));
        hdrBtn.setTextColor(hdr ? Color.BLACK : Color.WHITE);
        hdrBtn.setAlpha(avail ? 1f : 0.5f);
    }

    void showProcessing(boolean on) {
        procView.animate().cancel();
        if (on) {
            procView.setText("HDR+ · hold still…");
            procView.setVisibility(View.VISIBLE);
            procView.setAlpha(1);
            procView.animate().alpha(0.55f).setDuration(600).withEndAction(() -> {
                if (procView.getVisibility() == View.VISIBLE) procView.animate().alpha(1).setDuration(600).start();
            }).start();
        } else {
            procView.setVisibility(View.GONE);
        }
    }

    TextView roundBtn(String s) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(17);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0x33FFFFFF);
        t.setBackground(g);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        return t;
    }

    void refreshTorch() {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(torch ? 0xFFFFC93B : 0x33FFFFFF);
        torchBtn.setBackground(g);
        torchBtn.setTextColor(torch ? Color.BLACK : Color.WHITE);
    }

    List<Filter> list() {
        List<Filter> l = new ArrayList<>();
        for (Filter f : a.all)
            if (f.isOriginal() || cat.equals("All") || f.cat.equals(cat)
                    || (cat.equals(Filters.FAV) && a.favs.contains(f.name))) l.add(f);
        return l;
    }

    void buildFilterRow() {
        for (TextView t : catChips) {
            boolean sel = t.getTag().equals(cat);
            t.setBackground(sel ? a.round(Color.WHITE, dp(100)) : null);
            t.setTextColor(sel ? Color.BLACK : 0xFF8B8B92);
        }
        filterRow.removeAllViews();
        chips.clear();
        for (Filter f : list()) {
            TextView t = new TextView(a);
            t.setText(f.name);
            t.setTextSize(12);
            t.setLetterSpacing(0.06f);
            t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            t.setPadding(dp(14), dp(8), dp(14), dp(8));
            t.setTag(f);
            t.setOnClickListener(v -> setFilter(f, false));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.setMargins(dp(3), 0, dp(3), 0);
            filterRow.addView(t, lp);
            chips.add(t);
        }
        refreshChips();
        filterScroll.scrollTo(0, 0);
    }

    void refreshChips() {
        for (TextView t : chips) {
            boolean sel = t.getTag() == filter;
            t.setBackground(a.round(sel ? 0xFFFF4D2E : 0x26FFFFFF, dp(100)));
            t.setTextColor(Color.WHITE);
            if (sel) t.post(() -> filterScroll.smoothScrollTo(Math.max(0, t.getLeft() - dp(120)), 0));
        }
    }

    void step(int dir) {
        List<Filter> l = list();
        int i = Math.max(0, l.indexOf(filter));
        setFilter(l.get((i + dir + l.size()) % l.size()), true);
    }

    void setFilter(Filter f, boolean announce) {
        filter = f;
        refreshChips();
        glr.setFilter(f);
        frame.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        nameFlash.setText(f.name);
        nameFlash.animate().cancel();
        nameFlash.setAlpha(1);
        nameFlash.animate().alpha(0).setStartDelay(650).setDuration(350).start();
    }

    // ------------------------------------------------------------------ show / hide

    void open() {
        if (a.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            a.requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            return;
        }
        if (filter == null) filter = a.current;
        try { hdr = a.getSharedPreferences("tint", Context.MODE_PRIVATE).getBoolean("hdr", true); } catch (Throwable ignored) { }
        shown = true;
        root.setVisibility(View.VISIBLE);
        root.setAlpha(0);
        root.animate().alpha(1).setDuration(180).start();
        buildFilterRow();
        refreshTorch();
        refreshHdr();
        if (orient.canDetectOrientation()) orient.enable();
        glr.setFilter(filter);
        gl.onResume();
        start();
    }

    void close() {
        shown = false;
        stop();
        orient.disable();
        gl.onPause();
        root.setVisibility(View.GONE);
    }

    void start() {
        if (thread == null) {
            thread = new HandlerThread("tint-camera");
            thread.start();
            bg = new Handler(thread.getLooper());
        }
        if (st != null) openCamera();
    }

    void stop() {
        try { if (ses != null) ses.close(); } catch (Throwable ignored) { }
        try { if (dev != null) dev.close(); } catch (Throwable ignored) { }
        try { if (reader != null) reader.close(); } catch (Throwable ignored) { }
        try { if (yuv != null) yuv.close(); } catch (Throwable ignored) { }
        ses = null; dev = null; reader = null; yuv = null; merge = null; capturing = false; awaitingLock = false;
        if (thread != null) { thread.quitSafely(); thread = null; bg = null; }
    }

    void pause() { stop(); gl.onPause(); }

    void resume() { gl.onResume(); start(); }

    void restartCamera() { if (!shown) return; stop(); start(); }

    // ------------------------------------------------------------------ camera

    private static Size pick(Size[] sizes, int maxW) {
        Size best = null;
        for (Size s : sizes) {
            float r = (float) s.getWidth() / s.getHeight();
            if (Math.abs(r - 4f / 3f) > 0.02f) continue;
            if (maxW > 0 && s.getWidth() > maxW) continue;
            if (best == null || (long) s.getWidth() * s.getHeight() > (long) best.getWidth() * best.getHeight()) best = s;
        }
        if (best == null) best = sizes[0];
        return best;
    }

    // ------------------------------------------------------------------ lenses

    static final class Lens {
        final String id;       // null: same camera, use zoom ratio
        final float mul;
        Lens(String id, float mul) { this.id = id; this.mul = mul; }
    }

    final List<Lens> lenses = new ArrayList<>();
    String camId, lensOverride;
    float zoom = 1, zMin = 1, zMax = 1;
    boolean ratioApi, manualOk, yuvOk = true;

    private static float fovOf(CameraCharacteristics c) {
        float[] f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
        android.util.SizeF sz = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
        if (f == null || f.length == 0 || sz == null) return 0;
        return sz.getWidth() / f[0];
    }

    /** Works out which lenses this phone lets apps use: zoom ratios on one camera, or separate cameras. */
    void findLenses(CameraManager cm, String mainId) {
        lenses.clear();
        if (front) return;
        try {
            if (ratioApi && zMin < 0.95f) {
                lenses.add(new Lens(null, zMin));
                lenses.add(new Lens(null, 1f));
                if (zMax >= 2f) lenses.add(new Lens(null, 2f));
                if (zMax >= 5f) lenses.add(new Lens(null, 5f));
                return;
            }
            float mainFov = fovOf(cm.getCameraCharacteristics(mainId));
            List<Lens> found = new ArrayList<>();
            for (String c : cm.getCameraIdList()) {
                CameraCharacteristics ch = cm.getCameraCharacteristics(c);
                Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;
                float fov = fovOf(ch);
                if (fov <= 0 || mainFov <= 0) continue;
                float mul = Math.round(mainFov / fov * 10) / 10f;
                boolean dup = false;
                for (Lens l : found) if (Math.abs(l.mul - mul) < 0.15f) dup = true;
                if (!dup) found.add(new Lens(c.equals(mainId) ? null : c, mul));
            }
            found.sort((x, y) -> Float.compare(x.mul, y.mul));
            if (found.size() > 1) lenses.addAll(found);
            boolean hasTele = false;
            for (Lens l : lenses) if (l.mul >= 1.8f) hasTele = true;
            if (!hasTele && ratioApi && zMax >= 2f) {          // no separate telephoto: offer 2× zoom on the main camera
                if (lenses.isEmpty()) lenses.add(new Lens(null, 1f));
                lenses.add(new Lens(null, 2f));
            }
        } catch (Throwable ignored) { }
    }

    static String label(float m) {
        if (m < 1) return String.format(java.util.Locale.US, "%.1f", m).replace("0.", ".") + "×";
        return (m == Math.floor(m) ? String.valueOf((int) m) : String.format(java.util.Locale.US, "%.1f", m)) + "×";
    }

    void buildLensRow() {
        lensRow.removeAllViews();
        lensRow.setVisibility(lenses.size() > 1 ? View.VISIBLE : View.GONE);
        for (Lens l : lenses) {
            TextView t = new TextView(a);
            boolean sel = l.id != null ? l.id.equals(camId) && lensOverride != null
                    : (lensOverride == null && Math.abs(nearest() - l.mul) < 0.01f);
            String txt = sel && l.id == null && Math.abs(zoom - l.mul) > 0.05f ? label(Math.round(zoom * 10) / 10f) : label(l.mul);
            t.setText(txt);
            t.setTextSize(sel ? 12.5f : 11);
            t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            t.setGravity(Gravity.CENTER);
            t.setTextColor(sel ? 0xFFFFC93B : Color.WHITE);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(sel ? 0xCC000000 : 0x66000000);
            t.setBackground(g);
            t.setOnClickListener(v -> pickLens(l));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(sel ? 42 : 34), dp(sel ? 42 : 34));
            lp.setMargins(dp(4), 0, dp(4), 0);
            lp.gravity = Gravity.CENTER_VERTICAL;
            lensRow.addView(t, lp);
        }
    }

    /** The ratio lens closest to the current zoom (for highlighting). */
    float nearest() {
        float best = 1, d = 99;
        for (Lens l : lenses) if (l.id == null && Math.abs(l.mul - zoom) <= d && l.mul <= zoom + 0.05f) { d = Math.abs(l.mul - zoom); best = l.mul; }
        return best;
    }

    void pickLens(Lens l) {
        frame.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        if (l.id != null) {
            if (l.id.equals(lensOverride)) return;
            lensOverride = l.id;
            zoom = 1;
            restartCamera();
        } else if (lensOverride != null) {
            lensOverride = null;
            zoom = l.mul;
            restartCamera();
        } else {
            zoom = l.mul;
            restartPreview();
        }
        buildLensRow();
    }

    void pinch(float factor) {
        if (!ratioApi || zMax <= zMin) return;
        zoom = Math.max(zMin, Math.min(zMax, zoom * factor));
        restartPreview();
        buildLensRow();
    }

    // ------------------------------------------------------------------ camera

    ImageReader yuv;
    Size ySize;

    void openCamera() {
        try {
            CameraManager cm = (CameraManager) a.getSystemService(Context.CAMERA_SERVICE);
            String id = null;
            for (String c : cm.getCameraIdList()) {
                Integer facing = cm.getCameraCharacteristics(c).get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == (front ? CameraCharacteristics.LENS_FACING_FRONT : CameraCharacteristics.LENS_FACING_BACK)) { id = c; break; }
            }
            if (id == null) id = cm.getCameraIdList()[0];
            String mainId = id;
            if (!front && lensOverride != null) id = lensOverride;
            camId = id;
            CameraCharacteristics ch = cm.getCameraCharacteristics(id);
            StreamConfigurationMap map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Integer so = ch.get(CameraCharacteristics.SENSOR_ORIENTATION);
            sensorOrient = so == null ? 90 : so;
            ratioApi = false; zMin = 1; zMax = 1;
            if (Build.VERSION.SDK_INT >= 30) {
                android.util.Range<Float> r = ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);
                if (r != null) { ratioApi = true; zMin = r.getLower(); zMax = r.getUpper(); }
            }
            if (!ratioApi) {
                Float dz = ch.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
                zMax = dz == null ? 1 : dz;
            }
            zoom = Math.max(zMin, Math.min(zMax, zoom));
            manualOk = false;
            int[] caps = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
            if (caps != null) for (int c : caps) if (c == CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) manualOk = true;
            if (lenses.isEmpty() || front) findLenses(cm, mainId);
            pSize = pick(map.getOutputSizes(SurfaceTexture.class), 1920);
            jSize = pick(map.getOutputSizes(ImageFormat.JPEG), 0);
            Size[] ys = map.getOutputSizes(ImageFormat.YUV_420_888);
            ySize = ys == null || ys.length == 0 ? null : pick(ys, 0);
            if (ySize != null && (ySize.getWidth() % 16 != 0 || ySize.getHeight() % 16 != 0)) {
                ySize = new Size(ySize.getWidth() & ~15, ySize.getHeight() & ~15);
                boolean ok = false;
                for (Size z : ys) if (z.equals(ySize)) ok = true;
                if (!ok) ySize = null;
            }
            reader = ImageReader.newInstance(jSize.getWidth(), jSize.getHeight(), ImageFormat.JPEG, 2);
            reader.setOnImageAvailableListener(this::onJpeg, bg);
            yuv = null;
            if (ySize != null && yuvOk) {
                yuv = ImageReader.newInstance(ySize.getWidth(), ySize.getHeight(), ImageFormat.YUV_420_888, 10);
                yuv.setOnImageAvailableListener(this::onYuv, bg);
            }
            a.ui.post(() -> { layoutPreview(); buildLensRow(); refreshHdr(); });
            cm.openCamera(id, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice c) { dev = c; createSession(); }
                @Override public void onDisconnected(CameraDevice c) { c.close(); dev = null; }
                @Override public void onError(CameraDevice c, int e) {
                    c.close();
                    dev = null;
                    a.ui.post(() -> a.toast("Camera is busy or unavailable"));
                }
            }, bg);
        } catch (SecurityException e) {
            a.toast("Camera permission is needed");
        } catch (Throwable t) {
            a.toast("Couldn't open the camera");
        }
    }

    int displayRotation() {
        Display d = Build.VERSION.SDK_INT >= 30 ? a.getDisplay() : a.getWindowManager().getDefaultDisplay();
        return d == null ? Surface.ROTATION_0 : d.getRotation();
    }

    /** Fits the preview to the frame (handles tablets in landscape too). */
    void layoutPreview() {
        if (pSize == null) return;
        int rot = displayRotation();
        boolean landscape = rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270;
        frame.setRatio(landscape ? (float) pSize.getWidth() / pSize.getHeight() : (float) pSize.getHeight() / pSize.getWidth());
        glr.flipX = front;
        glr.rot = (float) Math.toRadians(rot == Surface.ROTATION_90 ? -90 : rot == Surface.ROTATION_270 ? 90 : rot == Surface.ROTATION_180 ? 180 : 0);
        gl.requestRender();
    }

    void createSession() {
        try {
            if (st == null || dev == null) return;
            st.setDefaultBufferSize(pSize.getWidth(), pSize.getHeight());
            Surface s = new Surface(st);
            CameraDevice d = dev;
            List<Surface> outs = new ArrayList<>(Arrays.asList(s, reader.getSurface()));
            final boolean withYuv = yuv != null;
            if (withYuv) outs.add(yuv.getSurface());
            d.createCaptureSession(outs, new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession c) {
                    if (dev == null) return;
                    ses = c;
                    previewTarget = s;
                    restartPreview();
                }
                @Override public void onConfigureFailed(CameraCaptureSession c) {
                    if (withYuv) {                       // this phone can't do the burst stream: use single shots
                        yuvOk = false;
                        a.ui.post(() -> restartCamera());
                    } else {
                        a.ui.post(() -> a.toast("Couldn't start the camera"));
                    }
                }
            }, bg);
        } catch (Throwable t) {
            a.ui.post(() -> a.toast("Couldn't start the camera"));
        }
    }

    Surface previewTarget;
    volatile int lastIso = 100;
    volatile long lastExp = 16_000_000L;
    volatile boolean awaitingLock;
    volatile long lockDeadline;
    volatile Runnable afterLock;

    private void common(CaptureRequest.Builder b) {
        if (ratioApi && Build.VERSION.SDK_INT >= 30) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom);
        b.set(CaptureRequest.FLASH_MODE, torch ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
    }

    final CameraCaptureSession.CaptureCallback previewCb = new CameraCaptureSession.CaptureCallback() {
        @Override public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest r, TotalCaptureResult res) {
            Integer iso = res.get(CaptureResult.SENSOR_SENSITIVITY);
            Long exp = res.get(CaptureResult.SENSOR_EXPOSURE_TIME);
            if (iso != null) lastIso = iso;
            if (exp != null) lastExp = exp;
            if (!awaitingLock) return;
            Integer af = res.get(CaptureResult.CONTROL_AF_STATE), ae = res.get(CaptureResult.CONTROL_AE_STATE);
            boolean afOk = af == null || af == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED
                    || af == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED || af == CaptureResult.CONTROL_AF_STATE_INACTIVE;
            boolean aeOk = ae == null || ae == CaptureResult.CONTROL_AE_STATE_CONVERGED || ae == CaptureResult.CONTROL_AE_STATE_LOCKED
                    || ae == CaptureResult.CONTROL_AE_STATE_FLASH_REQUIRED;
            if ((afOk && aeOk) || System.currentTimeMillis() > lockDeadline) {
                awaitingLock = false;
                Runnable go = afterLock;
                afterLock = null;
                if (go != null) go.run();
            }
        }
    };

    void restartPreview() {
        if (ses == null || dev == null || previewTarget == null) return;
        try {
            CaptureRequest.Builder b = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            b.addTarget(previewTarget);
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            common(b);
            ses.setRepeatingRequest(b.build(), previewCb, bg);
        } catch (Throwable ignored) { }
    }

    /** Focus and exposure settle first (like a real camera's half-press), then `then` runs. */
    void lockThen(Runnable then) {
        try {
            CaptureRequest.Builder b = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            b.addTarget(previewTarget);
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            common(b);
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START);
            b.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER_START);
            afterLock = then;
            lockDeadline = System.currentTimeMillis() + 900;
            awaitingLock = true;
            ses.capture(b.build(), previewCb, bg);
        } catch (Throwable t) {
            awaitingLock = false;
            then.run();
        }
    }

    void unlock() {
        try {
            if (ses == null || dev == null) return;
            CaptureRequest.Builder b = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            b.addTarget(previewTarget);
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_CANCEL);
            common(b);
            ses.capture(b.build(), null, bg);
        } catch (Throwable ignored) { }
        restartPreview();
    }

    int captureDeg() {
        int turn = front ? -deviceDeg : deviceDeg;
        return (sensorOrient + turn + 360) % 360;
    }

    void capture() {
        if (ses == null || dev == null || capturing) return;
        capturing = true;
        flashCover.setAlpha(0.85f);
        flashCover.animate().alpha(0).setDuration(260).start();
        frame.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        final boolean useHdr = hdr && yuv != null;
        if (useHdr) showProcessing(true);
        lockThen(() -> { if (useHdr) burst(); else single(); });
    }

    private void hq(CaptureRequest.Builder b) {
        b.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY);
        b.set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY);
        b.set(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE, CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY);
        b.set(CaptureRequest.HOT_PIXEL_MODE, CaptureRequest.HOT_PIXEL_MODE_HIGH_QUALITY);
        b.set(CaptureRequest.TONEMAP_MODE, CaptureRequest.TONEMAP_MODE_HIGH_QUALITY);
        b.set(CaptureRequest.SHADING_MODE, CaptureRequest.SHADING_MODE_HIGH_QUALITY);
    }

    void single() {
        try {
            CaptureRequest.Builder b = dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            b.addTarget(reader.getSurface());
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            common(b);
            hq(b);
            b.set(CaptureRequest.JPEG_QUALITY, (byte) 98);
            b.set(CaptureRequest.JPEG_ORIENTATION, captureDeg());
            ses.capture(b.build(), null, bg);
        } catch (Throwable t) {
            a.ui.post(() -> { capturing = false; showProcessing(false); a.toast("Couldn't take the photo"); });
        }
    }

    // ------------------------------------------------------------------ HDR+ burst

    final ExecutorService work = Executors.newSingleThreadExecutor();
    HdrMerge merge;
    int burstLeft, burstDeg;
    boolean finishing;
    Filter burstFilter;

    void burst() {
        try {
            int iso = lastIso;
            long exp = lastExp;
            int frames = iso >= 1600 ? 8 : iso >= 640 ? 7 : 6;
            float under = 1f;
            boolean manual = manualOk;
            if (manual) {
                under = 0.72f;                                        // a bit darker → highlights are kept
                if (iso > 800 && exp < 50_000_000L) { exp = Math.min(exp * 2, 90_000_000L); iso = Math.max(50, iso / 2); }
                exp = Math.max(100_000L, (long) (exp * under));
            }
            merge = new HdrMerge(ySize.getWidth(), ySize.getHeight(), 1f / under);
            burstLeft = frames;
            finishing = false;
            burstDeg = captureDeg();
            burstFilter = filter;
            List<CaptureRequest> reqs = new ArrayList<>();
            for (int i = 0; i < frames; i++) {
                CaptureRequest.Builder b = dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                b.addTarget(yuv.getSurface());
                b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO);
                b.set(CaptureRequest.CONTROL_AWB_LOCK, true);
                if (manual) {
                    b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF);
                    b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exp);
                    b.set(CaptureRequest.SENSOR_SENSITIVITY, iso);
                } else {
                    b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                    b.set(CaptureRequest.CONTROL_AE_LOCK, true);
                }
                common(b);
                hq(b);
                reqs.add(b.build());
            }
            ses.captureBurst(reqs, null, bg);
            final HdrMerge m = merge;
            a.ui.postDelayed(() -> { if (merge == m && !finishing) work.execute(this::finishBurst); }, 7000);   // safety net
        } catch (Throwable t) {
            merge = null;
            single();
        }
    }

    void onYuv(ImageReader r) {
        Image img;
        try { img = r.acquireNextImage(); } catch (Throwable t) { return; }
        if (img == null) return;
        final HdrMerge m = merge;
        if (m == null) { img.close(); return; }
        work.execute(() -> {
            try { if (!finishing && merge == m) m.add(img); }
            catch (Throwable ignored) { }
            finally { img.close(); }
            if (merge == m && --burstLeft <= 0) finishBurst();
        });
    }

    void finishBurst() {
        HdrMerge m = merge;
        if (m == null || finishing) return;
        finishing = true;
        byte[] bytes = null;
        try {
            if (m.n > 0) {
                Bitmap b = m.finish();
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream(8 << 20);
                b.compress(Bitmap.CompressFormat.JPEG, 96, bos);
                b.recycle();
                bytes = bos.toByteArray();
            }
        } catch (Throwable ignored) { }
        merge = null;
        final byte[] fb = bytes;
        final Filter f = burstFilter;
        final int deg = burstDeg;
        a.ui.post(() -> {
            showProcessing(false);
            capturing = false;
            if (bg != null) bg.post(this::unlock);
            if (fb == null) { a.toast("Couldn't take the photo"); return; }
            a.cameraCaptured(fb, f, deg);
        });
    }

    void onJpeg(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) return;
            ByteBuffer buf = img.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buf.remaining()];
            buf.get(bytes);
            final Filter f = filter;
            a.ui.post(() -> {
                capturing = false;
                showProcessing(false);
                if (bg != null) bg.post(this::unlock);
                a.cameraCaptured(bytes, f, 0);
            });
        } catch (Throwable t) {
            a.ui.post(() -> { capturing = false; showProcessing(false); a.toast("Couldn't take the photo"); });
        } finally {
            if (img != null) img.close();
        }
    }
}
