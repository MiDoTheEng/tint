package app.tint;

/**
 * "Tint Camera": the camera on its own, with its own icon and its own place in recent apps.
 * It shares everything with the editor but never shows it; photos go straight to the gallery.
 */
public class CameraActivity extends MainActivity {
    @Override boolean cameraOnly() { return true; }
}
